# Kurzbeschreibung:Vollständige Klammerung

# (i)
# (5 + ((7 * 4) * 2))

# (ii)
# (((4 + 8) * (-3)) < (42 + 1))

# (iii)
# (True or (((4 + 3) < x) and (not (z >= (7 * 10)))))


# Aufgabe 4b: Operatorbäume

# (i)
# +
#     5
#     *
#         *
#             7
#             4
#         2


# (ii)
# <
#     *
#         +
#             4
#             8
#         - (Vorzeichen)
#             3
#     +
#         42
#         1


# (iii)
# or
#     True
#     and
#         <
#             +
#                 4
#                 3
#             x
#         not
#             >=
#                 z
#                 *
#                     7
#                     10