from wypp import *

#   Kurzbeschreibung: Rechnet Euro nach Abzug der Steuer in Dollar um
#   Eingaben: Eurobetrag ab 0 in (float) & Dollarkurs in Dollar pro Euro größer als 0 in (float)
#   Ergebnis: Dollarbetrag nach Steuerabzug in (float)

def dollarNachSteuer(euro: float, dollarkurs: float) -> float:
    if euro * 0.10 <= 100:
        return (euro - euro * 0.10) * dollarkurs
    else:
        return (euro - 100) * dollarkurs


check(dollarNachSteuer(50.0, 1.15), 51.75)
check(dollarNachSteuer(2000.0, 1.15), 2185.0)
check(dollarNachSteuer(1000.0, 1.15), 1035.0)
check(dollarNachSteuer(0.0, 1.15), 0.0)
check(dollarNachSteuer(50.0, 2.0), 90.0)