from wypp import *

# Kurzbeschreibung: Verdoppelt eine Zeichenkette.
# Eingabe: Zeichenkette in (str)
# Ergebnis: Zweimal hintereinander angehängte Zeichenkette in (str)

def verdoppeln(text: str) -> str:
    return text + text

check(verdoppeln('Wehr'), 'WehrWehr')
check(verdoppeln(''), '')


# Kurzbeschreibung: Vervierfacht eine Zeichenkette.
# Eingabe: Zeichenkette in (str)
# Ergebnis: Viermal hintereinander angehängte Zeichenkette in (str)

def vervierfachen(text: str) -> str:
    return verdoppeln(verdoppeln(text))

check(vervierfachen('ab'), 'abababab')
check(vervierfachen(''), '')


#   Kurzbeschreibung: Verzwölffacht eine Zeichenkette.
#   Eingabe: Zeichenkette in (str)
#   Ergebnis: Zwölfmal hintereinander angehängte Zeichenkette in (str)

def verzwoelffachen(text: str) -> str:
    vierfach = vervierfachen(text)
    return vierfach + vierfach + vierfach

check(verzwoelffachen('a'), 'aaaaaaaaaaaa')
check(verzwoelffachen(''), '')


#   Kurzbeschreibung: Versechzehnfacht eine Zeichenkette.
#   Eingabe: Zeichenkette in (str)
#   Ergebnis: Sechzehnmal hintereinander angehängte Zeichenkette in (str)

def versechzehnfachen(text: str) -> str:
    return vervierfachen(vervierfachen(text))

check(versechzehnfachen('a'), 'aaaaaaaaaaaaaaaa')
check(versechzehnfachen(''), '')