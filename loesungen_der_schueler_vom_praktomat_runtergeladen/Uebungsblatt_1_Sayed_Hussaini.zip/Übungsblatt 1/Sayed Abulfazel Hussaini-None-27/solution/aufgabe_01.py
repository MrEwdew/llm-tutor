from wypp import *

#   Kurzbeschreibung: Rechnet Celsius in Fahrenheit um
#   Eingabe: Temperatur in Celsius in (float).
#   Ergebnis: Temperatur in Fahrenheit in (float)

def celsiusZuFahrenheit(celsius: float) -> float:
    return celsius * 9 / 5 + 32

check(celsiusZuFahrenheit(0.0), 32.0)
check(celsiusZuFahrenheit(100.0), 212.0)
check(celsiusZuFahrenheit(-40.0), -40.0)

