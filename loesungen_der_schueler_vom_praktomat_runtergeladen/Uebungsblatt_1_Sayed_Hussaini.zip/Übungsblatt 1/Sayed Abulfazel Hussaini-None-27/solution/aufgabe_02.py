from wypp import *

#   Kurzbeschreibung: Rechnet einen Eurobetrag in Dollar um
#   Eingabe: Eurobetrag in (float)
#   Ergebnis: Dollarbetrag in (float)

def euroZuDollar(euro: float) -> float:
    return euro * 1.15

check(euroZuDollar(0.0), 0.0)
check(euroZuDollar(10.0), 11.5)
check(euroZuDollar(100.0), 115.0)