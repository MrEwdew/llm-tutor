from wypp import *

#1.Kurzbeschreibung:
#Celsius in Fahrenheit Konvertieren

#2.Datenanalyse
#Eingabe:Temperatur C typ: float
#Ausgabe:Temperatur F typ: float

#3.Kopf:
def tempCtoF(tempC: float) -> float:
    return tempC * (9/5) + 32


#4.Check
check(tempCtoF(10),50)
check(tempCtoF(0),32)