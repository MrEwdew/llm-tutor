from wypp import *

#Kurzbeschreibung:
#Euro in Dollar kovertieren

#Datenanalyse:
#Eingabe: Euro typ: float
#Ausgabe: Dollar typ: float

#Kopf
def convEuroToDollar(euro:float) -> float:
    return euro * 1.15


#Checks:
check(convEuroToDollar(1),1.15)
check(convEuroToDollar(0),0)