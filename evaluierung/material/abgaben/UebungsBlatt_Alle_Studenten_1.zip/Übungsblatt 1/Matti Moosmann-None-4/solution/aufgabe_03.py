from wypp import *
# Kurzbeschreibung:
#euro zu Dollar Konvertieren mit 10% Steuer
#und maximalen Steuerbetrag von 100€

#Datenanalyse:
#Eingabe:Preis in euro typ. float
#Ausgabe:Preis in Dollar typ: float

#Kopf:
def convEuroToDollarTax(euro:float, kurs:float) -> float:
    if euro <= 1000:
        euro = (euro * 0.9) * kurs
        return euro
    else:
        euro = euro * kurs - 100
        return euro


#Checks:
check(convEuroToDollarTax(50,1),45)
check(convEuroToDollarTax(2000,1),1900)
check(convEuroToDollarTax(50,2),90)
check(convEuroToDollarTax(2000,2),3900)