from wypp import *

#Kurzbeschreibung:
#Funktion soll strings vervielfältigt

#Datenanalyse:
#Eingabe: wort typ string
#Ausgabe: Verdoppeltes Wort typ string. (2 = double, 4 = quadruple 12 = duodecuple 16 = quindecuple 😎)

#Kopf a)
def doubleStr(wort:str) -> str:
    return 2 * wort

#Check a)
check(doubleStr('Wehr'),'WehrWehr')


#Kopf b)
def quadrupleStr(wort:str) -> str:
    return 4 * wort

#Check b)
check(quadrupleStr('Wehr'),'WehrWehrWehrWehr')


#Kopf c
def duodecupleStr(wort:str) -> str:
    return 12 * wort

#Check c)
check(duodecupleStr('Wehr'),'WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr')


#Kopf d)
def quindecupleStr(wort:str) -> str:
    return 16 * wort

#Check d)
check(quindecupleStr('Wehr'),'WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr')