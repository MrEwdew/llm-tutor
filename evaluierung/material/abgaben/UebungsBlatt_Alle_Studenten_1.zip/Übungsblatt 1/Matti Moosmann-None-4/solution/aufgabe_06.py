import math
from wypp import *

#1.Kurzbeschreibung.
#Berechnet die Zeit t in Sekunden, die das Boot benötigt, um einen Fluss der Breite a zu überqueren.

#2.Daten-Analyse:
#Eingabe: a (Breite des Flusses in m) typ: float, vBoot (Geschwindigkeit des Boots in m/s) typ: float
#ausgabe: t (Zeit zum Überqueren in s) typ: float

#3.Kopf
def zeitUeberqueren(a: float, vBoot: float) -> float:
    return a / vBoot

#Check:
check(zeitUeberqueren(4.0, 2.0), 2.0)
check(zeitUeberqueren(10.0, 5.0), 2.0)


#1.Kurzbeschreibung:
#Berechnet die Strecke b in Metern, die das Boot durch die Strömung während der Zeit t abgetrieben wird

#2.Datenanalyse:
#Eingabe: t (Zeit in s) typ: float, vFluss (Strömungsgeschwindigkeit in Meter/s) typ: float
#Ausgabe: b (abgetriebene Strecke in m) typ: float

#3.Kopf:
def streckeB(t: float, vFluss: float) -> float:
    return t * vFluss

#4.Check:
check(streckeB(2.0, 1.5), 3.0)
check(streckeB(4.0, 2.5), 10.0)

#1.Kurzbeschreibung:
#Berechnet Strecke c in Metern, die das Boot beim Überqueren des Flusses
#mit Strömung zurücklegt (Satz des Pythagoras).

#2.Datenanalyse
#Eingabe: a (Breite des Flusses in m) typ: float, vBoot typ: float, vFluss typ: float
#Ausgabe: c (tatsächlich zurückgelegte Strecke in m) typ: float

#3.Kopf:
def streckeC(a: float, vBoot: float, vFluss: float) -> float:
    t = zeitUeberqueren(a, vBoot)
    b = streckeB(t, vFluss)
    return math.sqrt(a**2 + b**2)

#4.Checks:
check(streckeC(4.0, 2.0, 1.5), 5.0)
check(streckeC(8.0, 2.0, 1.5), 10.0)
check(streckeC(4.0, 2.0, 0.0), 4.0)