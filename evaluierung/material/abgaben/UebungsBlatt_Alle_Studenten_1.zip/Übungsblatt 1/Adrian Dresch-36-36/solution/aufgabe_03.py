from wypp import *

# Berechnet den Dollarbetrag nach Abzug einer Umtauschsteuer von 10%,
# die auf hoechstens 100 Euro begrenzt ist.
# Eingabe: euro (float), Betrag in Euro; dollarkurs (float), Dollar pro Euro.
# Ergebnis: float, ausgezahlter Dollarbetrag nach dem Steuerabzug.

def EurozuDollarMitSteuer(euro: float, dollarkurs: float) -> float:
    steuer = min(euro * 0.10, 100)
    euroNachSteuer = euro - steuer
    return euroNachSteuer * dollarkurs


check(EurozuDollarMitSteuer(50, 1.0), 45)
check(EurozuDollarMitSteuer(2000, 1.0), 1900)
check(EurozuDollarMitSteuer(1000, 1.0), 900)
