from wypp import *

#Funktion zur umrechnung von Euro zu Dollar.

#Eingabe: Euro in float
#Ausgabe: Dollar in float

def EurozuDollar(Euro:float) -> float:
    return Euro * 1.15

check (EurozuDollar(10), 11.5)
