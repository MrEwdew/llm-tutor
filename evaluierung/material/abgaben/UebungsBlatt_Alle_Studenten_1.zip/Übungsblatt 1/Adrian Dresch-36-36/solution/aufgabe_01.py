from wypp import *

#Funktion um Temperaturwert in Celsius nach Fahrenheit zu konvertieren.

#Eingabe: Celsius in int
#Ergebnis: Fahrenheit in int


def RechnungFahrenheit(celsius:float) -> float:
    return celsius * (9/5) +32


check(RechnungFahrenheit(20), 68)
