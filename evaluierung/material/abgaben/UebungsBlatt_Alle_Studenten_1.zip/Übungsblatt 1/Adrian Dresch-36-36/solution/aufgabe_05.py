from wypp import *

# (a) Verdoppelt eine Zeichenkette.
# Eingabe: text (str), beliebige Zeichenkette.
# Ergebnis: str, zweimal hintereinander angehaengte Zeichenkette.

def verdoppeln(text: str) -> str:
    return text * 2

check(verdoppeln("Wehr"), "WehrWehr")
check(verdoppeln(""), "")

# (b) Vervierfacht eine Zeichenkette.
# Eingabe: text (str), beliebige Zeichenkette.
# Ergebnis: str, viermal hintereinander angehaengte Zeichenkette.

def vervierfachen(text: str) -> str:
    return text * 4

check(vervierfachen("Hi"), "HiHiHiHi")
check(vervierfachen(""), "")

# (c) Verzwoelffacht eine Zeichenkette.
# Eingabe: text (str), beliebige Zeichenkette.
# Ergebnis: str, zwoelfmal hintereinander angehaengte Zeichenkette.

def verzwoelffachen(text: str) -> str:
    return text * 12

check(verzwoelffachen("a"), "aaaaaaaaaaaa")
check(verzwoelffachen(""), "")

# (d) Versechzehnfacht eine Zeichenkette.
# Eingabe: text (str), beliebige Zeichenkette.
# Ergebnis: str, sechzehnmal hintereinander angehaengte Zeichenkette.

def versechzehnfachen(text: str) -> str:
    return text * 16

check(versechzehnfachen("a"), "aaaaaaaaaaaaaaaa")
check(versechzehnfachen(""), "")
