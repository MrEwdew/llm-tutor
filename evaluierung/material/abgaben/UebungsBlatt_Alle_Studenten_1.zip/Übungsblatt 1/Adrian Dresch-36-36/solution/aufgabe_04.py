# Aufgabe 4: Operatorvorrang


# (a) Eindeutige Klammerung:
# (i)  (5 + ((7 * 4) * 2))
# (ii) (((4 + 8) * (-3)) < (42 + 1))
# (iii) (True or (((4 + 3) < x) and (not (z >= (7 * 10)))))

