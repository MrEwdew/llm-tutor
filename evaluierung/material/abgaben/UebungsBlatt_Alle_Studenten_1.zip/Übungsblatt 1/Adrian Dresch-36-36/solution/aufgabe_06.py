from wypp import *
import math

# Berechnet die tatsaechliche Fahrtstrecke des Boots durch den Fluss.
# Eingabe: a (float), Flussbreite in Metern; vBoot (float), Bootsgeschwindigkeit
# quer zur Stroemung in m/s; vFluss (float), Stroemungsgeschwindigkeit in m/s.
# Ergebnis: float, Laenge der diagonalen Bootsstrecke in Metern.

def bootsstrecke(a: float, vBoot: float, vFluss: float) -> float:
    t = ueberquerungszeit(a, vBoot)
    b = abdrift(t, vFluss)
    return math.sqrt(a * a + b * b)


# Berechnet die Zeit, die das Boot zum Ueberqueren des Flusses braucht.
# Eingabe: a (float), Breite in Metern; vBoot (float), Geschwindigkeit in m/s.
# Ergebnis: float, Ueberquerungszeit in Sekunden.

def ueberquerungszeit(a: float, vBoot: float) -> float:
    return a / vBoot


check(ueberquerungszeit(4, 2), 2)
check(ueberquerungszeit(6, 3), 2)

# Berechnet, wie weit das Boot waehrend der Ueberquerung abgetrieben wird.
# Eingabe: t (float), Zeit in Sekunden; vFluss (float), Stroemung in m/s.
# Ergebnis: float, Abdrift in Metern.

def abdrift(t: float, vFluss: float) -> float:
    return t * vFluss

check(abdrift(2, 1.5), 3)
check(abdrift(2, 0), 0)
check(bootsstrecke(4, 2, 1.5), 5)
check(bootsstrecke(6, 3, 0), 6)
