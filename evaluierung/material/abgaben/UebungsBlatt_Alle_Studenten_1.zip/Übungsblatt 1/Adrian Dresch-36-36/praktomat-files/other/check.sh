#!/bin/bash

PYTHONPATH=/wypp/python/site-lib:$PYTHONPATH python3 /checker/check.py python "$@"
