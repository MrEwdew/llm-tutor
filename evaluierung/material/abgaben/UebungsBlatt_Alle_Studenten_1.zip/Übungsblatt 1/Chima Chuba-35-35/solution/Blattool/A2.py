from wypp import * 

#Dollar in Euro umrechnen
# Eingabe: Euro(float)
# Audgabe: Dollar (float)


def euroumrechner(Euro: float) -> float:
    return Euro * 1.15



check(euroumrechner(5), 5.75)