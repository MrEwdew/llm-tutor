from wypp import * 


# Euro in Dollar Umrechnen mit 10% Steuerentnahme
# Eingabe: Euro
# Ausgabe: Dollar 


def euroumrechnerindollar5(Euro: float, Wechselkurs: float) -> float:
    if Euro > 1000:
        return (Euro - 100 ) * Wechselkurs
    else:
        return(Euro *  0.9) * Wechselkurs



check(euroumrechnerindollar5(2000,1.15),2185)


