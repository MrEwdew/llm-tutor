from wypp import * 
import math 

#  Die Länge der Strecke c, die das Boot tatsächlich zurücklegt, um von einem Ufer zum anderen zu Kommen
# Eingabe: a == Breite des Flusses in Meter; Vfluss == Strömungsgeschwindigkeit des Flusses; Vboot == die Geschwindigkeit des Boots; t == die zeit zum Überqueren des Flusses 
# Ergebniss des zurück gelegten weg des Bootes


# Die zeit zum Überqueren des Flusses 
def tRechner(breiteDesFlusses: float,  vboot: float) -> float:
    return breiteDesFlusses/ vboot
    

def brechner(zeit: float, vfluss: float) -> float:
    return zeit * vfluss


def ergebniss(breite: float, zeit: float) -> float:
    return math.sqrt(breite**2 + zeit**2)



check(ergebniss(4,brechner(tRechner(4,2),1.5)),5)