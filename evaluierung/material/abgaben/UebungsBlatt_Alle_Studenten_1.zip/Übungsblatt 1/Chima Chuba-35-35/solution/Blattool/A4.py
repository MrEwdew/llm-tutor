from wypp import * 

5+(7 * 4 *2)

((4+7)*(-3)) <(42+1)

true or( (4+3  < x) and (not(z>=(7*10)) ))