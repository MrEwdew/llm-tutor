from wypp import * 


#Konventiert Temperaturwert nach Fahrenheit.
# Eingabe:Temparatur(float) in Celicius
# Ausgabe: Temperatur nach Fahrenheit(Float)

def temperaturwert(Celcius: float) -> float :
    return Celcius * 9/5 + 32



check(temperaturwert(20), 68)