from wypp import * 

# (a) String verdoppeln
def verdoppeln(text):
    return text * 2

# (b) String vervierfachen
def vervierfachen(text):
    return text * 4

# (c) String verzwölffachen
def verzwoelffachen(text):
    return text * 12

# (d) String versechzehnfachen
def versechzehnfachen(text):
    return text * 16


# Test
print(verdoppeln("Wehr"))
print(vervierfachen("Wehr"))
print(verzwoelffachen("Wehr"))
print(versechzehnfachen("Wehr"))
