from wypp import * 

# Funktion, welche Temperaturwert in Celcius nach Fahrenheit konvertiert 
# Eingabe: Temperaturwert in Celcius (typ: float)
# Ausgabe: Termperaturwert in Fahrenheit (typ: float)
def convert_termperatur(celcius: float) ->float:
    return ((celcius * (9/5)) + 32)

check(convert_termperatur(5), 41)