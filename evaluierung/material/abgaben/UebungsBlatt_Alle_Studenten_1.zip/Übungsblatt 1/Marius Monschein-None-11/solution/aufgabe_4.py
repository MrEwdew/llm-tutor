from wypp import * 

# (i)
x_1 = 5 + 7 * 4 * 2
x_2 = (5 + ((7 * 4) * 2))
print(x_1 == x_2)

# (ii)
y_1 = (4 + 8) * -3 < 42 + 1
y_2 = (((4 + 8) * -3) < (42 + 1))
print(y_1 == y_2)

# (iii)
z_1 = True or 4 + 3 < x and not z >= 7*10
z_2 = (True or (((4 + 3) < x) and (not (z >= (7*10)))))
print(z_1 == z_2)