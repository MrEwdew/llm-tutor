from wypp import * 

# Funktion, welche die Länge berechnet die das Boot zurücklegt (c)
# Eingabe: Abstand der beiden Flussufer zueinander (a) (typ: float)
#          die Geschwindigkeit des Boots (vBoot) (typ: float)
#          die Geschwindigkeit des Flusses (vFluss) (typ: float)
# Ausgabe: die Strecke die das Boot zurücklegt (c) (typ: float)
def compute_distance(a: float, vBoot: float, vFluss: float) -> float:
    ratio = a / vBoot
    b = vFluss * ratio
    return math.sqrt(a**2 + b**2)

check(compute_distance(4, 2, 1.5), 5)