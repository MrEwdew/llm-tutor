from wypp import * 

# Funktion, die einen Eurobetrag nach Dollar umrechnet 
# Eingabe: Betrag in Euro (typ: float)
# Ausgabe: Betrag in Dollar (typ: float)
def convert_euro(euro: float) -> float:
    return (euro * 1.15)

check(convert_euro(1), 1.15)