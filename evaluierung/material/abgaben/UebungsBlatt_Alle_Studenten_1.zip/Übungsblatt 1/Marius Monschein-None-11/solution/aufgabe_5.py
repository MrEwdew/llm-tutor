from wypp import * 

# Funktion, die eine Zeichenkette verdoppelt 
# Eingabe: Zeichenkette (typ: str)
# Ausgabe: verdoppelte Zeichenkette (typ: str)
def double_string(original_str: str) ->str: 
    return original_str * 2

def string_times_4(original_str: str) ->str: 
    return original_str * 4

def string_times_8(original_str: str) ->str: 
    return original_str * 8

def string_times_16(original_str: str) ->str: 
    return original_str * 16

check(double_string("Wehr"), "WehrWehr")
check(string_times_4("Wehr"), "WehrWehrWehrWehr")
check(string_times_8("Wehr"), "WehrWehrWehrWehrWehrWehrWehrWehr")
check(string_times_16("Wehr"), "WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr")



