from wypp import * 

# Funktion, die Euro in Dollar konvertiert, doch dabei Steuern beachtet 
# Eingabe: Betrag in Euro (typ: float) / Dollarkurs in USD/EUR (typ: float)
# Ausgabe: Betrag in Dollar abzüglich Steuern (typ: float)
def convert_euro_2(euro: float, dollarkurs: float) -> float:
    tax_max = 100
    tax = euro * 0.1 
    current_tax = min(tax, tax_max)
    return ((euro * dollarkurs) - current_tax)


# Fall 1) Steuern 10% des Eurobetrags 
check(convert_euro_2(100, 1.5), 150-10)

# Fall 2) Steuern max. 100 euro 
check(convert_euro_2(100000, 1.5), 150000-100)
