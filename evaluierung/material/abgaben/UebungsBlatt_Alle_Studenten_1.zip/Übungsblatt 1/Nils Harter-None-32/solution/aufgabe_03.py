from wypp import *
#Betrag an Dollar den man, bei variablem Kurs, abzüglich 10% Steuer erhält. 
#Eingabe: Eingetauschter Betrag an Euro, Euro-Dollar-Kurs
#Ausgabe: Erhaltener Betrag an Dollar

def euroZuDollarEintausch(eurobetrag: float, euroDollarKurs: float) -> float:  #Falls euroZuDollar >= 1,000 
    steuer = min(eurobetrag * 0.1, 100)
    return (eurobetrag - steuer) * euroDollarKurs
 
check(euroZuDollarEintausch(1001, 1), 901)
check(euroZuDollarEintausch(100, 1), 90)
check(euroZuDollarEintausch(0, 1), 0)
check(euroZuDollarEintausch(100, 2), 180)
check(euroZuDollarEintausch(1001, 2), 1802)