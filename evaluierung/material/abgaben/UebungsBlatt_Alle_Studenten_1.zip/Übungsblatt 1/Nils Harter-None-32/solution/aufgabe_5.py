from wypp import *
#verdoppelt Zeichenkette
#Eingabe: Zeichenkette, als String
#Ausgabe: verdoppelte Zeichenkette, als String

def verdoppleZeichenkette(zeichenkette: str) -> str:
    return zeichenkette + zeichenkette

check(verdoppleZeichenkette("Test"), "TestTest")
check(verdoppleZeichenkette(" "), "  ")

#vervierfachte Zeichenkette
#Eingabe: Zeichenkette, als String
#Ausgabe: vervierfachte Zeichenkette, als String

def vervierfacheZeichenkette(zeichenkette: str) -> str:
    return verdoppleZeichenkette(zeichenkette) + verdoppleZeichenkette(zeichenkette)

check(vervierfacheZeichenkette("Test"), "TestTestTestTest")
check(vervierfacheZeichenkette(" "), "    ")

#verzwölffachte Zeichenkette
#Eingabe: Zeichenkette, als String
#Ausgabe: verzwölffachte Zeichenkette, als String 

def verzwölfacheZeichenkette(zeichenkette: str) -> str:
    return zeichenkette * 12 

check(verzwölfacheZeichenkette("Test"), "TestTestTestTestTestTestTestTestTestTestTestTest")
check(verzwölfacheZeichenkette(" "), "            ")

#versechzehnfache Zeichenkette
#Eingabe: Zeichenkette, als String
#Ausgabe: versechzehnfachte Zeichenkette, als String 

def versechzehnfacheZeichenkette(zeichenkette: str) -> str:
    return zeichenkette * 16

check(versechzehnfacheZeichenkette("Test"), "TestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTest")
check(versechzehnfacheZeichenkette(" "), "                ")