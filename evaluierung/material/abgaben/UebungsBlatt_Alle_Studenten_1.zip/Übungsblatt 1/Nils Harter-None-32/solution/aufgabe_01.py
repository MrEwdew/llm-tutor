from wypp import *
#Temperatur von Celcius nach Fahrenheit konvertieren. 
#Eingabe: Temperatur in Celcius, als float.
#Ausgabe: Temperatur in Fahrenheit, als float.

def celciusZuFahrenheit(temperaturInCelcius: float) -> float:  #Fahrenheit = Celcius * 9/5 + 32
    return temperaturInCelcius * 9/5 + 32

check(celciusZuFahrenheit(10), 50)
check(celciusZuFahrenheit(-20), -4)
check(celciusZuFahrenheit(0), 32)

