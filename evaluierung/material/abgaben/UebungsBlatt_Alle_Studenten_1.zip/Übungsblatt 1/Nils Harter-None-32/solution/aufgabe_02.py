from wypp import *
#Euro nach Dollar umrechnen. 
#Eingabe: Betrag in Euro
#Ausgabe: Betrag in Dollar

def euroZuDollar(eurobetrag: float) -> float:  # Dollar = Euro * 1.15
    return eurobetrag * 1.15

check(euroZuDollar(0), 0)
check(euroZuDollar(1.31), 1.5065)
check(euroZuDollar(-2), -2.3)