from wypp import *
#Satz des Pythagoras aus Breite des Flusses und abgetriebener Strecke
#Eingabe: Flussbreite als float, abgetriebene Strecke als float
#Ausgabe: zurückgelegte Strecke als float

def zurueckgelegteStrecke(flussbreite: float, abgetriebeneStrecke: float) -> float:
    return math.sqrt(flussbreite ** 2 + abgetriebeneStrecke ** 2)


#Abgetriebene Strecke = Dauer * Strömungsgeschwindigkeit 
#Eingabe: Dauer als float, Strömungsgeschwindigkeit als float
#Ausgabe: abgetriebene Strecke als float
def abgetriebeneStrecke(dauer: float, stroemungsgeschwindigkeit: float) -> float:
    return dauer * stroemungsgeschwindigkeit

#Dauer = Breite des Flusses / Geschwindigkeit des Bootes
#Eingabe: Breite des Flusses als float, Geschwindigkeit des Boots als float
#Ausgabe: dauer als float
def dauer(flussbreite: float, bootGeschwindigkeit: float) -> float:
    return flussbreite / bootGeschwindigkeit 

check(zurueckgelegteStrecke(4, abgetriebeneStrecke(dauer(4, 2), 1.5)), 5)
