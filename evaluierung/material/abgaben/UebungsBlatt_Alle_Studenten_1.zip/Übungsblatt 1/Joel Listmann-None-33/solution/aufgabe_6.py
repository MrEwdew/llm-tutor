from wypp import *

#Funktion, die die tatsächlich Zurückgelegte Strecke des Bootes in Metern berechnet, die ein Boot nach Strömung zurücklegt 
#Eingabe: Abstand zum anderen Ufer in Metern (float), Geschwindigkeit des Bootes in m/s (float), Strömungsstärke in m/s (float)
#Ergebnis: Zurückgelegte Gesamtstrecke nach Strömung (float)

def berechneGesamtstrecke(abstandZumUfer: float, geschwindigkeitBoot:float, strömungsstärke:float)-> float:
    horizontaleStrecke = berechneHorizontaleStrecke(berechneBenötigteZeit(abstandZumUfer, geschwindigkeitBoot),strömungsstärke)
    return math.sqrt(abstandZumUfer**2 + horizontaleStrecke**2)

#Funktion, die die benötigte Zeit in Sekunden zum Überqueren des Ufers berechnet
#Eingabe: Abstand zum Ufer in Metern (float), geschwindigkeit des Bootes in m/s (float)
#Ergebnis: Benötigte Zeit zum Überqueren in Sekunden(float)

def berechneBenötigteZeit(abstandZumUfer: float, geschwindigkeitBoot: float)->float:
    return abstandZumUfer/geschwindigkeitBoot

#Funktion, die die horizontale Strecke in Metern berechnet
#Eingabe: Benötigte Zeit in Sekunden (float), Strömungsstärke in m/s (float)
#Ergebnis: Horizontale Strecke in Metern (float)

def berechneHorizontaleStrecke(benötigteZeit: float, strömungsstärke: float) -> float:
    return benötigteZeit * strömungsstärke


check(berechneBenötigteZeit(10,1),10)
check(berechneBenötigteZeit(8,2),4)

check(berechneHorizontaleStrecke(3,1),3)
check(berechneHorizontaleStrecke(6,2),12)

check(berechneGesamtstrecke(4, 2, 1.5), 5)
check(berechneGesamtstrecke(10, 2, 1.5), 12.5)
check(berechneGesamtstrecke(10, 1, 0), 10)