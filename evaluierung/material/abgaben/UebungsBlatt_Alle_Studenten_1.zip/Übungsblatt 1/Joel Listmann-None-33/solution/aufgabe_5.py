from wypp import *

#funktion, die eine Zeichenkette vervielfacht
#Eingabe: Zeichenkette (str) und anzahl (int)
#Ergebnis: Zeichenkette n mal hintereinander (str)

def zeichenketteVervielfachen(zeichenkette: str, iterationen: int) -> str:
    return zeichenkette * iterationen

check(zeichenketteVervielfachen("Wehr",3),"WehrWehrWehr")
check(zeichenketteVervielfachen("Tom",2),"TomTom")

#funktion, die eine Zeichenkette verdoppelt
#Eingabe: Zeichenkette (str)
#Ergebnis: Zeichenkette 2 mal hintereinander (str)

def zeichenketteVerdoppeln(zeichenkette:str) -> str:
    return zeichenketteVervielfachen(zeichenkette, 2)

check(zeichenketteVerdoppeln("Wehr"),"WehrWehr")
check(zeichenketteVerdoppeln("Tom"),"TomTom")

#funktion, die eine Zeichenkette vervierfacht
#Eingabe: Zeichenkette (str)
#Ergebnis: Zeichenkette 4 mal hintereinander (str)

def zeichenkettevervierfachen(zeichenkette:str) -> str:
    return zeichenketteVervielfachen(zeichenkette, 4)

check(zeichenkettevervierfachen("Wehr"),"WehrWehrWehrWehr")
check(zeichenkettevervierfachen("Tom"),"TomTomTomTom")

#funktion, die eine Zeichenkette verzwölffacht
#Eingabe: Zeichenkette (str)
#Ergebnis: Zeichenkette 12 mal hintereinander (str)

def zeichenketteVerzwölffachen(zeichenkette:str) -> str:
    return zeichenketteVervielfachen(zeichenkette, 12)

check(zeichenketteVerzwölffachen("Wehr"),"WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr")
check(zeichenketteVerzwölffachen("Tom"),"TomTomTomTomTomTomTomTomTomTomTomTom")

#funktion, die eine Zeichenkette versechzehnfacht
#Eingabe: Zeichenkette (str)
#Ergebnis: Zeichenkette 16 mal hintereinander (str)

def zeichenketteVersechszehnfachen(zeichenkette:str) -> str:
    return zeichenketteVervielfachen(zeichenkette, 16)

check(zeichenketteVersechszehnfachen("Wehr"),"WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr")
check(zeichenketteVersechszehnfachen("Tom"),"TomTomTomTomTomTomTomTomTomTomTomTomTomTomTomTom")