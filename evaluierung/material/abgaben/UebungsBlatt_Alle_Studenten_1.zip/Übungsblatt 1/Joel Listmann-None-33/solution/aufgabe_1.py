from wypp import * 

#Funktion, die einen Temperaturwert in Celsius zu Fahrenheit konvertiert
#Eingabe: Temperatur in Celsius (float)
#Ergebnis: Temperatur in Fahrenheit (float)

def konvertiereZuFahrenheit(celsius: float)-> float:
    return celsius * 9/5 +32

check(konvertiereZuFahrenheit(1), 33.8)
check(konvertiereZuFahrenheit(0), 32)