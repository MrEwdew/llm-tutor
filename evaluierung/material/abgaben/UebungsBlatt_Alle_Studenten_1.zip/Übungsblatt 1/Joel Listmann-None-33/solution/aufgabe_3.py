from wypp import *

#Funktion, die den Eurobetrag nach abzug einer Transaktionssteuer ausgibt
#Eingabe: Betrag in Euro (float) und Steuer in prozent (float)
#Ergebnis: Euro nach Steuer (float)

def eurobetragNachSteuer(euro: float, steuer: float) -> float:
    steuerbetrag= steuer*0.01 * euro
    if steuerbetrag > 100:
        return euro - 100
    else:
        return euro - steuerbetrag

check(eurobetragNachSteuer(50,10),45)
check(eurobetragNachSteuer(50,0),50)
check(eurobetragNachSteuer(120,10), 108)

#Funktion, die für einen gegebenen Dollarkurs die Menge an Dollar berechnet, die man nach Steuer für einen Eurobetrag erhält
#Eingabe: Betrag in Euro vor steuer (float), dollarkurs (float)
#Ergebnis: dollarbetrag nach steuer (float)

def dollarbetragNachSteuer(euroVorSteuer: float, dollarkurs: float) -> float:
    euroNachSteuer = eurobetragNachSteuer(euroVorSteuer,10)
    return euroNachSteuer * dollarkurs

check(dollarbetragNachSteuer(100,1.15), 103.5)
check(dollarbetragNachSteuer(10000,1.15),11385.0 )
check(dollarbetragNachSteuer(10000,1.30), 12870.0)
check(dollarbetragNachSteuer(50,1.30), 58.5)