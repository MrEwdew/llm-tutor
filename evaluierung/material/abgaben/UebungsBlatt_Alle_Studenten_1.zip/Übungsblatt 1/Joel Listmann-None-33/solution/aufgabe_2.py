from wypp import * 

#Funktion, die einen Eurobetrag nach Dollar umrechnet
#Eingabe: Betrag in Euro (float)
#Ergebnis: Betrag in Dollar (float)

def euroZuDollar(euro: float)-> float:
    return euro * 1.15

check(euroZuDollar(1), 1.15)
check(euroZuDollar(5), 5.75)