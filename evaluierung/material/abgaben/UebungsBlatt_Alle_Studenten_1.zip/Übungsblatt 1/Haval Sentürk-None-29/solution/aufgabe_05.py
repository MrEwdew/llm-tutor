from wypp import *

# Eine funktion die Strings Verdoppelt
# Eingabe: Beliebiger String als str
# Ergebnis: Verdoppeln von Strings als str

def verdoppler(word: str) -> str:
    return word + word

check(verdoppler("Banane"), "BananeBanane")
check(verdoppler("Apfel"), "ApfelApfel")
check(verdoppler(""), "")


# Eine funktion zu Vervierfachung
# Eingabe: Beliebiger String als str
# Ergebnis: Vervierfacht von Strings als str

def vervierfacher(word: str) -> str:
    return verdoppler(verdoppler(word))

check(vervierfacher("apfel"), "apfelapfelapfelapfel")
check(vervierfacher(""), "")

# Eine Funktion zu Verzwölffachung eines Strings
# Eingabe: Beliebiger String als str
# Ergebnis: Verzwölffachung des Strings als str

def verzwoelffacher(word: str) -> str:
    return verdoppler(vervierfacher(word)) + vervierfacher(word)

check(verzwoelffacher("apfel"), "apfelapfelapfelapfelapfelapfelapfelapfelapfelapfelapfelapfel")
check(verzwoelffacher(""), "")


# Eine funktion zur Versechzehnfachung
# Eingabe: Beliebiger String als str
# Ergebnis: Versechzehnfachung des Strings als str

def versechzehnfacher(word: str) -> str:
    return vervierfacher(vervierfacher(word))

check(versechzehnfacher("apfel"), "apfelapfelapfelapfelapfelapfelapfelapfelapfelapfelapfelapfelapfelapfelapfelapfel")
check(versechzehnfacher(""), "")