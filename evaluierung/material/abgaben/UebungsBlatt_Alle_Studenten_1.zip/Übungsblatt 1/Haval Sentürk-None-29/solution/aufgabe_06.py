from wypp import *
import math


# Teilproblem 1 was ist t -> Funktion zu Brechnung von t
# Eingabe: 
# * a als float
# * vBoot als float
# Ergebnis: t als float

def ueberquerungszeit(a: float, vBoot: float) -> float:
    return a / vBoot

check(ueberquerungszeit(4, 2), 2)
check(ueberquerungszeit(10, 5), 2)


# Teilproblem 2 was ist b -> Funtion zu Brechnung von b 
# Eingabe: 
# * vFluss als float
# * t als float
# Ergebnis: b als flaot

def abtriebsstreke(t: float, vFluss: float) -> float:
    return t * vFluss

check(abtriebsstreke(3, 3), 9)
check(abtriebsstreke(2, 10), 20)



# Hauptfunktion zu Berechnung der tatsächlich zurücklegten sträcke des Bootes
# Eingabe: 
# * Länge von Flussufer zu Flussufer -> flussuferabstand als float
# * Boot Geschwindigkeit -> vBoot als float
# * flussgeschwindigkeit -> vFluss als float
# Ergebnis: Tatsächlich zurücklegten sträcke des Bootes als float

def realeBootStraeke(flussuferabstand: float, vBoot: float, vFluss: float) -> float:
    return math.sqrt(flussuferabstand**2 + (abtriebsstreke(ueberquerungszeit(flussuferabstand, vBoot), vFluss))**2 )

check(realeBootStraeke(4, 2, 1.5), 5)
check(realeBootStraeke(5, 5, 0), 5)