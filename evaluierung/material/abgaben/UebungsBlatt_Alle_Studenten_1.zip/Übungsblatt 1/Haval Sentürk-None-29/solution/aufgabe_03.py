from wypp import *

MAXIMALSTEUERBETRAG = 100

# Dollarbetrag für einen Eurobetrag berechnen, abzüglich 10 % Steuer (max. 100 Euro)
# Eingabe: 
# * euroBetrag als float
# * dollarKurs als float 
# Ergebnis: dollarBetrag nach steuer float

def divisentauschtransaktionRechner(euroBetrag: float, dollarKurs: float) -> float:
    if euroBetrag <= 1000:
        return euroBetrag * 0.9 * dollarKurs
    else:
        return (euroBetrag - MAXIMALSTEUERBETRAG) * dollarKurs 


check(divisentauschtransaktionRechner(50, 1.15), 51.75)
check(divisentauschtransaktionRechner(1000, 1.15), 1035)
check(divisentauschtransaktionRechner(1200, 1.15), 1265)