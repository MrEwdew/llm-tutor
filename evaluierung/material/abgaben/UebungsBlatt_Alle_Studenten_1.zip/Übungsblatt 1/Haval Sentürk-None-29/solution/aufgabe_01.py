from wypp import *


# Funktion zu Berechnung von Celsius in Fahrenheit
# Eingabe: Celsius als float 
# Ergebnis: Fahrenheit als float

def celsiusZuFahrenheit(tempCelsius: float) -> float:
    return tempCelsius * (9 / 5) + 32


check(celsiusZuFahrenheit(10), 50)
check(celsiusZuFahrenheit(37), 98.6)


