from wypp import *

DOLLARKURS = 1.15

# Funktion zur Berechnung des Eurokurs in Dollarkurs 
# Eingabe: Euro als float
# Ergebnis: Dollar als float

def euroInDollarRechner(eurobetrag: float) -> float:
    return eurobetrag * DOLLARKURS


check(euroInDollarRechner(1), 1.15)
check(euroInDollarRechner(20), 23)