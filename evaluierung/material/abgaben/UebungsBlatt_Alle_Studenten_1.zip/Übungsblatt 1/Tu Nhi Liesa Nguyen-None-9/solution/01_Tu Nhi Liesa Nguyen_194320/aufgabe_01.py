from wypp import *
#Aufgabe 1
#Der Temperaturwert (Celsius) soll in Fahrenheit umgewandelt werden
#Tf = Tc * 9/5 +32
#Eingabe: Temperaturwert in Celsius
#Ausgabe: Temperaturwert in Fahrenheit

def temperaturwert(Tc: float) -> float:
    Tf = (Tc * (9/5)) +32
    return Tf

check(temperaturwert(10), 50.0)
check(temperaturwert(25), 77.0)
check(temperaturwert(0), 32.0)
