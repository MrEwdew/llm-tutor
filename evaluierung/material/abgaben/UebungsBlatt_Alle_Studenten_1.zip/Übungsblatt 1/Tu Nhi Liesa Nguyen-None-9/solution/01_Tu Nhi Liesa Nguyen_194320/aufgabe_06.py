from wypp import *
import math
#Aufgabe 6
#Boot überquert den Fluss der Breite (a) mit der Geschwindigkeit (vboot) 
#Boot wird von der Strömung (vfluss) seitlich verschoben

#zeit: Überfahrtauer
#bstrecke: Strecke b mit seitlicher verschobung
#cstrecke: Mit dem Stz des Pythagoras wird die Strecke c berechnet
#a: Flussbreite
#vfluss: Strömungsgeschwindigkeit
#vboot: Bootsgeschwindigkeit

#Eingabe: a, vfluss, vboot
#Ausgabe: tatsächlich zurückgelegte Strecke c 

def zeit(a: float,
         vboot: float) -> float:
    t = a/vboot
    return t

def bstrecke(vfluss: float,
             t: float) -> float:
    b = vfluss * t
    return b

def cstrecke(a: float,
             b: float) -> float:
    c = math.sqrt(a**2 + b**2)
    return c 


def gesamtstrecke(a: float,
                  vfluss: float,
                  vboot: float) -> float:
    t = zeit(a, vboot)
    b = bstrecke(vfluss, t)
    c = cstrecke(a, b)
    return c

check(zeit(4.0, 2.0), 2.0)
check(bstrecke(1.5, 2.0), 3.0)
check(cstrecke(4.0, 3.0), 5.0)
check(gesamtstrecke(4.0, 1.5, 2.0), 5.0)
