from wypp import *
#Aufgabe 5a-d
#vervielfachen von Strings
#a=2x
#b=4x
#c=12x
#d16x
#Eingabe: 'Wehr'
#Ausgabe: 'Wehra-d'

def aname(wort: str) -> str:
    ergebnis = wort * 2
    return ergebnis

def bname(wort: str) -> str:
    ergebnis = wort * 4
    return ergebnis

def cname(wort: str) -> str:
    ergebnis = wort * 12
    return ergebnis

def dname(wort: str) -> str:
    ergebnis = wort * 16
    return ergebnis

check(aname('Mensch'), 'MenschMensch')
check(bname('Baum'), 'BaumBaumBaumBaum')

