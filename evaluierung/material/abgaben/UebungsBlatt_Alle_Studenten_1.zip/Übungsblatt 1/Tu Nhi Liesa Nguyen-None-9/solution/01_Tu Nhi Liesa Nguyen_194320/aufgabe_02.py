from wypp import *
#Aufgabe 2
#Euro in Dollar umrechen
#1 Euro = 1.15 Dollar
#Eingabe: Eurobetrag
#Ausgabe: Umgerechneter Eurobetrag in Dollarbetrag

def waehrung(euro: float) -> float:
    umr = round((euro * 1.15),2)
    return umr

check(waehrung(10), 11.50)
check(waehrung(50), 57.5)
check(waehrung(0.50), 0.57)