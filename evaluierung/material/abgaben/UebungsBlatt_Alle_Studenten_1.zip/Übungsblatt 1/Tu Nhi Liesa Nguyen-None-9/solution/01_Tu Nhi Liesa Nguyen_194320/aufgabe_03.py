from wypp import *
#Aufabe 3
#Eurobetrag in Dollar umrechnen. 
#Dabei 10% und max. 100% einbehalten als Steuer.
#Es wird zuerst die Steuer abgezogen und dann mit dem Restwert/Endwert umgerechnet.
# 1 Euro = (variable Wählbar) Dollar 
#Eingabe: Eurobetrag 
#Ausgabe: Dollarbetrag (inkl. 10% und max 100Euro abzug)

def tausch(euro: float,
           umr: float) -> float:
    steuerabzug = round((euro * 0.1), 2)
    if steuerabzug > 100:
        steuerabzug = 100

    nachsteuerabzug = euro - steuerabzug
    end = round((nachsteuerabzug * umr),2)
    return end

check(tausch(50, 2), 90)
check(tausch(10, 3.2), 28.80)
check(tausch(10000, 1), 9900 )


