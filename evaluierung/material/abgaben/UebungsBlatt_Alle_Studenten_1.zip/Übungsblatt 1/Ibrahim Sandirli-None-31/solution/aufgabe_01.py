from wypp import *

# Programm zur Umrechnung von Celsius zu Fahrenheit
# Gegeben: Tf = Tc * 9/5 + 32.
# Eingabe: GradCelsius (float)
# Ausgabe: Fahrenheit (float)

def TemperaturKonverter(GradCelsius: float) -> float:
    return (GradCelsius * (9/5)) + 32

check(TemperaturKonverter(20), 68)
check(TemperaturKonverter(26), 78.8)
check(TemperaturKonverter(42), 107.6)
check(TemperaturKonverter(16), 60.8)