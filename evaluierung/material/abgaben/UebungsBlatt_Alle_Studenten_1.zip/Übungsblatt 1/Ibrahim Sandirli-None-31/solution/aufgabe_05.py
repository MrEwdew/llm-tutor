from wypp import *

# Verfielfachen von Wehr (string)
# Eingabe: Wehr(string)
# Ausgabe: verfielfachter Wehr (string)


# Verfielfachung * 2

def Verfielfachung(name: str) -> str:
    return  str(name) * 2

check(Verfielfachung("Wehr"), "WehrWehr")

# Verfielfachung * 4

def VerfielfachungV2(name: str) -> str:
    return str(name) * 4

check(VerfielfachungV2("Wehr"), "Wehr" * 4)

# Verfielfachung * 12

def VerfielfachungV3(name: str) -> str:
    return str(name) * 12

check(VerfielfachungV3("Wehr"), "Wehr" * 12)

# Verfielfachung * 16

def VerfielfachungV4(name: str) -> str:
    return str(name) * 16

check(VerfielfachungV4("Wehr"), "Wehr" * 16)

