from wypp import *

# Programm zur Umrechnung von Euro zu Dollar
# Preiskurs: 1€ = 1.15$ (Stand: 11.10.2021)
# Eingabe: Euro (float)
# Ausgabe: Dollar (float)

def DollarKonverter(Euro: float) -> float:
    return Euro * 1.15


check(DollarKonverter(15), 17.25)
check(DollarKonverter(150), 172.5)
check(DollarKonverter(278), 319.7)
check(DollarKonverter(75), 86.25)