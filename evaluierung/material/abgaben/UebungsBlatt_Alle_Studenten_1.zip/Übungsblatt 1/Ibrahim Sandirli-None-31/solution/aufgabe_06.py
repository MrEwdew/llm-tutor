from wypp import *

# Berechnung der Strecke c die das Boot tatsächlich zurücklegt (float)
# Eingabe: a = 4 m(float), VBoot = 2 m/s (float), VFluss = 1.5 m/s (float)
# Ausgabe: t in s (float), Strecke c in m (float)

# Datensatz (Beispiel)

#ameter = 4
#vboot = 2
#vfluss = 1.5

# 1. Die Zeit von Strecke a ist benötigt um Strecke b zu errechnen
# dafür wird die Formel t = m/v verwendet
# Eingabe: a (float), VBoot (float)
# Ausgabe: t für a in sekunden(float)

def StreckeA(ameter: float, vboot: float) -> float:
    return ameter / vboot

check(StreckeA(4, 2), 2)

# 2. Berechung der Strecke b mit der Zeit von Strecke a und Geschwindigkeit des Flusses
# dafür wird die Formel t = m/v umgestellt sodass v*t = m
# Eingabe: t (float), vfluss (float)
# Ausgabe: Strecke b in Metern (float)

def StreckeB(t: float, vfluss: float) -> float:
    return t * vfluss

check(StreckeB(2, 1.5), 3.0)

# 3. Berechnung der Strecke c mit den Strecken Werten von a und b
# Formel wurde hier Satz des Pythagoras verwendet a**2 + b**2 = c**2
# Verwendun von math.sqrt um die Wurzel von c**2 zu ziehen
# Eingabe: a (float), b (float)
# Ausgabe: Strecke c in Metern (float)

def StreckeC(ameter: float, bmeter: float) -> float:
    return math.sqrt(ameter**2 + bmeter**2)

check(StreckeC(4, 3), 5)

# Gesamtfunktion verbinden aller kleinen Funktionen
# Eingabe: StreckeA(ameter, vboot), StreckeB(a, vfluss), StreckeC(ameter, b)
# Ausgabe: Strecke c in Metern (float)

def BootStrecke(ameter:float, vboot:float, vfluss:float) -> float:
    a = StreckeA(ameter, vboot)
    b = StreckeB(a, vfluss)
    c = StreckeC(ameter, b)
    return c

check(BootStrecke(4, 2, 1.5), 5)
check(BootStrecke(6, 3, 4), 10)

