from wypp import *

# Programm zur einfallenden Steuer für das wechseln von Euro zu Dollar
# Zusätzlich muss Der Wechselkurs anpassbar sein
# Eingabe: Steuern 10% (float), Max. Steuer 100€ (float)
# Ausgabe: Anfallende Steuern der zu wechselnden Betrages (float)

# Maximaler Batrag Euro für anfällige Steuern
x = 1000


def DollarKonverter(betrageuro: float, kursdollar: float) -> float:
    Steuer = betrageuro * 0.1
    if betrageuro <= x:
        return (betrageuro - Steuer) * kursdollar
    elif betrageuro >= x:
        return (betrageuro - 100) * kursdollar
    


check(DollarKonverter(1200, 1.15), 1265.0)
check(DollarKonverter(2300, 1.15), 2530.0)
check(DollarKonverter(600, 1.15), 621.0)
check(DollarKonverter(75, 1.15), 77.625)
        

