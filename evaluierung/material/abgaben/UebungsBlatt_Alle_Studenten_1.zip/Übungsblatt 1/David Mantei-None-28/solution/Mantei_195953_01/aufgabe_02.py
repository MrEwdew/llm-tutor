from wypp import *

#Am 11.10.2021 kostete 1 Euro 1,15 Dollar. Schreiben Sie eine Funktion, die einen Eurobetrag
#nach Dollar umrechnet.
#Eingabe: Euro in float -> float
#Ergebnis: Euro * 1,15 = Dollar in float

def EuroInDollar(Euro:float) -> float:
    return Euro * 1.15

check(EuroInDollar(10), 11.50)
check(EuroInDollar(15.44), 17.756)