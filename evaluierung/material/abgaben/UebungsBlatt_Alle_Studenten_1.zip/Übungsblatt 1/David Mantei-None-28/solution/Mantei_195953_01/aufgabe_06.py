from wypp import *

# Berechnung der Zeit, die das Boot zum Überqueren des Flusses braucht
# Eingabe: Flussbreite, Bootsgeschwindigkeit in float
# Ergebnis: Überquerungszeit in float = Flussbreite / Bootsgeschwindigkeit

def überquerungszeit(Flussbreite: float, Bootsgeschwindigkeit: float) -> float:
    return Flussbreite / Bootsgeschwindigkeit

# Berechnung der Strecke, die das Boot abgetrieben wird
# Eingabe: Zeit, Strömungsgeschwindigkeit in float
# Ergebnis: Drift in float = Strömungsgeschwindigkeit * Zeit

def driftdistanz(Zeit:float, Strömungsgeschwindigkeit:float) -> float:
    return Zeit * Strömungsgeschwindigkeit

# Berechnung der tatsächlichen Strecke mit dem Satz des Pythagoras. c=sqrt(a²+b²)
# Eingabe: Flussbreite, Drift in float
# Ergebnis: Distanz in float = sqrt(Flussbreite² + Drift²)

def distanz(Flussbreite: float, Drift:float) -> float:
    return (Flussbreite ** 2 + Drift ** 2) ** 0.5

# Vollständige Berechnung

def flussüberquerungsdistanz(Flussbreite: float, Bootsgeschwindigkeit: float, Strömungsgeschwindigkeit: float) -> float:
    Zeit = überquerungszeit(Flussbreite, Bootsgeschwindigkeit)
    Drift = driftdistanz(Zeit, Strömungsgeschwindigkeit)
    return distanz(Flussbreite, Drift)

check(überquerungszeit(4, 2), 2.0)
check(driftdistanz(2, 1.5), 3.0)
check(distanz(4, 3), 5.0)
check(flussüberquerungsdistanz(4, 2, 1.5), 5.0) 