from wypp import *

# Funktionen sollen Strings vervielfachen
# Eingabe: "eingabe" in Str
# Ergebnis: "eingabe" * x

def string2(eingabe:str) -> str:
    return eingabe * 2

def string4(eingabe:str) -> str:
    return eingabe * 4

def string12(eingabe:str) -> str:
    return eingabe * 12

def string16(eingabe:str) -> str:
    return eingabe * 16

check(string2("Wehr"), "WehrWehr")
check(string4("A "), "A A A A ")
check(string12("X"), "XXXXXXXXXXXXXXXX")
check(string16("X"), "XXXXXXXXXXXXXXXXXXXX")