from wypp import *

#Divisentauschtransaktionssteuer von 10% wird einbehalten bis die zusätzlichen Steuern
#höchstens 100€ betragen. Das heißt alles über 1000€ bleibt 100€ Steuer. 
#Außerdem ist der Dollarkurs nicht fix. 

#Eingabe: Einbezahlmenge: float, Dollarkurs: float
#Ergebnis: transaktionssteuer = einbezahlmenge * dollarkurs * 0.9 (für 10%), wenn X < 1000
#Sonst transaktionssteuer = (einbezahlmenge - 100) * dollarkurs (Weil max 100€ Steuerabgabe)

def transaktionssteuer(einbezahlmenge: float, dollarkurs: float) -> float:
    if einbezahlmenge >= 1000:
        return (einbezahlmenge - 100) * dollarkurs
    else:
        return einbezahlmenge * dollarkurs * 0.9

check(transaktionssteuer(1100, 1.15), 1165)
check(transaktionssteuer(966.66, 1.30), 1130.9922)
check(transaktionssteuer(664.50, 1.23), 735.6015)