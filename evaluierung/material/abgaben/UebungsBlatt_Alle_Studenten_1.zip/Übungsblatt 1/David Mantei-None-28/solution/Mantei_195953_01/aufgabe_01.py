from wypp import *

#Celsius wird umgerechnet in Fahrenheit
#Eingabe: Fahrenheit, Celsius in float
#Ergebnis: Fahrenheit = Celsius * 9/5 + 32 ODER Celsius * 1,8 + 32

def CelsiusInFahrenheit(celsius:float) -> float:
    return celsius * 1.8 + 32

check(CelsiusInFahrenheit(32), 89.6)
check(CelsiusInFahrenheit(40), 104)
check(CelsiusInFahrenheit(-5), 23)