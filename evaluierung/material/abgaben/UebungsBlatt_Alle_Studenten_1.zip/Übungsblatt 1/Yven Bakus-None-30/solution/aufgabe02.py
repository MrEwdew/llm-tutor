from wypp import *

# Eine Funktion bauen die den euro betrag in dollar umrechnet
# Eingabe: Euro
# Ergebnis: Dollar

def waehrungsRechner(Euro: float) -> float:
    return Euro * 1.15

check(waehrungsRechner(10), 11.5)
check(waehrungsRechner(25), 28.75)