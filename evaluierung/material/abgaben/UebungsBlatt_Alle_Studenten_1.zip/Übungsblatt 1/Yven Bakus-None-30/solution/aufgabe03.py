from wypp import *

# Divisentauschtransaktionsteuer. 10% bis zu 100 Euro abgabesteuer
# Eingabe: Euro, Dollarkurs
# Ergebnis: Dollar

def divisentauschsteuer(euro: float) -> float:
    if euro <= 1000:
        return euro * 0.9
    else: 
        return euro - 100

def euroZuDollar(euro: float , kurs: float) -> float:
    return divisentauschsteuer(euro) * kurs


check(divisentauschsteuer(999), 899.1)
check(divisentauschsteuer(1001), 901)
check(euroZuDollar(999, 1.2), 1078.92)
check(euroZuDollar(1000, 1.2), 1080)
check(euroZuDollar(1001, 1.2), 1081.2)