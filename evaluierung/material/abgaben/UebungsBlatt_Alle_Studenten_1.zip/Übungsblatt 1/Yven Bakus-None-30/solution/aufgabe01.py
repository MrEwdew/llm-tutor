from wypp import *

# Eine Funktion bauen, die einen Temperaturwert von Celsius in Fahrenheit konvertiert.
# Eingabe: Temperatur in Celsius
# Ergebnis: Temperatur in Fahrenheit


def temperaturKonverter(celsius: float) -> float:
    return celsius * (9/5) + 32 

check(temperaturKonverter(20), 68)
check(temperaturKonverter(40), 104)