from wypp import *

# Vervielfachen von strings
# Eingabe: Wehr
# Ausgabe: Wehr vervielfacht

def double(Wehr: str) -> str:
    return Wehr + Wehr

def quadruple(Wehr: str) -> str:
    return double(double(Wehr))

def duodecuple(Wehr: str) -> str:
    return quadruple(Wehr) * 3

def sexdecuple(Wehr: str) -> str:
    return quadruple(quadruple(Wehr))


check(double("Wehr"), "WehrWehr")
check(quadruple("Wehr"), "WehrWehrWehrWehr")
check(duodecuple("Wehr"), "WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr")
check(sexdecuple("Wehr"), "WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr")