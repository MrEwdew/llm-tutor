from wypp import *
from math import *
# Berechnung der Länge c die das boot tatsächlich zurückgelegt hat
# Eingabe: a und b
# Ergebnis: c

def berechneteStrecke(a: float, v_boot: float, v_fluss: float) -> float:
    t = berechneteZeit(a, v_boot)
    b = berechneteAbtreibung(t, v_fluss)
    return math.sqrt(a**2 + b**2)


def berechneteZeit(a: float, v_boot: float) -> float:
    return a / v_boot


def berechneteAbtreibung(t: float, v_fluss: float) -> float:
    return t * v_fluss


check(berechneteStrecke(4, 2 , 1.5), 5)
check(berechneteZeit(4, 2), 2)
check(berechneteAbtreibung(2, 1.5), 3)


