from wypp import*

#berechnug der Zeit (Flussbreite/Geschwind.)
#Eingabe:Flussbreite(float) Geschwindigkeit(flaot)
#Ergebnis:Zeit(flaot)

def Zeit(Flussbreite:float,Geschwindigkeit:float)-> float:
    return Flussbreite/Geschwindigkeit

check(Zeit(10,5),2)
check(Zeit(20,5),4)

#berechnug der Drift(B)=(Zeit*Flussgeschwindigkeit)
#Eingabe:Flussgeschwindigkeit(float) Zeit(float)
#Ergebnis:Drift länge (B) (float)

def Drift(Flussgeschwindigkeit:float,Zeit:float)->float:
    return Zeit*Flussgeschwindigkeit

check(Drift(20,15),300)
check(Drift(5,10),50)

#berechnug der echte Strecke(C)=(Flussbreite^2 + Drift^2)
#Eingabe:Drift(float) Flussbreite(float)
#Ergebnis: echte länge der Strecke (C) (float)

def echteStrecke(Drift:float,Flussbreite:float)->float:
    return (Drift**2 + Flussbreite**2)**0.5

check(echteStrecke(5,10),11.180339887498949)
check(echteStrecke(20,25),32.01562118716424)
check(echteStrecke(4,3),5)

# zusammenfassung der Funktionen


def StreckeC(Flussbreite:float,Geschwindigkeit:float,Flussgeschwindigkeit:float)->float:
    T=Zeit(Flussbreite,Geschwindigkeit)
    B=Drift(Flussgeschwindigkeit,T)
    return echteStrecke(B,Flussbreite)

check(StreckeC(4,10,3),4.17612260356422)
check(StreckeC(5,5,5),7.0710678118654755)
check(StreckeC(4,2,1.5),5)