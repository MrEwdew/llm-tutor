from wypp import*

#Eurobetrag nach Dollar umrechnet
# 1 Euro 1,15 Dollar
# Euro in doller = 1.15
# Eingabe : Euro 
# Ergebnis : Doller
def Dollar(Euro:float)->float:
    return Euro*1.15

check(Dollar(5),5.75)
check(Dollar(745),856.75)