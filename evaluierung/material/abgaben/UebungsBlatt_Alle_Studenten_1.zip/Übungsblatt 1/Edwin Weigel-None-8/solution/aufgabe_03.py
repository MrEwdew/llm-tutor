from wypp import *
# Dollarkurs die Menge an Dollar berechnet
#einen Eurobetrag erhält.
#Dollarkurs nicht fix 
#10% jedoch höchstens 100 Euro
def DollarSteuer(EuroMenge:float,Kurs:float)->float:
    if EuroMenge>=1000:
        return (EuroMenge-100)*Kurs
    else:
        return (EuroMenge*0.9)*Kurs

check(DollarSteuer(200,1.08),194.4)
check(DollarSteuer(50,1.15),51.75)
check(DollarSteuer(5000,1.13),5537)
check(DollarSteuer(6000,3.2),18880)