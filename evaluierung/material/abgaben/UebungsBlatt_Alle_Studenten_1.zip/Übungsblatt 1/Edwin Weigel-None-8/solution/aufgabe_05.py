from wypp import*
# a)
#verdopplung bei eingabe Wehr zu WehrWehr (str)
#Eingabe Wehr 
#Ergebnis= WehrWehr

def verdoppeln(s: str) -> str :
    return s * 2

check(verdoppeln("Wehr"),"WehrWehr")
check(verdoppeln("Hallo"),"HalloHallo")
check(verdoppeln("Salam"),"SalamSalam")

# b)
#vervierfachung bei eingabe Wehr zu WehrWehrWehrWehr
#Eingabe Wehr 
#Ergebnis= WehrWehrWehrWehr


def vervierfachung(s: str) -> str :
    return s * 4

check(vervierfachung("Wehr"),"WehrWehrWehrWehr")
check(vervierfachung("ABC"),"ABCABCABCABC")
check(vervierfachung("123"),"123123123123")

# c)
#verzwlöffachung bei eingabe Wehr zu WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr
#Eingabe Wehr 
#Ergebnis= WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr

def verzwlöffachung(s: str)-> str:
    return s * 12

check(verzwlöffachung("Wehr"),"WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr")
check(verzwlöffachung("123"),"123123123123123123123123123123123123")

# d)

#versechzehnfachung bei eingabe Wehr zu WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr
#Eingabe Wehr 
#Ergebnis= WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr

def versechzehnfachung(s:str)->str:
    return s * 16

check(versechzehnfachung("Wehr"),"WehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehrWehr")
check(versechzehnfachung("ABC"),"ABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABC")
check(versechzehnfachung("123"),"123123123123123123123123123123123123123123123123")