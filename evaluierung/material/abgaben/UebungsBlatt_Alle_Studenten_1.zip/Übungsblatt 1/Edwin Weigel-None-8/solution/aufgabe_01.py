from wypp import*

# Temperaturwert in Celcius nach Fahrenheit konvertiert.
#F = (°C × 9/5) + 32
# Eingabe: Celcius und Fahrenhei (float)
#Ergebnis: Celcius zu Fahrenhei

def Fahrenheit(Celcius: float)->float:
    return Celcius*9/5+32

check (Fahrenheit(12),53.6)
