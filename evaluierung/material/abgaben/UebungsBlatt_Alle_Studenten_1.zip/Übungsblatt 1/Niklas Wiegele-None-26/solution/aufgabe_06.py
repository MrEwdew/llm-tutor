from wypp import *
from math import sqrt

# Beschreibung: Gesamtproblem: Ein Fluss ist A Meter Breit und wird von einem Boot mit der Geschwindigkeit vBoot überquert.
#Dabei wird das Boot abgetrieben mit der Strömungsgeschwindigkeit vFluss.
# Uns interessiert welche Strecke das Boot tatsächlich zurückgelegt hat, wenn es den Fluss überqueert hat.

#Input: 
# -Breite des Flusses in Meter (float)
# -Geschwindigkeit Boot in m/s (float)
# Strömungsgeschwindigkeit in m/s (float)

#Output:
# Zurückgelegte Strecke in Meter


def GesamtStrecke(breite: float, vBoot: float, vFluss: float ) -> float:
    time = ZeitBerechnung(breite, vBoot)
    streckeB = BerechnungB(time, vFluss)
    gesamtStrecke = BerechnungC(breite, streckeB)
    return gesamtStrecke




#Beschreibung: rechnet die Zeit aus, die das Boot für die Überqueerung braucht
#Input: 
# -Breite des Flusses in Meter (float)
# -Geschwindigkeit Boot in m/s (float)
#Output: Zeit der Überqueerung in Sekunden (float)
def ZeitBerechnung(breite: float, vBoot: float) -> float:
    return breite/vBoot

check(ZeitBerechnung(4, 2), 2)
check(ZeitBerechnung(100, 10), 10)

#Beschreibung: Mithilfe der Ausgerechneten Überquerungszeit und der Strömungsgeschwindigkeit berechnen wir B / die abgetriebene Strecke 
#Input:
# - Zeit der Überqueerung in Sekunden / time (float)
# -Geschwindigkeit Fluss in m/s / vFluss (float)
 
#Output: Abgetriebene Strecke / B in Meter (float)
def BerechnungB(time:float, vFluss:float) -> float:
    return time * vFluss


check(BerechnungB(2,1.5), 3)
check(BerechnungB(10,5), 50)


#Beschreibung: Berechnet mit dem Satz des Pythagoras die Gesamtstrecke C
#Input: 
# - Breite des Flusses in Meter (float)
# - Abgetriebene Strecke in Meter / hoehe (float)
#Output: Gesamtstrecke C (float)
def BerechnungC(breite: float, hoehe: float ) -> float:
    return sqrt(breite ** 2 + hoehe ** 2)

check(BerechnungC(1, 1), sqrt(2))
check(BerechnungC(50, 20), 53.8516480713)

# Checks der Gesamtfunktion GesamtStrecke
check(GesamtStrecke(4,2,1.5),5)
check(GesamtStrecke(30, 3, 4), 50)