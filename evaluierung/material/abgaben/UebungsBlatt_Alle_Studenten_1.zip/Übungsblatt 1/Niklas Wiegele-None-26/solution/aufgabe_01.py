from wypp import *

#Beschreibung:Es soll eine Funktion erstellt werden, die einen Gegebenen Temperaturwert in Celsius nach Fahrenheit konvertiert.
#Input: Temperatur in Celsius (float)
#Output: Temperatur in Fahrenheit (float)

def ConvertToFahrenheit(temperatur: float) -> float:
    return temperatur * 9/5 + 32


# -40°F =  -40°C
check(ConvertToFahrenheit(-40), -40)
# 32°F =  0°C
check(ConvertToFahrenheit(0), 32)