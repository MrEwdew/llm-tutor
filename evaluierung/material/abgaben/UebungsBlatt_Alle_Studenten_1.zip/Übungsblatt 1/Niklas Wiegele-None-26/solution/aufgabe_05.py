from wypp import *

#Beschreibung:  Eine Funktion welche die gegebene Zeichenkette vervielfacht und an die als neue Zeichenkette ausgibt
# Alle Teilaufgaben kombiniert durch einen zusätzlichen Parameter
#Input: Vervielfachungsfaktor (int) , Zeichenkette (string)
#Output: Zeichenkette mit x Zeichenketten angehängt, wobei x der Vervielfachungsfaktor ist (string)

def StringVervielfachung(faktor: int, text: str) -> str:
    outputtext = ""
    for i in range(faktor):
        outputtext += text
    return outputtext


check(StringVervielfachung(1, "Hallo"), "Hallo")
check(StringVervielfachung(2, "Hallo"), "HalloHallo")
check(StringVervielfachung(4, "Hallo"), "HalloHalloHalloHallo")
check(StringVervielfachung(8, "Hallo"), "HalloHalloHalloHalloHalloHalloHalloHallo")
check(StringVervielfachung(16, "Hallo"), "HalloHalloHalloHalloHalloHalloHalloHalloHalloHalloHalloHalloHalloHalloHalloHallo")