from wypp import *

#Beschreibung: Eine Funktion soll einen Eurobetrag in Dollar umwandeln mit einem variablen Kurs. Dabei wird 10% der Eingabe einbehalten, jedoch hächstens 100€
#Input: 
# - Geldbetrag in Euro (float)
# - Wechselkurs von Euro in Dollar (float)
#Output: Geldbetrag in Dollar (float)

def ConvertToDollarWithTax(amount:float, kurs: (float)) -> float:
    if 0.1 * amount >= 100:
        return kurs * (amount - 100)
    else:
        return kurs * (amount - 0.1* amount)


check(ConvertToDollarWithTax(2000, 1.15),2185)
check(ConvertToDollarWithTax(200, 1.15),207)