from wypp import *

#Beschreibung: Eine Funktion soll Euro nach Dollar umrechnen mit dem Wechselkurs : 1€ = 1,15$
#Input: Geldbetrag in Euro mit Centbeträgen als Nachkommastelle (float)
#Output: Geldbetrag in Dollar mit Centbeträgen als Nachkommastelle (float), bei einem negativen Input wird 0 zurück gegeben.

def ConvertToDollar(amount: float) -> float:
    if amount <= 0:
        return 0
    return amount * 1.15


check(ConvertToDollar(1), 1.15)
check(ConvertToDollar(10),11.5)
check(ConvertToDollar(-10), 0)
