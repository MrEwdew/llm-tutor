from wypp import*




# Aufgabe 4a
# Modelliert Lebensmittel mit unterschiedlichen Angaben zum Zuckergehalt.
# Datenanalyse:
# Ein Lebensmittel besteht aus:
# - Name (str)
# - positive Packungsgröße in Gramm (int)
# - Zuckergehalt in einer von drei Formen:
#   1. Fruktose und Glukose für die gesamte Packung (je float)
#   2. Zucker in Gramm pro 100 Gramm Lebensmittel (float)
#   3. Ampelfarbe: 'grün', 'gelb' oder 'rot' (str)

@record
class FruktoseGlukose:
    fruktose: float
    glukose: float



Zuckergehalt = Union[FruktoseGlukose, float, str]


@record
class Lebensmittel:
    name: str
    packungsgroesse: int
    zuckergehalt: Zuckergehalt



cocaCola = Lebensmittel(
    'Coca Cola', 500, FruktoseGlukose(25.0, 25.0)
)

ritterSport = Lebensmittel(
    'Ritter Sport himmlische Beere',
    100,
    FruktoseGlukose(15.29, 24.9)
)

kuerbis = Lebensmittel('Kürbis', 1000, 2.8)

gurke = Lebensmittel('Gurke', 470, 'grün')


# Aufgabe 4b – Hilfsfunktion
# Berechnet aus Fruktose und Glukose den Zucker pro 100 Gramm.
# Eingabe: Zucker für die gesamte Packung (FruktoseGlukose),
#          positive Packungsgröße in Gramm (int)
# Ergebnis: Zucker in Gramm pro 100 Gramm Lebensmittel (float)

def ZuckerPro100g(zucker: FruktoseGlukose, packungsgroesse: int) -> float:
    # Record-Schablone: Fruktose und Glukose auswerten.
    return (zucker.fruktose + zucker.glukose) / packungsgroesse * 100


check(ZuckerPro100g(FruktoseGlukose(25.0, 25.0), 500), 10.0)
check(ZuckerPro100g(FruktoseGlukose(10.0, 12.5), 100), 22.5)


# Berechnet die Zuckerampel eines Lebensmittels.
# Eingabe: Lebensmittel (Lebensmittel)
# Ergebnis: Ampelfarbe 'grün', 'gelb' oder 'rot' (str)
# Grenzen für Zucker pro 100 Gramm:
# - unter 5 Gramm: grün
# - 5 bis einschließlich 22,5 Gramm: gelb
# - über 22,5 Gramm: rot

def Zuckerampel(lebensmittel: Lebensmittel) -> str:
    zucker = lebensmittel.zuckergehalt

    
    if isinstance(zucker, str):
        return zucker
    elif isinstance(zucker, FruktoseGlukose):
        pro100g = ZuckerPro100g(zucker, lebensmittel.packungsgroesse)
    else:
        pro100g = zucker

    
    if pro100g < 5:
        return 'grün'
    elif pro100g <= 22.5:
        return 'gelb'
    else:
        return 'rot'

check(Zuckerampel(cocaCola), 'gelb')
check(Zuckerampel(ritterSport), 'rot')
check(Zuckerampel(kuerbis), 'grün')
check(Zuckerampel(gurke), 'grün')