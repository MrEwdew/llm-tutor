from wypp import*
# Aufgabe 3a 
# Eine Adresse besteht aus :  Namen (str),Straße plus Hausnummer(str), einem Zusatz der leer
# sein kann(str), Postleitzahl(str weil es mit 0 beginnen kann),Stadt(str) und Land(str).
# Ein Name besteht aus Vor- und Nachname

@record
class Name:
    vorname: str
    nachname:str

@record
class Adresse:
    name:Name
    strasseHausNr:str
    zusatz: str
    postleitzahl:str
    stadt: str
    land:str

#3b
# Ändert den Nachnamen in einer Adresse.
# Eingabe: Adresse (Adresse), neuer Nachname (str)
# Ergebnis: Adresse mit geändertem Nachnamen (Adresse)

def NameaAendern(adresse:Adresse,neuerNachname:str) -> Adresse:
    return Adresse(Name(adresse.name.vorname,neuerNachname),
                        adresse.strasseHausNr,adresse.zusatz,adresse.postleitzahl,adresse.stadt,
                        adresse.land)



check(NameaAendern(Adresse(Name('Thomas' ,'Müller'),'Okenstrasse 2','','77694','Kehl','Deutschland'),'Peter')
,Adresse(Name('Thomas','Peter'),'Okenstrasse 2','','77694','Kehl','Deutschland'))
check(NameaAendern(Adresse(Name('Yuri' ,'Gagarin'),'Milchstrasse 1','Im Weltall','0000','Weltraum','?'),'Boyka')
,Adresse(Name('Yuri','Boyka'),'Milchstrasse 1','Im Weltall','0000','Weltraum','?'))

#Aufgabe 3c 
#Adresse für einen Briefumschlag formatiert
# Eingabe: Adresse (Adresse)
# Ergebnis: formatierte Adresse (str)

def AdresseFormatieren(adresse:Adresse )-> str:
    if adresse.zusatz=='':
        return(adresse.name.vorname + ' ' +adresse.name.nachname + '\n'
               +adresse.strasseHausNr +'\n'
               +adresse.postleitzahl +' '+ adresse.stadt + '\n'
               +adresse.land)
    else:
        return (adresse.name.vorname + ' ' + adresse.name.nachname + '\n'
            + adresse.strasseHausNr + '\n'
            + adresse.zusatz + '\n'
            + adresse.postleitzahl + ' ' + adresse.stadt + '\n'
            + adresse.land)

check(AdresseFormatieren(Adresse(Name('Thomas','Peter'),'Okenstrasse 2','','77694','Kehl','Deutschland'))
,'Thomas Peter\nOkenstrasse 2\n77694 Kehl\nDeutschland')

check(AdresseFormatieren(Adresse(Name('Thomas','Peter'),'Okenstrasse 2','3.Stock','77694','Kehl','Deutschland'))
,'Thomas Peter\nOkenstrasse 2\n3.Stock\n77694 Kehl\nDeutschland')