from wypp import*

type schadstoffklasse=Literal[1,2,3,4,5,6]
# Prüft ob ein Auto in die Stadt einfahren darf.
# Eingabe: Maut bezahlt (bool), Sondergenehmigung (bool), Schadstoffklasse von 1-6 (int)
# Ergebnis: Einfahrt erlaubt (bool)
#Regeln: 
# -Maut nicht bezhalt = Sondergenehmigung.
# -Schadstoffklasse 1-4  = Sondergenehmigung + Maut 
@record
class MautKriterien:
    bezahlt: bool
    sondergenehmigung : bool
    schadstoffklasse : int

def EinfahrtErlaubt(kriterien:MautKriterien)-> bool:
    if kriterien.schadstoffklasse == 5 or kriterien.schadstoffklasse==6:
        return kriterien.bezahlt or kriterien.sondergenehmigung
    else:
        return kriterien.bezahlt and kriterien.sondergenehmigung

check(EinfahrtErlaubt(MautKriterien(False,True,6)),True)
check(EinfahrtErlaubt(MautKriterien(False,True,2)),False)
check(EinfahrtErlaubt(MautKriterien(True,True,6)),True)
check(EinfahrtErlaubt(MautKriterien(False,False,1)),False)
check(EinfahrtErlaubt(MautKriterien(True, False, 4)), False)
check(EinfahrtErlaubt(MautKriterien(True, False, 6)), True)