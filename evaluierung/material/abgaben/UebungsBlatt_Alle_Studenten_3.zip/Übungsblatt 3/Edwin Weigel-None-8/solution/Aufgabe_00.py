from wypp import*
print('Salam')
#Eingabe:Stunde (int) und Minute (int)
#Ergebnis: Anzahl vergangener Sekunden seit Mitternacht

@record
class Uhrzeit:
    stunden: int
    minuten: int

def sekSeitMn(u: Uhrzeit)-> int|str:
    if u.stunden <24 and u.minuten < 60 :
        StudenInSek= u.stunden*3600
        MinutenInSek= u.minuten*60
        return StudenInSek + MinutenInSek
    else:
        return 'NO'



check(sekSeitMn(Uhrzeit(10,10)), 36600)
check(sekSeitMn(Uhrzeit(25,66)),'NO')
check(sekSeitMn(Uhrzeit(14,19)), 51540)