#Aufgabe 1a
from wypp import*

#Ein Com. zusammenstellen
#Ein Com. besteht aus (CPU str, Ram int, Festplatte int, Erweiterungen str,
@record
class Comp:
    Cpu:str
    Ram:int
    Festplatte: int
    Erweiterungen : str

#Eingabe: Ram in gb (int)
#Ergebnis: Preis (int)

def Rampreis(Ram: int) -> int:
    if Ram * 5 < 30:
        return 30
    else:
        return Ram * 5


check(Rampreis(16),80)

def FestplattePreis(Festplatte:int)->int:
    Festplattengröße=(Festplatte +499)//500
    return Festplattengröße * 20
    

check(FestplattePreis(500),20)
check(FestplattePreis(501),40)
check(FestplattePreis(1000),40)
check(FestplattePreis(1001),60)
check(FestplattePreis(9999),400)

#Eingabe: Cpu (str)
#Ergebnis: Preis

def CpuPreis(Cpu:str)-> int:
    if Cpu in ('intel'):
        return 90+20
    else: 
        return 90

check(CpuPreis('intel'),110)
check(CpuPreis('AMD'),90)

#Eingabe: Erweiterung (str)
#Ergebnis: Preis 100E (int)

def ErweiterungPreis()->int:
    return 100
 

check(ErweiterungPreis(),100)

#Gesamtpreis des Comp. 
#Eingabe: Funktionen
#Ergebnis: Preis

def GesamtpreisPc(computer:Comp)-> int:
    return CpuPreis(computer.Cpu)+ Rampreis(computer.Ram) + FestplattePreis(computer.Festplatte)+100

check(GesamtpreisPc(Comp('intel',16,500,'')),310)
check(GesamtpreisPc(Comp('AMD',18,502,'')),320)
check(GesamtpreisPc(Comp('intel',24,1002,'')),390)
check(GesamtpreisPc(Comp('AMD',55,5000,'')),665)

#Aufgabe 1b

# Erweitert den RAM eines Computers, ohne ihn zu verkleinern.
# Eingabe: computer (Comp), zusätzliche Speichermenge in GB (int)
# Ergebnis: Computer mit erweitertem RAM (Comp)

def RamErweitern(computer: Comp, zusätzlich: int) -> Comp:
    if zusätzlich > 0:
        return Comp(computer.Cpu, computer.Ram + zusätzlich , computer.Festplatte, computer.Erweiterungen)
    else:
        return computer

check(RamErweitern(Comp('intel', 16, 500, ''), 8),Comp('intel', 24, 500, ''),)




check(RamErweitern(Comp('AMD',8,100,''),16),Comp('AMD',24,100,''),)