from wypp import *


# (a) Datenbeschreibung und Typdefinition

# Zucker in Gramm bezogen auf die gesamte Packung.
@record
class ZuckerAufgeteilt:
    fruktose: float
    glukose: float


# Zucker in Gramm pro 100 g Lebensmittel.
@record
class ZuckerPro100g:
    menge: float


# Eine Ampelfarbe ist "grün", "gelb" oder "rot".
type Ampelfarbe = Literal["grün", "gelb", "rot"]


# Der Zuckergehalt kann auf drei Arten angegeben werden.
type Zuckergehalt = Union[ZuckerAufgeteilt , ZuckerPro100g , Ampelfarbe]


# Ein Lebensmittel hat einen Namen, eine Packungsgröße in Gramm
# und einen Zuckergehalt.
@record
class Lebensmittel:
    name: str
    packungsgroesse: float
    zuckergehalt: Zuckergehalt


# Beispiele aus der Aufgabe

cola = Lebensmittel(
    "Coca Cola",
    500.0,
    ZuckerAufgeteilt(25.0, 25.0)
)

schokolade = Lebensmittel(
    "Ritter Sport himmlische Beere",
    100.0,
    ZuckerAufgeteilt(15.29, 24.9)
)

kuerbis = Lebensmittel(
    "Kürbis",
    1000.0,
    ZuckerPro100g(2.8)
)

gurke = Lebensmittel(
    "Gurke",
    470.0,
    "grün"
)


# (b) Hilfsfunktion
# Eingabe: Aufgeteilter Zucker und Packungsgröße in Gramm
# Ausgabe: Gesamtzucker pro 100 g
# Voraussetzung: packungsgroesse > 0

def zuckerPro100g(zucker: ZuckerAufgeteilt,
                  packungsgroesse: float) -> float:
    gesamtzucker = zucker.fruktose + zucker.glukose
    return gesamtzucker / packungsgroesse * 100


# Hilfsfunktion für die Einteilung nach Zucker pro 100 g.
# Genau 5 g und genau 22,5 g zählen zu Gelb.

def farbeFuerZucker(menge: float) -> Ampelfarbe:
    if menge < 5:
        return "grün"
    elif menge <= 22.5:
        return "gelb"
    else:
        return "rot"


# Eingabe: Lebensmittel
# Ausgabe: Ampelfarbe des Lebensmittels

def ampel(lebensmittel: Lebensmittel) -> Ampelfarbe:
    zucker = lebensmittel.zuckergehalt

    if isinstance(zucker, ZuckerAufgeteilt):
        menge = zuckerPro100g(zucker, lebensmittel.packungsgroesse)
        return farbeFuerZucker(menge)

    elif isinstance(zucker, ZuckerPro100g):
        return farbeFuerZucker(zucker.menge)

    else:
        # Der Zuckergehalt ist bereits eine Ampelfarbe.
        return zucker




check(zuckerPro100g(ZuckerAufgeteilt(25.0, 25.0), 500.0), 10.0)




check(farbeFuerZucker(4.9), "grün")
check(farbeFuerZucker(5.0), "gelb")
check(farbeFuerZucker(22.5), "gelb")
check(farbeFuerZucker(22.6), "rot")




check(ampel(cola), "gelb")
check(ampel(schokolade), "rot")
check(ampel(kuerbis), "grün")
check(ampel(gurke), "grün")