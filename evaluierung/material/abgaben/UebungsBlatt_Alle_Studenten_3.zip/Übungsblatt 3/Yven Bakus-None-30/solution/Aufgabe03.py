from wypp import *


# (a) Datenbeschreibung und Typdefinition

# Ein Name besteht aus einem Vornamen und einem Nachnamen.
@record
class Name:
    vorname: str
    nachname: str


# Eine Adresse besteht aus einem Namen, einer Straße mit Hausnummer,
# einem Zusatz, einer Postleitzahl, einer Stadt und einem Land.
# Der Zusatz kann leer sein.
@record
class Adresse:
    name: Name
    strasse: str
    zusatz: str
    postleitzahl: str
    stadt: str
    land: str


# (b) Nachnamen ändern
# Eingabe: Adresse und neuer Nachname
# Ausgabe: Neue Adresse mit geändertem Nachnamen

def nachnameAendern(adresse: Adresse, neuerNachname: str) -> Adresse:
    return Adresse(
        Name(adresse.name.vorname, neuerNachname),
        adresse.strasse,
        adresse.zusatz,
        adresse.postleitzahl,
        adresse.stadt,
        adresse.land
    )


# (c) Adresse formatieren
# Eingabe: Adresse
# Ausgabe: Adresse als Text in einer Zeile

def adresseFormatieren(adresse: Adresse) -> str:
    name = adresse.name.vorname + " " + adresse.name.nachname
    ort = adresse.postleitzahl + " " + adresse.stadt

    if adresse.zusatz == "":
        return (name + ", "
                + adresse.strasse + ", "
                + ort + ", "
                + adresse.land)
    else:
        return (name + ", "
                + adresse.zusatz + ", "
                + adresse.strasse + ", "
                + ort + ", "
                + adresse.land)




adresse1 = Adresse(
    Name("Edwin", "Weigel"),
    "Unterer Weiher 10",
    "",
    "79098",
    "Freiburg",
    "Deutschland"
)

adresse2 = Adresse(
    Name("Max", "Mustermann"),
    "Musterstraße 5",
    "Wohnung 3",
    "77652",
    "Offenburg",
    "Deutschland"
)




check(
    nachnameAendern(adresse1, "Müller"),
    Adresse(
        Name("Edwin", "Müller"),
        "Unterer Weiher 10",
        "",
        "79098",
        "Freiburg",
        "Deutschland"
    )
)



check(
    adresseFormatieren(adresse1),
    "Edwin Weigel, Unterer Weiher 10, 79098 Freiburg, Deutschland"
)

check(
    adresseFormatieren(adresse2),
    "Max Mustermann, Wohnung 3, Musterstraße 5, 77652 Offenburg, Deutschland"
)