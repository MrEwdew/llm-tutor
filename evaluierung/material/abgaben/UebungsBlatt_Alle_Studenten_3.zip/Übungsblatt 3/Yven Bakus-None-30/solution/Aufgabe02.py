from wypp import *

# Eine Schadstoffklasse ist eine der Zahlen 1 bis 6.
# Die Klassen 1 bis 4 werden bei der Maut gleich behandelt.
type Schadstoffklasse = Literal[1, 2, 3, 4, 5, 6]


# Die Maut-Kriterien bestehen aus:
# - bezahlt: Wurde die Maut bezahlt?
# - sondergenehmigung: Liegt eine Sondergenehmigung vor?
# - schadstoffklasse: Welche Schadstoffklasse hat das Auto?

@record
class MautKriterien:
    bezahlt: bool
    sondergenehmigung: bool
    schadstoffklasse: Schadstoffklasse


# Eingabe: Maut-Kriterien eines Autos
# Ausgabe: True, wenn die Einfahrt erlaubt ist; sonst False

def mautGenehmigung(k: MautKriterien) -> bool:
    if k.schadstoffklasse == 5 or k.schadstoffklasse == 6:
        # Bei Klasse 5 und 6 reicht eine der beiden Bedingungen.
        return k.bezahlt or k.sondergenehmigung
    else:
        # Bei Klasse 1 bis 4 müssen beide Bedingungen erfüllt sein.
        return k.bezahlt and k.sondergenehmigung


# Tests für Schadstoffklasse 5 und 6

check(mautGenehmigung(MautKriterien(True, False, 5)), True)
check(mautGenehmigung(MautKriterien(True, False, 6)), True)
check(mautGenehmigung(MautKriterien(False, True, 5)), True)
check(mautGenehmigung(MautKriterien(False, True, 6)), True)
check(mautGenehmigung(MautKriterien(False, False, 5)), False)
check(mautGenehmigung(MautKriterien(False, False, 6)), False)


# Tests für Schadstoffklasse 1 bis 4

check(mautGenehmigung(MautKriterien(True, True, 1)), True)
check(mautGenehmigung(MautKriterien(True, True, 4)), True)
check(mautGenehmigung(MautKriterien(False, True, 3)), False)
check(mautGenehmigung(MautKriterien(True, False, 2)), False)
check(mautGenehmigung(MautKriterien(False, False, 1)), False)