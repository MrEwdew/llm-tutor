from wypp import *

# Computer Modelle zusammenstellen
# Computer Besteht aus:
# CPU (str)
# RAM (int)
# Festplatte (int)



@record
class Computer:
    cpu: str
    ram: int
    festplatte: int
    komponenten: str

# Eingabe: Ram in Gb (int)
# Ausgabe: Ram kosten (int)


def ramKosten(ram: int) -> int:
    if ram > 0:
        return 30 + (ram * 5)
    
check(ramKosten(16), 110)


# Eingabe: Festplattengroesse in GB (int)
# Ausgabe: Kosten für Festplatte in Euro (int)
from math import *

def festplattenKosten(Festplatte: int) -> int:
   festplattengroesse = (Festplatte + 499) // 500
   return festplattengroesse * 20
    
        

check(festplattenKosten(500), 20)
check(festplattenKosten(501), 40)
check(festplattenKosten(1000), 40)
check(festplattenKosten(1001), 60)
check(festplattenKosten(7777), 320)

# Eingabe: CPU (str)
# Ausgabe: Kosten der CPU (int)

def cpuKosten(CPU: str) ->int:
    if CPU in ("Intel"):
        return 90 + 20
    else:
        return 90

check(cpuKosten("Intel"), 110)
check(cpuKosten("AMD Ryzen 9"), 90)

# Eingabe: Beliebig viele Komponente (str)
# Ausgabe: 100 Euro Pauschale a komponente

def weitereKomponentenKosten(komponenten: str) -> int:
    if komponenten == "":
        return 0
    else:
        return (komponenten.count(",") + 1) * 100


check(weitereKomponentenKosten("dvdLesegerät"), 100)
check(weitereKomponentenKosten("dvdLesegerät, GPU"), 200)
check(weitereKomponentenKosten("dvdLesegerät, GPU, Wasserkühlung"), 300)



# Eingabe: Computer und weitere Komponenten als Text
# Ausgabe: Gesamtkosten in Euro


def computerKosten(computer: Computer) -> int:
    return (cpuKosten(computer.cpu)
            + ramKosten(computer.ram)
            + festplattenKosten(computer.festplatte)
            + weitereKomponentenKosten(computer.komponenten))


pc1 = Computer(cpu="Intel", ram=16, festplatte=1001, komponenten="dvdPlayer")

check(pc1.cpu, "Intel")
check(pc1.ram, 16)
check(pc1.festplatte, 1001)
check(pc1.komponenten, "dvdPlayer")

check(computerKosten(pc1), 380)


# Aufgabe b)
# Eingabe: Computer und zusätzliche RAM-Menge in GB
# Ausgabe: Computer mit erweitertem RAM



def RAMerweitern(computer: Computer, erweiterung: int) -> Computer:
    if erweiterung >= 0:
        return Computer(
            computer.cpu,
            computer.ram + erweiterung,
            computer.festplatte,
            computer.komponenten
        )
    else:
        return computer

pc = Computer("Intel", 16, 1001, "dvdPlayer")

check(RAMerweitern(pc, 8), Computer("Intel", 24, 1001, "dvdPlayer"))

check(RAMerweitern(pc, -8), Computer("Intel", 16, 1001, "dvdPlayer"))

check(RAMerweitern(pc, 0), Computer("Intel", 16, 1001, "dvdPlayer"))


