from wypp import *
#Aufgabe 4


type AmpelFarbe = Literal['grün', 'gelb', 'rot'] 

@record
class ZuckerAufgeteilt:
    fruktose: float
    glukose: float

@record
class ZuckerPro100g:
    gramm: float

type ZuckerGehalt = ZuckerAufgeteilt | ZuckerPro100g | AmpelFarbe

@record
class Lebensmittel:
    name: str
    packungsgroesse: float
    zucker: ZuckerGehalt

coca_cola = Lebensmittel('Coca Cola', 500.0, ZuckerAufgeteilt(25.0, 25.0))
ritter_sport = Lebensmittel('Ritter Sport himmlische Beere', 100.0, ZuckerAufgeteilt(15.29, 24.9))
kuerbis = Lebensmittel('Kürbis', 1000.0, ZuckerPro100g(2.8))
gurke = Lebensmittel('Gurke', 470.0, 'grün')



def zucker_pro_100g(z: ZuckerAufgeteilt, packung: float) -> float:
    gesamtzucker = z.fruktose + z.glukose
    return (gesamtzucker / packung) * 100.0

check(zucker_pro_100g(ZuckerAufgeteilt(25.0, 25.0), 500.0), 10.0)




def ampel_kategorie(l: Lebensmittel) -> AmpelFarbe:
    if isinstance(l.zucker, str):
        return l.zucker
    
    if isinstance(l.zucker, ZuckerPro100g):
        wert = l.zucker.gramm
    else:
        wert = zucker_pro_100g(l.zucker, l.packungsgroesse)

    if wert < 5.0:
        return 'grün'
    elif wert <= 22.5:
        return 'gelb'
    else:
        return 'rot'

check(ampel_kategorie(Lebensmittel('Gurke', 470.0, 'grün')), 'grün')
check(ampel_kategorie(Lebensmittel('Kürbis', 1000.0, ZuckerPro100g(2.8))), 'grün')
check(ampel_kategorie(Lebensmittel('Coca Cola', 500.0, ZuckerAufgeteilt(25.0, 25.0))), 'gelb')
check(ampel_kategorie(Lebensmittel('Ritter Sport himmlische Beere', 100.0, ZuckerAufgeteilt(15.29, 24.9))), 'rot')