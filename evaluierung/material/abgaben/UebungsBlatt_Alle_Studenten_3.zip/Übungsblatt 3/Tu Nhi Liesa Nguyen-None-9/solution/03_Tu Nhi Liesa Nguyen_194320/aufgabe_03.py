from wypp import * 
#Aufgabe 3

@record
class Name:
    vorname: str
    nachname: str

@record
class Adresse:
    name: Name
    strasse: str
    hausnr: str
    zusatz: str
    plz: int
    stadt: str
    land: str

def namensaenderung(a: Adresse, nachnameneu: str) -> Adresse:
    neuer_name = Name(a.name.vorname, nachnameneu)
    return Adresse(neuer_name, a.strasse, a.hausnr, a.zusatz, a.plz, a.stadt, a.land)

check(namensaenderung(Adresse(Name('Max', 'Mustermann'), 'Hauptstr.', '12', '', 77652, 'Offenburg', 'Deutschland'), 'Müller'), Adresse(Name('Max', 'Müller'), 'Hauptstr.', '12', '', 77652, 'Offenburg', 'Deutschland'))
check(namensaenderung(Adresse(Name('Anna', 'Meier'), 'Badstr.', '5', 'Wohnung 3', 79098, 'Freiburg', 'Deutschland'), 'Schmidt'), Adresse(Name('Anna', 'Schmidt'), 'Badstr.', '5', 'Wohnung 3', 79098, 'Freiburg', 'Deutschland'))




def format_adresse(a: Adresse) -> str:
    name_str = a.name.vorname + " " + a.name.nachname
    str_nr = a.strasse + " " + a.hausnr
    ort = str(a.plz) + " " + a.stadt
    if a.zusatz != "":
        return name_str + "\n" + str_nr + "\n" + a.zusatz + "\n" + ort + "\n" + a.land
    else:
        return name_str + "\n" + str_nr + "\n" + ort + "\n" + a.land

check(format_adresse(Adresse(Name('Max', 'Mustermann'), 'Hauptstr.', '12', '', 77652, 'Offenburg', 'Deutschland')), "Max Mustermann\nHauptstr. 12\n77652 Offenburg\nDeutschland")
check(format_adresse(Adresse(Name('Anna', 'Meier'), 'Badstr.', '5', 'Wohnung 3', 79098, 'Freiburg', 'Deutschland')), "Anna Meier\nBadstr. 5\nWohnung 3\n79098 Freiburg\nDeutschland")