from wypp import *
#Aufgabe 2

#Datenbeschreibung:
#Es gibt verschiedene Schadstoffklassen für ein Auto
#1-4
#5
#6

#wurde die Maut bezahlt?
#ja/nein (bool)

#gibt es eine Sondergenehmigung?
#ja/nein (bool)

#Ohne Maut ist Einfahrt nur mit Sondergenehmigung möglich

#Wenn Schadstoffklasse = 1-4, dann nur mit Sondergenehmigung UND bezahlter Maut

#Eingabe: Schadstoffklasse, Sondergenehmigung, Maut (record)
#Ausgabe: ja/nein (bool)

type Schadstoffklasse = Literal['1-4', '5', '6']

@record 
class Maut:
    maut_bezahlt: bool
    sondergenehmigung: bool
    schadstoffklasse: Schadstoffklasse

def einfahrt(anforderung: Maut) -> bool:
    if anforderung.maut_bezahlt == False and anforderung.sondergenehmigung == True:
        return True

    if anforderung.schadstoffklasse == '1-4' and anforderung.sondergenehmigung == True and anforderung.maut_bezahlt == True:
        return True

    if anforderung.maut_bezahlt == True and anforderung.schadstoffklasse in ('5', '6'):
        return True
    
    return False

check(einfahrt(Maut(False, True, '1-4')), True)
check(einfahrt(Maut(True, True, '1-4')), True)
check(einfahrt(Maut(True, False, '5')), True)
check(einfahrt(Maut(False, False, '6')), False)