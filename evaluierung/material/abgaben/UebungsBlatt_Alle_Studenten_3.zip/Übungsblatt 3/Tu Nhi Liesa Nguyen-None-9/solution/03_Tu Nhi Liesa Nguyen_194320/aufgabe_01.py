from wypp import *

@record
class Computer:
    ram: int
    festplatte: int
    cpu: str

def preis(c: Computer) -> float:
    preis_ram = c.ram * 5
    if preis_ram < 30:
        preis_ram = 30

    anzahl_500gb = c.festplatte // 500
    if c.festplatte % 500 != 0:
        anzahl_500gb = anzahl_500gb + 1
    preis_festplatte = anzahl_500gb * 20

    preis_cpu = 90
    if 'Intel' in c.cpu:
        preis_cpu = preis_cpu + 20

    return float(preis_ram + preis_festplatte + preis_cpu + 100)

check(preis(Computer(4, 500, 'AMD Ryzen')), 240.0)
check(preis(Computer(16, 1100, 'Intel i7')), 350.0)





def ram_erweitern(c: Computer, menge: int) -> Computer:
    if menge > 0:
        neuer_ram = c.ram + menge
    else:
        neuer_ram = c.ram
    return Computer(neuer_ram, c.festplatte, c.cpu)

check(ram_erweitern(Computer(4, 500, 'AMD Ryzen'), 8), Computer(12, 500, 'AMD Ryzen'))
check(ram_erweitern(Computer(4, 500, 'AMD Ryzen'), -4), Computer(4, 500, 'AMD Ryzen'))