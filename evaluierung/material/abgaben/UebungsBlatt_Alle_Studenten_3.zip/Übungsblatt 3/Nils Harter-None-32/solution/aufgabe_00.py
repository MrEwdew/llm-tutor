from wypp import *
#Berechne für eine Uhrzeit die Sekunden seit Mitternacht 
#Eingabe: Stunde als int, Minute als int
#Ausgabe: Sekunden seit Mitternacht, als int

def sekundenSeitMitternacht(Stunde: int, Minute: int) -> int:
    return Stunde % 24 * 3600 + Minute % 60 * 60


#check(sekundenSeitMitternacht(0, 0), 0)
check(sekundenSeitMitternacht(1, 0),3600)
check(sekundenSeitMitternacht(0, 1), 60)
check(sekundenSeitMitternacht(12, 30), 45000)
check(sekundenSeitMitternacht(36, 90), 45000)
