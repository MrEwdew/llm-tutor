from wypp import *

#Name: Besteht aus Vorname und Nachname
@record 
class Name:
    vorname: str
    nachname: str

#Adresse besteht aus:
#name
#Straße und Hausnummer
#Zusatz
#Postleitzahl
#Stadt
#Land

@record 
class Adresse:
    name: Name
    strasseUndHausnummer: str
    zusatz: str
    Postleitzahl: str
    stadt: str
    land: str

#Ändert Nachnamen einer Adresse
#Eingabe: Adresse als class, neuer Nachname als str
#Ausgabe: Neue Adresse als class

def aendereNachnamen(adresse: Adresse, neuerNachname: str) -> Adresse:
    return Adresse(
        Name(adresse.name.vorname, neuerNachname),
        adresse.strasseUndHausnummer,
        adresse.zusatz,
        adresse.Postleitzahl,
        adresse.stadt,
        adresse.land
    )

testAdresse = Adresse(
    Name("Max", "Mustermann"),
    "Hauptstraße 1",
    "",
    "77654",
    "Offenburg",
    "Deutschland"
)


testAdresse2 = Adresse(
    Name("Max", "Mustermann"),
    "Hauptstraße 1",
    "Zusatz",
    "77654",
    "Offenburg",
    "Deutschland"
)

check(aendereNachnamen(testAdresse, "Mueller"), Adresse(Name("Max", "Mueller"),
    "Hauptstraße 1",
    "",
    "77654",
    "Offenburg",
    "Deutschland"))

#Formatiert die Adresse für einen Briefumschlag. Zusatzt wird nur hinzugefügt, sofern er existiert.
#Alles in einen String, mit eigener Zeile für jede Angabe. 
#Eingabe: Adresse als class Adresse
#Ausgabe: Formatiert, als string

def formatiereFuerBriefumschlag(adresse: Adresse) -> str:
    if adresse.zusatz != "":
        return (
            f"{adresse.name.vorname} {adresse.name.nachname}\n"
            f"{adresse.strasseUndHausnummer}\n"
            f"{adresse.zusatz}\n"
            f"{adresse.Postleitzahl} {adresse.stadt}\n"
            f"{adresse.land}"
        )
    else:
        return (
            f"{adresse.name.vorname} {adresse.name.nachname}\n"
            f"{adresse.strasseUndHausnummer}\n"
            f"{adresse.Postleitzahl} {adresse.stadt}\n"
            f"{adresse.land}"
        )

check(formatiereFuerBriefumschlag(testAdresse), "Max Mustermann\n"
    "Hauptstraße 1\n"
    "77654 Offenburg\n"
    "Deutschland")

check(formatiereFuerBriefumschlag(testAdresse2), "Max Mustermann\n"
    "Hauptstraße 1\n"
    "Zusatz\n"
    "77654 Offenburg\n"
    "Deutschland")