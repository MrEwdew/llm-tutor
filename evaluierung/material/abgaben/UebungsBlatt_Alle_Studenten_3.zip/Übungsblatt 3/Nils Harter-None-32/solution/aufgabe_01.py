from wypp import *
@record
class Computer:
    prozessor: str
    festplatte: int
    hauptspeicher: int

workstation = Computer('Intel i9', 1000, 16)
browsing = Computer('AMD', 250, 8)

#Berechnet den Preis eines Computers anhand der Komponenten
#Eingabe: GB arbeitsspeicher als int, GB festplatte als int, CPU als str
def computerPreis(arbeitsspeicher: int, festplatte: int, cpu: str) -> int:
    intel = False
    if("Intel" in cpu):
        intel = True
    return 30 + arbeitsspeicher * 5 + math.ceil(festplatte / 500) * 20 + 90 + 20 * intel + 100

check(computerPreis(0, 100, "AMD"), 240)
check(computerPreis(16, 1000, "AMD"), 340)
check(computerPreis(16, 1000, "Intel"), 360)

#Erhöht den Arbeitsspeicher einer Computer Konfiguration
#Eingabe: Computer Konfiguration als Computer, zusätzlicher Arbeitsspeicher als int
#Ausgabe: Neue Computer Konfiguration als Computer 
def arbeitsspeicherErweitern(c: Computer, extraArbeitsspeicher: int) -> Computer:
    if(extraArbeitsspeicher <= 0):
        return c
    return Computer(c.prozessor, c.festplatte, c.hauptspeicher + extraArbeitsspeicher)

check(arbeitsspeicherErweitern(workstation, 8), Computer('Intel i9', 1000, 24))
check(arbeitsspeicherErweitern(browsing, 6), Computer('AMD', 250, 14))
check(arbeitsspeicherErweitern(workstation, 0), workstation)
check(arbeitsspeicherErweitern(workstation, -8), workstation)