from wypp import *
#Lebensmittel:
#Name als str
#Packungsgröße als int
#Zuckergehalt als zuckergehaltangabe

#zuckergehaltangabe:
# fruktose als int und glukose als int
# gram als int
# ampel als str

@record
class FructoseUndGlukose:
    fruktose: float  # in Gramm (gesamt)
    glukose: float   # in Gramm (gesamt)

type Zuckergehaltangabe = Union[FructoseUndGlukose, float, str]

@record
class Lebensmittel:
    name: str
    packungs_groesse: int  
    zuckergehalt: Zuckergehaltangabe

#berechnet die Zuckermenge pro 100 gram
#Eingabe: Lebensmittel als class Lebensmittel
#Ausgabe: Zuckergehalt als float

def zuckerPro100g(fructoseUndGlukose: FructoseUndGlukose, packungsGroesse: float) -> float:
    return ((fructoseUndGlukose.fruktose + fructoseUndGlukose.glukose) / packungsGroesse) * 100

#Gibt an zu welcher Ampelfarbe ein Lebensmittel gehört
#Eingabe: Lebensmittel as class Lebensmittel
#Ausgabe: Farbe als string

def ampelfarbeErmitteln(lebensmittel: Lebensmittel) -> str:
    if isinstance(lebensmittel.zuckergehalt, str):
        return lebensmittel.zuckergehalt

    if (isinstance(lebensmittel.zuckergehalt, FructoseUndGlukose)):
        zuckerPro100 = zuckerPro100g(lebensmittel.zuckergehalt, lebensmittel.packungs_groesse)

    elif isinstance(lebensmittel.zuckergehalt, (int, float)):
        zuckerPro100 = lebensmittel.zuckergehalt

    if zuckerPro100 < 5:
        return "grün"

    elif zuckerPro100 <= 22.5:
        return "gelb"

    else:
        return "rot"

coca_cola = Lebensmittel(
    "Coca Cola", 
    500, 
    FructoseUndGlukose(25.0, 25.0)
)

ritter_sport = Lebensmittel(
    "Ritter Sport himmlische Beere", 
    100, 
    FructoseUndGlukose(15.29, 24.9)
)

kuerbis = Lebensmittel(
    "Kürbis", 
    1000, 
    2.8 
)

gurke = Lebensmittel(
    "Gurke", 
    470, 
    "grün"
)

check(ampelfarbeErmitteln(coca_cola), "gelb")
check(ampelfarbeErmitteln(ritter_sport),"rot")
check(ampelfarbeErmitteln(kuerbis),"grün")
check(ampelfarbeErmitteln(gurke),"grün")