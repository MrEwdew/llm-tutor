from wypp import *

# Typdefinition:
#1-4
#5
#6

type Schadstoffklasse = Literal["1-4", "5", "6"]

# Typdefinition für die Maut-Kriterien als Record
@record 
class MautKriterien:
    mautBezahlt: bool
    sondergenehmigung: bool
    schadstoffklasse: Schadstoffklasse

#Prüft ob die Einfahrt möglich ist. 
#Eingabe: kriterien als class
#Ausgabe: ob die Einfahrt möglich ist, als bool
def einfahrtMoeglich(kriterien: MautKriterien) -> bool:
    # Falls das Auto Schadstoffklasse 1-4 hat. 
    if (kriterien.schadstoffklasse == "1-4"):
        # Einfahrt bei bezahlter Maut möglich. 
        return kriterien.mautBezahlt
    else: #Bei bezahlter Maut und Sondergenehmigung möglich. 
        return kriterien.mautBezahlt and kriterien.sondergenehmigung

check(einfahrtMoeglich(MautKriterien(True, False, "1-4")), True)
check(einfahrtMoeglich(MautKriterien(False, True, "1-4")), False)
check(einfahrtMoeglich(MautKriterien(True, False, "5")), False)
check(einfahrtMoeglich(MautKriterien(True, True, "5")), True)