from wypp import *


# Die Schadstoffklasse wird mit einer Zahl von 1 bis 6 angegeben.
type Schadstoffklasse = Literal[1, 2, 3, 4, 5, 6]

# Maut-Kriterien bestehen aus:
# - bezahlter Maut (bool)
# - Sondergenehmigung (bool)
# - Schadstoffklasse (Schadstoffklasse)
@record
class MautKriterien:
    bezahlt: bool
    sondergenehmigung: bool
    schadstoffklasse: Schadstoffklasse


# Feststellen, ob ein Auto nach Offenburg einfahren darf
# Eingabe: die Maut-Kriterien
# Ergebnis: ob die Einfahrt erlaubt ist (bool)
def darfEinfahren(k: MautKriterien) -> bool:
    if k.schadstoffklasse >= 5:
        return k.bezahlt or k.sondergenehmigung
    return k.bezahlt and k.sondergenehmigung


check(darfEinfahren(MautKriterien(False, False, 5)), False)
check(darfEinfahren(MautKriterien(True, False, 5)), True)
check(darfEinfahren(MautKriterien(False, True, 5)), True)
check(darfEinfahren(MautKriterien(True, False, 4)), False)
check(darfEinfahren(MautKriterien(True, True, 1)), True)
