from wypp import *


# Ein Computer setzt sich aus diesen Angaben zusammen:
# - Prozessor (str)
# - Festplatten-Kapazität in Gigabyte (int)
# - Hauptspeicher-Kapazität in Gigabyte (int)
@record
class Computer:
    prozessor: str
    festplatte: int
    hauptspeicher: int


# Den Preis für einen Computer berechnen
# Eingabe: ein Computer
# Ergebnis: Preis in Euro (int)
def computerPreis(c: Computer) -> int:
    ramPreis = max(30, c.hauptspeicher * 5)

    anzahl = (c.festplatte + 499) // 500
    plattenPreis = anzahl * 20

    prozessorPreis = 90
    if 'Intel' in c.prozessor:
        prozessorPreis = prozessorPreis + 20
    return ramPreis + plattenPreis + prozessorPreis + 100


check(computerPreis(Computer('AMD', 500, 4)), 240)
check(computerPreis(Computer('AMD', 501, 6)), 260)
check(computerPreis(Computer('Intel i9', 1100, 16)), 350)


# Den Hauptspeicher eines Computers vergrößern
# Eingaben: ein Computer und die Erweiterung in Gigabyte (int)
# Ergebnis: ein Computer mit dem erweiterten Hauptspeicher
def erweitereHauptspeicher(c: Computer, menge: int) -> Computer:
    menge = max(0, menge)
    return Computer(c.prozessor, c.festplatte, c.hauptspeicher + menge)


check(erweitereHauptspeicher(Computer('AMD', 500, 8), 4),
      Computer('AMD', 500, 12))
check(erweitereHauptspeicher(Computer('AMD', 500, 8), -4),
      Computer('AMD', 500, 8))
