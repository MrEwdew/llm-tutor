from wypp import *


# Ein Name besteht aus:
# - Vorname (str)
# - Nachname (str)
@record
class Name:
    vorname: str
    nachname: str


# Zu einer Adresse gehören:
# - Name (Name)
# - Straße und Hausnummer (str)
# - Zusatz, eventuell leer (str)
# - Postleitzahl (str)
# - Stadt (str)
# - Land (str)
@record
class Adresse:
    name: Name
    strasseUndNummer: str
    zusatz: str
    plz: str
    stadt: str
    land: str


# Den Nachnamen in einer Adresse ersetzen
# Eingaben: eine Adresse und ein neuer Nachname (str)
# Ergebnis: die Adresse mit geändertem Nachnamen
def aendereNachname(a: Adresse, neu: str) -> Adresse:
    neuerName = Name(a.name.vorname, neu)
    return Adresse(neuerName, a.strasseUndNummer, a.zusatz,
                  a.plz, a.stadt, a.land)


# Eine Adresse für den Briefumschlag aufbereiten
# Eingabe: eine Adresse
# Ergebnis: die mehrzeilige Anschrift (str)
def briefanschrift(a: Adresse) -> str:
    zeilen = [a.name.vorname + ' ' + a.name.nachname,
              a.strasseUndNummer]
    if a.zusatz != '':
        zeilen.append(a.zusatz)
    zeilen.append(a.plz + ' ' + a.stadt)
    zeilen.append(a.land)
    return '\n'.join(zeilen)


a1 = Adresse(Name('Yven', 'Bakus'), 'Tel Aviv Straße 7',
             '', '77652', 'Offenburg', 'Deutschland')
a2 = Adresse(Name('Yven', 'Battlepass'), 'Tel Aviv Straße 7',
             '', '77652', 'Offenburg', 'Deutschland')
check(aendereNachname(a1, 'Battlepass'), a2)
check(briefanschrift(a1),
      'Yven Bakus\nTel Aviv Straße 7\n'
      '77652 Offenburg\nDeutschland')
check(briefanschrift(Adresse(Name('Ahmad', 'Wardogs'), 'Tel Aviv Straße 2', '',
                             '77652', 'Offenburg', 'Deutschland')),
      'Ahmad Wardogs\nTel Aviv Straße 2\n77652 Offenburg\nDeutschland')
