from wypp import *
import math

# Datenbeschreibung:
# Ein Computer besteht aus:
# - Prozessor (typ: str)
# - Festplatte in GB (typ: int)
# - Hauptspeicher in GB (typ: int)

# Record aus der Vorlesung
@record
class Computer:
    prozessor: str
    festplatte: int
    hauptspeicher: int

# Aufgabe 1a

# 1. Kurzbeschreibung
# Berechnet Preis vom Computer.

# 2. Datenanalyse
# Eingabe: ein Computer (Typ Computer)
# Ergebnis: Preis in Euro (int)

# 3. Kopf
def computerPreis(c: Computer) -> int:
    ram_preis = c.hauptspeicher * 5
    if ram_preis < 30:
        ram_preis = 30
        
    # Festplatte 20 Euro je angefangene 500gb
    hdd_preis = math.ceil(c.festplatte / 500) * 20
    
    # CPU 90 Euro, bei Intel 20 mehr
    cpu_preis = 90
    if 'Intel' in c.prozessor:
        cpu_preis = cpu_preis + 20
        
    # + Pauschale (100€)
    return ram_preis + hdd_preis + cpu_preis + 100

# 4. Checks
check(computerPreis(Computer('AMD', 500, 2)), 240)
check(computerPreis(Computer('Intel i7', 1100, 16)), 350)
check(computerPreis(Computer('Intel', 200, 8)), 270)

# Aufgabe 1b

# 1. Kurzbeschreibung
# Arbeitsspeicher erweitern, darf nicht kleiner werden.

# 2. Datenanalyse
# Eingabe: Computer (Computer), neuer Speicher (int)
# Ergebnis: geupgradeter Computer (Computer)

# 3. Kopf
def upgradeRAM(c: Computer, extraRam: int) -> Computer:
    if extraRam < 0:
        extraRam = 0
    return Computer(c.prozessor, c.festplatte, c.hauptspeicher + extraRam)

# 4. Checks
test_pc = Computer('AMD', 1000, 16)
check(upgradeRAM(test_pc, 16), Computer('AMD', 1000, 32))
check(upgradeRAM(test_pc, -5), Computer('AMD', 1000, 16))