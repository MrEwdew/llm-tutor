from wypp import *

# Aufgabe 3a

# Datenbeschreibung:
# Ein Name besteht aus:
# - Vorname (typ: str)
# - Nachname (typ: str)

@record
class Name:
    vorname: str
    nachname: str

# Eine Adresse besteht aus:
# - Name (typ: Name)
# - Straße plus Hausnummer (typ: str)
# - Zusatz, der leer sein kann (typ: str)
# - Postleitzahl (typ: str)
# - Stadt (typ: str)
# - Land (typ: str)

@record
class Adresse:
    name: Name
    strasse: str
    zusatz: str
    plz: str
    stadt: str
    land: str

# Aufgabe 3b

# 1. Kurzbeschreibung
# Ändert den Nachnamen einer gegebenen Adresse.

# 2. Datenanalyse
# Eingabe: Adresse (typ: Adresse), neuer Nachname (typ: str)
# Ausgabe: Adresse mit neuem Nachnamen (typ: Adresse)

# 3. Kopf
def aendereNachname(a: Adresse, neuerNachname: str) -> Adresse:
    neuerName = Name(a.name.vorname, neuerNachname)
    return Adresse(neuerName, a.strasse, a.zusatz, a.plz, a.stadt, a.land)

# 4. Checks
test_adresse1 = Adresse(Name('Matti', 'Mustermann'), 'Teststraße 24', '', '77652', 'Offenburg', 'Deutschland')
test_adresse2 = Adresse(Name('Lisa', 'Müller'), 'Musterstraße 10', '2. OG', '77652', 'Offenburg', 'Deutschland')

check(aendereNachname(test_adresse1, 'Moosmann'), Adresse(Name('Matti', 'Moosmann'), 'Teststraße 24', '', '77652', 'Offenburg', 'Deutschland'))
check(aendereNachname(test_adresse2, 'Wehr'), Adresse(Name('Lisa', 'Wehr'), 'Musterstraße 10', '2. OG', '77652', 'Offenburg', 'Deutschland'))

# Aufgabe 3c

# 1. Kurzbeschreibung
# Formatiert eine Adresse für einen Briefumschlag.

# 2. Datenanalyse
# Eingabe: Adresse (typ: Adresse)
# Ausgabe: Formatierte Adresse für den Briefumschlag (typ: str)

# 3. Kopf
def formatiereAdresse(a: Adresse) -> str:
    vollerName = a.name.vorname + ' ' + a.name.nachname
    ortZeile = a.plz + ' ' + a.stadt
    if a.zusatz == '':
        return vollerName + '\n' + a.strasse + '\n' + ortZeile + '\n' + a.land
    else:
        return vollerName + '\n' + a.strasse + '\n' + a.zusatz + '\n' + ortZeile + '\n' + a.land

# 4. Checks
check(formatiereAdresse(test_adresse1), 'Matti Mustermann\nTeststraße 24\n77652 Offenburg\nDeutschland')
check(formatiereAdresse(test_adresse2), 'Lisa Müller\nMusterstraße 10\n2. OG\n77652 Offenburg\nDeutschland')
