from wypp import *

# Datenbeschreibung:
# Es gibt folgende Schadstoffklassen: 1-4, 5 und 6
type MöglicheSchadstoffklassen = Literal[1,2,3,4,5,6]

#Maut Kriterien sind abhängig von:
# - Wurde Maut bezahlt (typ bool)
# - Liegt eine Sondergenehmigung vor (typ bool)
# - Schadstoffklasse (typ MöglicheSchadstoffklassen)

@record
class MautKriterien:
    mautBezahlt: bool
    liegtSondergenehmigungVor: bool
    schadstoffklasse: MöglicheSchadstoffklassen

# 1. Kurzbeschreibung
# Berechnet anhand der Maut-Kriterien, ob eine Einfahrt in die Stadt möglich ist.

# 2. Datenanalyse
# Eingabe: Maut-Kriterien (typ: MautKriterien)
# Ausgabe: Ob Einfahrt möglich ist (typ: bool)

# 3. Kopf
def istEinfahrtMöglich(mK: MautKriterien) -> bool:
    if mK.mautBezahlt == False:
        if (mK.schadstoffklasse == 5 or mK.schadstoffklasse == 6) and mK.liegtSondergenehmigungVor == True:
            return True
        else:
            return False
    else:
        if mK.schadstoffklasse == 5 or mK.schadstoffklasse == 6 or mK.liegtSondergenehmigungVor == True:
            return True
        else: 
            return False

# 4. Checks
check(istEinfahrtMöglich(MautKriterien(False,True,6)),True) #Falls die Maut nicht bezahlt wurde, ist eine Einfahrt nur mit Sondergenehmigung möglich
check(istEinfahrtMöglich(MautKriterien(False,False,6)),False)
check(istEinfahrtMöglich(MautKriterien(True,False,5)),True)
check(istEinfahrtMöglich(MautKriterien(True,False,3)),False)
check(istEinfahrtMöglich(MautKriterien(True,True,3)),True)
check(istEinfahrtMöglich(MautKriterien(False,True,3)),False)

