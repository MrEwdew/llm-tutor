from wypp import *

# Aufgabe 4a

# Datenbeschreibung:
# Eine Ampelfarbe ist eins der folgenden:
# - grün (niedriger Gehalt, weniger als 5g)
# - gelb (mittlerer Gehalt, zwischen 5g und 22,5g)
# - rot (hoher Gehalt, mehr als 22,5g)

type Ampel = Literal['grün', 'gelb', 'rot']

# Ein aufgeteilter Zuckergehalt (bezogen auf die Packungsgröße) besteht aus:
# - Fruktose in Gramm (typ: float)
# - Glukose in Gramm (typ: float)

@record
class ZuckerAufgeteilt:
    fruktose: float
    glukose: float

# Der Zuckergehalt eines Lebensmittels ist entweder:
# - aufgeteilt in Fruktose und Glukose (typ: ZuckerAufgeteilt)
# - in Gramm pro 100g Lebensmittel angegeben (typ: float)
# - über das Ampelsystem angegeben (typ: Ampel)

type Zuckergehalt = Union[ZuckerAufgeteilt, float, Ampel]

# Ein Lebensmittel hat folgende Eigenschaften:
# - Name (typ: str)
# - Packungsgröße in Gramm (typ: int)
# - Zuckergehalt (typ: Zuckergehalt)

@record
class Lebensmittel:
    name: str
    packungsgroesse: int
    zuckergehalt: Zuckergehalt

# Beispiele aus der Aufgabenstellung:
cocaCola = Lebensmittel('Coca Cola', 500, ZuckerAufgeteilt(25, 25))
ritterSport = Lebensmittel('Ritter Sport himmlische Beere', 100, ZuckerAufgeteilt(15.29, 24.9))
kuerbis = Lebensmittel('Kürbis', 1000, 2.8)
gurke = Lebensmittel('Gurke', 470, 'grün')

# Aufgabe 4b

# Hilfsfunktion:
# 1. Kurzbeschreibung
# Berechnet für einen in Fruktose und Glukose aufgeteilten Zuckergehalt
# den Gesamtzuckergehalt pro 100g anhand der Packungsgröße.

# 2. Datenanalyse
# Eingabe: Zuckergehalt aufgeteilt (typ: ZuckerAufgeteilt), Packungsgröße in Gramm (typ: int)
# Ausgabe: Gesamtzuckergehalt pro 100g (typ: float)

# 3. Kopf
def zuckerPro100gBerechnen(z: ZuckerAufgeteilt, packungsgroesse: int) -> float:
    gesamtZucker = z.fruktose + z.glukose
    return (gesamtZucker / packungsgroesse) * 100

# 4. Checks
check(zuckerPro100gBerechnen(ZuckerAufgeteilt(25, 25), 500), 10.0)
check(zuckerPro100gBerechnen(ZuckerAufgeteilt(15.29, 24.9), 100), 40.19)


# Hauptfunktion:
# 1. Kurzbeschreibung
# Berechnet für ein gegebenes Lebensmittel, in welche Kategorie der Ampel (rot, gelb oder grün) es fällt.

# 2. Datenanalyse
# Eingabe: ein Lebensmittel (typ: Lebensmittel)
# Ausgabe: Kategorie der Ampel (typ: Ampel)

# 3. Kopf
def lebensmittelAmpel(l: Lebensmittel) -> Ampel:
    if isinstance(l.zuckergehalt, ZuckerAufgeteilt):
        zuckerPro100g = zuckerPro100gBerechnen(l.zuckergehalt, l.packungsgroesse)
    elif isinstance(l.zuckergehalt, float) or isinstance(l.zuckergehalt, int):
        zuckerPro100g = l.zuckergehalt
    else:
        return l.zuckergehalt

    if zuckerPro100g < 5:
        return 'grün'
    elif zuckerPro100g <= 22.5:
        return 'gelb'
    else:
        return 'rot'

# 4. Checks
check(lebensmittelAmpel(cocaCola), 'gelb')
check(lebensmittelAmpel(ritterSport), 'rot')
check(lebensmittelAmpel(kuerbis), 'grün')
check(lebensmittelAmpel(gurke), 'grün')
check(lebensmittelAmpel(Lebensmittel('Limonade', 500, 5.0)), 'gelb')
check(lebensmittelAmpel(Lebensmittel('Bonbons', 200, 25.0)), 'rot')
