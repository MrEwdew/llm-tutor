from wypp import *

#DATENBSCHREIBUNG

#Ein Computer besteht aus:
# - Prozessor (str)
# - Festplatte (int)
# - Hauptspeicher (int)

@record
class Computer:
    arbeitsspeicher: int
    festplatte: int
    prozessor: str

#Funktion, die die Kosten des Arbeitsspeichers berechnet
#Eingabe: Computer (typ: Computer)
#Ergebnis: Arbeitsspeicherkosten (typ: int)

def berechneArbeitsspeicherkosten(computer: Computer)->int:
    if computer.arbeitsspeicher < 6:
        return 30
    else:
        return computer.arbeitsspeicher * 5

check(berechneArbeitsspeicherkosten(Computer(1,1000,"AMD")),30)
check(berechneArbeitsspeicherkosten(Computer(10,1000,"AMD")),50)

#Funktion, die die Kosten der Festplatte berechnet
#Eingabe: Computer (typ: Computer)
#Ergebnis: Festplattenkosten (typ: int)

def berechneFestplattenkosten(computer: Computer)->int:
    return math.ceil(computer.festplatte/500) *20

check(berechneFestplattenkosten(Computer(10,1000,"AMD")),40)
check(berechneFestplattenkosten(Computer(10,1300,"AMD")),60)
check(berechneFestplattenkosten(Computer(10,900,"AMD")),40)

#Funktion, die die Kosten der CPU berechnet
#Eingabe: Computer (typ: Computer)
#Ergebnis: cpuKosten (typ: int)

def berechneCPUKosten(computer: Computer)->int:
    if "Intel" in computer.prozessor:
        return 110
    else:
        return 90
    
check(berechneCPUKosten(Computer(10,1000,"AMD")),90)
check(berechneCPUKosten(Computer(10,1000,"Intel")),110)

#Funktion, die je Computerteil den Preis berechnet
#Eingabe: Computer (typ: Computer)
#Ergebnis: Gesamtkosten (typ: int)

def preismodell(computer: Computer)->int:
    arbeitsspeicherkosten = berechneArbeitsspeicherkosten(computer)
    kostenFestplatte = berechneFestplattenkosten(computer)
    kostenCPU = berechneCPUKosten(computer)
    extraKosten = 100

    return arbeitsspeicherkosten+kostenFestplatte+kostenCPU+extraKosten

check(preismodell(Computer(100,1000,"AMD")), 730)
check(preismodell(Computer(5,1300,"Intel")), 300)


#Funktion, die den Arbeitsspeicher eines Computers erweitert
#Eingabe: Computer (Typ: Computer), erweiterung in GB (int)
#Ergebnis: Computer (Typ: Computer)

def arbeitsspeicherErweitern(computer: Computer, erweiterung: int)-> Computer | str:
    if erweiterung<0:
        return "Die Erweiterung darf nicht negativ sein"
    else:
        neuerSpeicher = computer.arbeitsspeicher+erweiterung
        return Computer(neuerSpeicher,1000,"AMD")

check(arbeitsspeicherErweitern(Computer(100,1000,"AMD"),50), Computer(150,1000,"AMD"))
check(arbeitsspeicherErweitern(Computer(100,1000,"AMD"),-50),
      "Die Erweiterung darf nicht negativ sein")