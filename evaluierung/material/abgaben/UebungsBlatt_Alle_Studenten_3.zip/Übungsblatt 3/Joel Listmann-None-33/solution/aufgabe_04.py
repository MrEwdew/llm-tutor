from wypp import *

#DATENBESCHREIBUNG

#Der Zuckergehalt hat folgende Möglichkeiten visualisiert zu werden:
# - Fruktose und Glukose (typ: FruktoseUndGlukose)
# - Pro 100 Gramm (typ: ZuckerIn100G)
# - Ampelsystem (typ: Ampelsystem)

type Zuckergehalt = Union[FrutkoseUndGlukose, ZuckerIn100G, Ampelkategorie]

#Der Fruktose- und Glukosegehalt hat folgende Merkmale:
# - Fruktosegehalt (float)
# - Glukosegehalt (float)

@record 
class FrutkoseUndGlukose:
    fruktosegehalt: float
    glukosegehalt: float


#Der Zuckergehalt pro 100 gramm hat folgende Eigenschaften:
# - Zuckergehalt (float)

@record
class ZuckerIn100G:
    zuckergehalt: float

#Das Ampelsystem hat folgende Varianten:
#rot, gelb, grün

type Ampelkategorie = Literal["rot", "gelb", "grün"]

#Ein Produkt besteht aus folgenden Eigenschaften:
# - Name (str)
# - Packungsgröße in gramm (int)
# - Zuckergehalt (typ: Zuckergehalt)

@record 
class Produkt:
    name: str
    packungsgöße: int
    zuckergehalt: Zuckergehalt


cola = Produkt("Coca Cola", 500, FrutkoseUndGlukose(25, 25))
ritterSport = Produkt("Ritter Sport himmlische Beere", 100, FrutkoseUndGlukose(15.29, 24.9))
kürbis = Produkt("Kürbis", 1000, ZuckerIn100G(2.8))
gurke = Produkt("Gurke", 470, "grün")



#Funktion, die einem Zuckergehalt einer Ampelkategorie zuordnet
#Eingabe: Zuckergehalt pro 100 g (float)
#Ausgabe: Ampelkategorie

def zuckerInAmpel(zucker: float) -> Ampelkategorie:
    if zucker <5:
        return "grün"
    elif zucker >22.5:
        return "rot"
    else: 
        return "gelb"

check(zuckerInAmpel(4), "grün")
check(zuckerInAmpel(5), "gelb")
check(zuckerInAmpel(10.5), "gelb")
check(zuckerInAmpel(22.5), "gelb")
check(zuckerInAmpel(23), "rot")


#Funktion, den Zuckergehalt in Zucker pro 100g umrechnet
#Eingabe: Produkt (typ: Produkt)
#Ausgabe: Zucker pro 100g (float)
def zuckerUmrechnen(produkt: Produkt) -> float:
    return (produkt.zuckergehalt.fruktosegehalt + produkt.zuckergehalt.glukosegehalt)/produkt.packungsgöße *100

#Funktion, die die Ampelkategorie des Lebensmittels berechnet
#Eingabe: Produkt (typ: Produkt)
#Ausgabe: Ampelkategorie (typ: Ampelkategorie)

def berechneAmpelkategorie(produkt: Produkt) -> Ampelkategorie:
    if isinstance(produkt.zuckergehalt, FrutkoseUndGlukose):
        return zuckerInAmpel(zuckerUmrechnen(produkt))
    elif isinstance(produkt.zuckergehalt, ZuckerIn100G):
        return zuckerInAmpel(produkt.zuckergehalt.zuckergehalt)
    else: 
        return produkt.zuckergehalt

check(berechneAmpelkategorie(cola), "gelb")
check(berechneAmpelkategorie(ritterSport),"rot")
check(berechneAmpelkategorie(kürbis),"grün")
check(berechneAmpelkategorie(gurke), "grün")


