from wypp import *

#DATENBESCHREIBUNG:

#Ein Name besteht aus 
# - Vorname (str)
# - Nachname (str)

@record
class Name:
    vorname: str
    nachname: str

#Eine Straße besteht aus
# - Straßenname (str)
# - Hausnummer (int)

@record
class Straße:
    straßenname: str
    hausnummer: int

#Eine Adresse besteht aus:
# - Name (typ: Name)
# - Straße (typ: Straße)
# - Zusatz (str)
# - Postleitzahl (int)
# - Stadt (str)
# - Land (str)

@record
class Adresse:
    name: Name
    straße: Straße
    zusatz: str
    postleitzahl: int
    stadt: str
    land: str

name1 = Name("Joel", "Listmann")
adresse1 = Adresse(name1, Straße("Teststraße", 1),"a",77928, "Teststadt","Testland")
adresse2 = Adresse(name1, Straße("Teststraße", 2),"",77928, "Teststadt","Testland")

#Funktion, die den Nachnamen einer gegebenen Adresse ändert
#Eingabe: Adresse (typ: Adresse), neuerNachname (str)
#Ausgabe: Adresse (typ: Adresse)

def änderungNachname(adresse: Adresse, neuerNachname: str) -> Adresse:
    neuerName = Name(adresse.name.vorname, neuerNachname)
    return Adresse(neuerName, adresse.straße, adresse.zusatz, adresse.postleitzahl, adresse.stadt, adresse.land)

check(änderungNachname(adresse1, "Kreide"), Adresse(Name("Joel", "Kreide"), Straße("Teststraße",1),"a",77928, "Teststadt","Testland"))
check(änderungNachname(adresse1, "Lettland"), Adresse(Name("Joel", "Lettland"), Straße("Teststraße",1),"a",77928, "Teststadt","Testland"))

#Funktion, die eine Adresse für einen Briefumschlag formattiert
#Eingabe: Adresse (typ: Adresse)
#Ausgabe: Adresse als Text (str)

def formattiereAdresse(adresse: Adresse) -> str:
    zeile1 = adresse.name.vorname + " " + adresse.name.nachname + "\n"
    zeile2 = adresse.straße.straßenname + " " + str(adresse.straße.hausnummer) + adresse.zusatz + "\n"
    zeile3 = str(adresse.postleitzahl) + " " + adresse.stadt + "\n"
    zeile4 = adresse.land
    return zeile1+zeile2+zeile3+zeile4

check(formattiereAdresse(adresse1), "Joel Listmann\nTeststraße 1a\n77928 Teststadt\nTestland")
check(formattiereAdresse(adresse2), "Joel Listmann\nTeststraße 2\n77928 Teststadt\nTestland")