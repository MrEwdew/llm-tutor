from wypp import * 

#Eine Uhrzeit besteht aus:
# - einer Stunde
# - einer Minute

@record
class Uhrzeit:
    stunde: int
    minute: int

#Funktion, die für eine gegebene Uhrzeit die Anzahl der Sekunden seit Mitternacht zurückgibt
#Eingabe: Uhrzeit (Type: Uhrzeit)
#Ergebnis: Sekunden seit Mitternacht (int)

def timeSinceMidnight(uhr: Uhrzeit)-> int:
    return uhr.stunde * 60 **2 + uhr.minute *60

check(timeSinceMidnight(Uhrzeit(1,0)),3600)
check(timeSinceMidnight(Uhrzeit(10,30)),37800)