from wypp import *

#DATENBESCHREIBUNG

#Ein Auto besteht aus folgenden Attributen:
# - Mautbezahlung (bool)
# - Sondergenehmigung (bool)
# - Schadstoffklasse (typ: Schadstoffklasse)

@record
class Auto:
    mautbezahlung: bool
    sondergenehmigung: bool
    schadstoffklasse: Schadstoffklasse

#Eine Schadstoffklasse hat folgende Alternativen:
#1, 2, 3, 4, 5, 6

type Schadstoffklasse = Literal[1, 2, 3, 4, 5, 6]

#Funktion, die bestimmt ob eine Einfahrt möglich ist
#Eingabe: Auto (typ: Auto)
#Ausgabe: Einfahrt möglich ja/nein (typ: bool)

def einfahrtMöglich(auto: Auto)->bool:
    if auto.schadstoffklasse == 5 or auto.schadstoffklasse == 6:
        if auto.mautbezahlung == True or auto.sondergenehmigung==True:
            return True
        else: 
            return False
    else: 
        if auto.mautbezahlung ==True and auto.sondergenehmigung==True:
            return True
        else:
            return False
        

check(einfahrtMöglich(Auto(True, False, 5)),True)
check(einfahrtMöglich(Auto(False, True, 6)),True)
check(einfahrtMöglich(Auto(False, False, 6)),False)
check(einfahrtMöglich(Auto(True, True, 2)),True)
check(einfahrtMöglich(Auto(False, True, 2)),False)



