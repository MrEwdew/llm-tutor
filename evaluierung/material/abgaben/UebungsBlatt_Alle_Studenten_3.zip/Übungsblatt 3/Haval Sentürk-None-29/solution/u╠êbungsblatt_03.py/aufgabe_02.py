from wypp import *


# Eine Schadstoffklasse ist eins der folgenden:
# - 1-4 
# - 5 
# - 6 

type Schadstoffklasse = Literal['1-4', '5', '6']


# Maut-Kriterien bestehen aus:
# - Mautbezahlt (typ:bool)
# - Sonderzeichen (typ:bool)
# - Schadstofklasse (typ:Schadstoffklasse)

@record
class MautKriterien:
    mautBezahlt: bool
    sondergenehmigung: bool
    schadstoffklasse: Schadstoffklasse

# Funktion zu Einfahrt möglich 
# Eingabe:
# - Maut-Kriterien als record
# Ergebnis: Einfahrt möglich Ture / False als bool

def einfahrtMoeglich(k: MautKriterien) -> bool:
    if k.mautBezahlt and k.sondergenehmigung:
        return True
    elif (k.mautBezahlt or k.sondergenehmigung) and k.schadstoffklasse != '1-4':
        return True
    else:
        return False


check(einfahrtMoeglich(MautKriterien(True, False, '6')), True)
check(einfahrtMoeglich(MautKriterien(False, False, '6')), False)
check(einfahrtMoeglich(MautKriterien(False, True, '5')), True)
check(einfahrtMoeglich(MautKriterien(True, False, '1-4')), False)
check(einfahrtMoeglich(MautKriterien(False, True, '1-4')), False)
check(einfahrtMoeglich(MautKriterien(True, True, '1-4')), True)