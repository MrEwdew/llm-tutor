from wypp import *


# Ein Name besteht aus:
# - Vorname (typ: str)
# - Nachname (typ: str)

@record
class Name:
    vorname: str
    nachname: str


# Eine Adresse besteht aus:
# - Name (typ: Name)
# - Straße (typ: str)
# - Zusatz (typ: str)
# - PLZ (typ: str)
# - Stadt (typ: str)
# - Land (typ: str)

@record
class Adresse:
    name: Name
    strasse: str
    zusatz: str
    plz: str
    stadt: str
    land: str


# Testdaten
adresseMax = Adresse(Name('Max', 'Mustermann'), 'Bananen Str. 12', 'a', '67591',
                     'Worms', 'Deutschland')


# Erzeugt eine neue Adresse, in der nur der Nachname ersetzt ist.
# Eingabe:
# - neuerNachname (typ: str)
# - alteAdresse (typ: Adresse)
# Ergebnis: neue Adresse mit geändertem Nachnamen (typ: Adresse)

def nachnamenAendern(neuerNachname: str, alteAdresse: Adresse) -> Adresse:
    neuerName = Name(alteAdresse.name.vorname, neuerNachname)
    return Adresse(neuerName, alteAdresse.strasse, alteAdresse.zusatz,
                   alteAdresse.plz, alteAdresse.stadt, alteAdresse.land)


check(nachnamenAendern('Abu-Alsaad', adresseMax),
      Adresse(Name('Max', 'Abu-Alsaad'), 'Bananen Str. 12', 'a', '67591',
              'Worms', 'Deutschland'))
check(nachnamenAendern('Mustermann', adresseMax), adresseMax)



# Funktion zur DArstellung des Briefsumschlags
# Eingabe: Adresse 
# Ergebnis: Formatierter Briefumschlag (typ:str)

def briefumschlag(adresse: Adresse) -> str:
    return (adresse.name.vorname + ' ' + adresse.name.nachname + '\n' +
            adresse.strasse +  '\n' +
            adresse.zusatz + '\n' +
            adresse.plz + ' ' + adresse.stadt + '\n' +
            adresse.land)