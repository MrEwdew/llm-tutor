from wypp import *

PAUSCHALE = 100

# Ein Computer besteht aus:
# - Prozessor (str)
# - Festplatten-Kapazität in Gigabyte (int)
# - Arbeitsspeicher-Kapazität in Gigabyte (int)
@record
class Computer:
    prozessor: str
    festplatte: int
    arbeitsspeicher: int




# Funktion zu Berechnung von Arbeitsspeicher Preis 
# Eingabe: Arbeitsspeicher in GB als int
# Ergebnis: Preis in Euro als int

def arbeitsspeicherPreis(arbeitsspeicherMenge: int) -> int:
    if arbeitsspeicherMenge <= 6:
        return 30 
    else:
        return arbeitsspeicherMenge * 5 

check(arbeitsspeicherPreis(5), 30)
check(arbeitsspeicherPreis(6), 30)
check(arbeitsspeicherPreis(7), 35)


# Funktion zur Brechnung des Festplattenspeichers 
# Eingabe: Festplattenspeichermenge in GB als int
# Ergebnis: Preis in euro als int

def festplattenPreis(festplattenspeicherMenge: int) -> int:
    if festplattenspeicherMenge % 500 == 0:
        return festplattenspeicherMenge // 500 * 20
    else: 
        return festplattenspeicherMenge // 500 * 20 + 20

check(festplattenPreis(500), 20)
check(festplattenPreis(501), 40)
check(festplattenPreis(1000), 40)
check(festplattenPreis(1100), 60)

# Funktion zu Berechnung des Prozessor Preis
# Eingabe: Prozessor Name als str
# Ergebnis: Preis in euro als int 

def prozessorPreis(prozessorName: str) -> int:
    if 'Intel' in prozessorName:
        return 110
    else: 
        return 90

check(prozessorPreis('Intel'), 110)
check(prozessorPreis('AMD'), 90) 
check(prozessorPreis('Intel i7'), 110)




# Preis eines Computers 
# Eingabe: ein Computer 
# Ergebnis: Preis für Computer in Euro als int

def computerPreis(c: Computer) -> int:
    return arbeitsspeicherPreis(c.arbeitsspeicher) + festplattenPreis(c.festplatte) + prozessorPreis(c.prozessor)  + PAUSCHALE

check(computerPreis(Computer('Sempron', 500, 2)), 240)
check(computerPreis(Computer('Intel i7', 1100, 8)), 310)
check(computerPreis(Computer('AMD', 1000, 5)), 260)



# Aufgabe 1B)

# Ein Fehler besitzt folgende Eigenschaften:
# - Fehlermeldung (str)
@record
class Error:
    message: str


# Funktion zu Erweiterung des Arbeitsspeichers 
# Eingabe: Computer und eine Speichermenge in GB als int 
# Ergebnis: ein Computer mit veränderten Arbeitsspeicher als Computer


def arbeitsspeicherAenderer(c: Computer, zusatzSpeicher: int) -> Union[Error, Computer]:
    if zusatzSpeicher < 0:
         return Error('Speicher darf nicht kleiner werden')
    else: 
        return Computer(c.prozessor, c.festplatte, c.arbeitsspeicher + zusatzSpeicher)


check(arbeitsspeicherAenderer(Computer('AMD', 1000, 8), 8), Computer('AMD', 1000, 16))
check(arbeitsspeicherAenderer(Computer('AMD', 1000, 8), 0), Computer('AMD', 1000, 8))
check(arbeitsspeicherAenderer(Computer('AMD', 1000, 8), -4), Error('Speicher darf nicht kleiner werden'))