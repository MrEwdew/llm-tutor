from wypp import *

# Aufgabe 4a

# Datenbeschreibung:
# Eine Ampelstufe ist eins der folgenden:
# - grün (niedriger Gehalt, weniger als 5g)
# - gelb (mittlerer Gehalt, zwischen 5g und 22,5g)
# - rot (hoher Gehalt, mehr als 22,5g)
type Ampelstufe = Literal['grün', 'gelb', 'rot']


# Eine Zuckerverteilung (bezogen auf die Packungsgröße) besteht aus:
# - Fruktoseanteil in Gramm (typ: float)
# - Glukoseanteil in Gramm (typ: float)
@record
class Zuckerverteilung:
    fruktoseGramm: float
    glukoseGramm: float


# Die Zuckerangabe eines Produkts ist entweder:
# - aufgeteilt in Fruktose und Glukose (typ: Zuckerverteilung)
# - in Gramm pro 100g Produkt angegeben (typ: float)
# - über das Ampelsystem angegeben (typ: Ampelstufe)
type Zuckerangabe = Union[Zuckerverteilung, float, Ampelstufe]


# Ein Produkt hat folgende Eigenschaften:
# - Bezeichnung (typ: str)
# - Packungsgewicht in Gramm (typ: int)
# - Zuckerangabe (typ: Zuckerangabe)
@record
class Produkt:
    bezeichnung: str
    packungsgewicht: int
    zucker: Zuckerangabe


# Beispiele aus der Aufgabenstellung:
cola = Produkt('Coca Cola', 500, Zuckerverteilung(25, 25))
schokolade = Produkt('Ritter Sport himmlische Beere', 100, Zuckerverteilung(15.29, 24.9))
hokkaido = Produkt('Kürbis', 1000, 2.8)
salatgurke = Produkt('Gurke', 470, 'grün')


# Aufgabe 4b

# Hilfsfunktion:
# 1. Kurzbeschreibung
# Rechnet eine in Fruktose und Glukose aufgeteilte Zuckerangabe anhand
# des Packungsgewichts in Gramm Zucker pro 100g um.

# 2. Datenanalyse
# Eingabe: Zuckerverteilung (typ: Zuckerverteilung), Packungsgewicht in Gramm (typ: int)
# Ausgabe: Zucker pro 100g (typ: float)

# 3. Kopf
def zuckerAnteilPro100g(verteilung: Zuckerverteilung, packungsgewicht: int) -> float:
    zuckerGesamt = verteilung.fruktoseGramm + verteilung.glukoseGramm
    return (zuckerGesamt / packungsgewicht) * 100

# 4. Checks
check(zuckerAnteilPro100g(Zuckerverteilung(25, 25), 500), 10.0)
check(zuckerAnteilPro100g(Zuckerverteilung(15.29, 24.9), 100), 40.19)


# Hauptfunktion:
# 1. Kurzbeschreibung
# Ordnet ein gegebenes Produkt einer Ampelstufe (rot, gelb oder grün) zu.

# 2. Datenanalyse
# Eingabe: ein Produkt (typ: Produkt)
# Ausgabe: Ampelstufe (typ: Ampelstufe)

# 3. Kopf
def ampelEinstufen(p: Produkt) -> Ampelstufe:
    if isinstance(p.zucker, Zuckerverteilung):
        anteil = zuckerAnteilPro100g(p.zucker, p.packungsgewicht)
    elif isinstance(p.zucker, float) or isinstance(p.zucker, int):
        anteil = p.zucker
    else:
        return p.zucker

    if anteil < 5:
        return 'grün'
    elif anteil <= 22.5:
        return 'gelb'
    else:
        return 'rot'

# 4. Checks
check(ampelEinstufen(cola), 'gelb')
check(ampelEinstufen(schokolade), 'rot')
check(ampelEinstufen(hokkaido), 'grün')
check(ampelEinstufen(salatgurke), 'grün')
check(ampelEinstufen(Produkt('Limonade', 500, 5.0)), 'gelb')
check(ampelEinstufen(Produkt('Bonbons', 200, 25.0)), 'rot')
