from wypp import *
# DATENBESCHREIBUNG
# Ein Name Besteht aus:
# - Vorname (str)
# - Nachname (str)

# Eine Adresse besteht aus:
# - Name (Klasse Name)
# - Strasse (str)
# - Hausnummer (str), weil auch Angaben wie "11a" möglich sind
# - Zusatz (str), der leer sein kann
# - PLZ (str), weil eine Postleitzahl mit 0 beginnen kann
# - Stadt (str)
# - Land (str)

@record
class Name:
    vorname : str
    nachname : str

@record
class Adresse:
    name : Name
    strasse : str
    hausnummer : str
    zusatz : str
    plz : str
    stadt : str
    land : str



#beschreibung: Diese Funktion ändert den Nachnamen an einer gegebenen Adresse
#Input: Eine Adresse (Klasse Adresse) und der neue Nachname (str)
#Output: Eine Adresse mit veränderten Nachnamen (Klasse Adresse)

def aendereNachname(adresse: Adresse, nachname : str) -> Adresse:
    return Adresse(Name(adresse.name.vorname,nachname),adresse.strasse,adresse.hausnummer,adresse.zusatz,adresse.plz,adresse.stadt,adresse.land)

check(aendereNachname(Adresse(Name("Max","Mustermann"),"Musterstrasse","11","a","12345","Musterstadt","DE"),"Musterfrau"),Adresse(Name("Max","Musterfrau"),"Musterstrasse","11","a","12345","Musterstadt","DE"))
check(aendereNachname(Adresse(Name("Max","Mustermann"),"Musterstrasse","11","","12345","Musterstadt","DE"),"MusterMuster"),Adresse(Name("Max","MusterMuster"),"Musterstrasse","11","","12345","Musterstadt","DE"))

#beschreibung: Diese Funktion formatiert eine Adresse für einen Briefumschlag
#Input: Eine Adresse (Klasse Adresse)
#Output: Eine Textkette die auf einen Brief geschrieben werden kann (str)

def schreibeAdresse(adresse :Adresse) -> str:
    # Der Zusatz bekommt nur dann ein Leerzeichen davor, wenn er nicht leer ist
    zusatz = ""
    if(adresse.zusatz != ""):
        zusatz = " " + adresse.zusatz
    return "{vorname} {nachname}\n{strasse} {hausnummer}{zusatz}\n{plz} {stadt}\n{land}".format(vorname = adresse.name.vorname, nachname = adresse.name.nachname, strasse = adresse.strasse,hausnummer = adresse.hausnummer, zusatz = zusatz, plz = adresse.plz, stadt = adresse.stadt,land = adresse.land )

check(schreibeAdresse(Adresse(Name("Max","Mustermann"),"Musterstrasse","11","a","12345","Musterstadt","DE")),"Max Mustermann\nMusterstrasse 11 a\n12345 Musterstadt\nDE")
check(schreibeAdresse(Adresse(Name("Marta","Musterfrau"),"Im Bühl","11","","12345","Musterstadt","DE")),"Marta Musterfrau\nIm Bühl 11\n12345 Musterstadt\nDE")
check(schreibeAdresse(Adresse(Name("Erika","Muster"),"Hauptstrasse","7b","","01067","Dresden","DE")),"Erika Muster\nHauptstrasse 7b\n01067 Dresden\nDE")

print(schreibeAdresse(Adresse(Name("Max","Mustermann"),"Musterstrasse","11","a","12345","Musterstadt","DE")))
