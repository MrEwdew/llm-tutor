from wypp import *

@record
class Uhrzeit:
    stunde : int
    minute : int
      

#Beschreibung: Wir schreiben eine funktion, die vergangenen Sekunden seit 24 Uhr berechnet. 
#Input: Eine Uhrzeit (Klasse Uhrzeit)
#Output: Die Zeit in Sekunden seit 0:00 Uhr, Stunden größer als 24 liefern 0 zurück (int)

def berechneZeitSeitMitternachtInSekunden(zeit :Uhrzeit) -> int:
    if zeit.stunde >= 24:
        return 0
    counter = 0
    counter += zeit.stunde * 3600
    counter += zeit.minute * 60
    return counter



check(berechneZeitSeitMitternachtInSekunden(Uhrzeit(1,0)), 3600)
check(berechneZeitSeitMitternachtInSekunden(Uhrzeit(5,20)), 3600 *5 + 20 *60)
check(berechneZeitSeitMitternachtInSekunden(Uhrzeit(25,20)), 0)