from wypp import *

# DATENBESCHREIBUNG
# Eine Schadstoffklasse besteht aus:
# - Typ (Literal)

@record
class Schadstoffklasse:
    typ : Literal["1-4","5","6"]


# DATENBESCHREIBUNG
# Die Mautkriterien bestehen aus:
# - Schadstoffklasse (Schadstoffklasse)
# - sonderkriterium (bool)
# - bezahlt (bool)

@record
class Maut:
    schadstoffklasse : Schadstoffklasse
    sonderkriterium : bool
    bezahlt : bool



#beschreibung: Diese Funktion prüft anhand von gegebenen Bedingungen ob die einfahrt mögl. ist
#Input: eine Maut (Klasse Maut)
#Output: Wahrheitswert (bool)

def einfahrtErlaubt(maut : Maut) -> bool:
    if(maut.bezahlt and (maut.schadstoffklasse.typ == "5" or maut.schadstoffklasse.typ == "6")):
        return True
    if((not maut.bezahlt) and maut.sonderkriterium and (maut.schadstoffklasse.typ == "5" or maut.schadstoffklasse.typ == "6")):
        return True
    if((not maut.schadstoffklasse.typ == "5") and (not maut.schadstoffklasse.typ == "6") and maut.sonderkriterium is True and maut.bezahlt is True):
        return True
    else:
        return False

check(einfahrtErlaubt(Maut(Schadstoffklasse("6"), False, True)), True)
check(einfahrtErlaubt(Maut(Schadstoffklasse("5"), True, False)), True)
check(einfahrtErlaubt(Maut(Schadstoffklasse("1-4"), True, False)), False)