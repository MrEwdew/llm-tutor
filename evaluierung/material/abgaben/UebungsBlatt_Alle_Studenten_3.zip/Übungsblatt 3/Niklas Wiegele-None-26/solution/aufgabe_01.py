from wypp import *



# DATENBESCHREIBUNG
# Ein Computer besteht aus:
# - Prozessor (str)
# - Festplatten-Kapazität in Gigabyte (int)
# - Hauptspeicher-Kapazität in Gigabyte (int)

# TYPDEFINITION
@record
class Computer:
    prozessor: str
    festplatte: int
    hauptspeicher: int

#beschreibung: Wir schreiben eine funktion, die den preis eines Computers ausgibt, basierend auf den Preiskalukulationen der Aufgabe
#Input: Eine Computerdefinition (Klasse Computer)
#Output: Einen Preis in Euro (int)

def berechneComputerPreis(computer : Computer) -> int:
    preis = 0
    preis += computer.hauptspeicher * 5
    if(preis < 30 ):
        preis = 30
    preis += (20 * (math.ceil(computer.festplatte/500)))
    if('Intel' in computer.prozessor):
        preis+= 110
    else:
        preis+= 90

    preis += 100

    return preis

check(berechneComputerPreis(Computer("Intel", 200, 50)), 480)
check(berechneComputerPreis(Computer("AMD", 1100, 4)), 280)
check(berechneComputerPreis(Computer("Intel Core i3", 1500, 16)), 350)


#beschreibung: Diese Funktion erweitert den Arbeitsspeicher eines gegebenen Computers um einen gegebenen Wert
#Input: Eine Computerdefinition (Klasse Computer) und einen Wert für den Arbeitsspeicher (int)
#Output: Eine Computerdefinition (Klasse Computer)

def erweitereArbeitsspeicher(computer : Computer, ram : int) -> Computer:
    
    if(ram + computer.hauptspeicher > computer.hauptspeicher):
        return Computer(computer.prozessor,computer.festplatte, computer.hauptspeicher + ram)
    else: 
        return computer
    

check(erweitereArbeitsspeicher(Computer("Intel", 200, 50), 50),Computer("Intel", 200, 100))
check(erweitereArbeitsspeicher(Computer("AMD", 1100, 4), 4),Computer("AMD", 1100, 8))
check(erweitereArbeitsspeicher(Computer("Intel", 200, 50), -50),Computer("Intel", 200, 50))
        