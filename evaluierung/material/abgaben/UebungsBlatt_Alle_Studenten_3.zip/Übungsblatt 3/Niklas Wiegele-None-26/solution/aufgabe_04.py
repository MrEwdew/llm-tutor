from wypp import *

# DATENBESCHREIBUNG
# Eine Zuckermenge bezieht sich auf die gesamte Packung und besteht aus:
# - fruktosemenge in Gramm (float)
# - glukosemenge in Gramm (float)

@record
class Zuckermenge:
    fruktosemenge : float
    glukosemenge : float

# Ein zuckeranteil besteht aus:
# - zuckerPro100Gramm in Gramm pro 100 Gramm (float)

@record
class Zuckeranteil:
    zuckerPro100Gramm : float

# Eine Ampelfarbe ist eine der folgenden Farben:
# - "grün": niedriger Zuckergehalt Gehalt
# - "gelb": mittlerer Zuckergehalt
# - "rot": hoher Zuckergehalt

type Ampelfarbe = Literal["grün", "gelb", "rot"]

# Ein Zuckergehalt ist eine der folgenden Möglichkeiten:
# - eine Zuckermenge (Klasse Zuckermenge)
# - ein Zuckeranteil (Klasse Zuckeranteil)
# - eine Ampelfarbe (Ampelfarbe)

type Zuckergehalt = Union[Zuckermenge, Zuckeranteil, Ampelfarbe]

# Ein Lebensmittel besteht aus:
# - name (str)
# - packungsgroesse in Gramm (int)
# - zuckergehalt (Zuckergehalt)

@record
class Lebensmittel:
    name : str
    packungsgroesse : int
    zuckergehalt : Zuckergehalt


# Initiierung der Test Lebensmittel
cocaCola = Lebensmittel("Coca Cola", 500, Zuckermenge(25, 25))
ritterSport = Lebensmittel("Ritter Sport himmlische Beere", 100, Zuckermenge(15.29, 24.9))
kuerbis = Lebensmittel("Kürbis", 1000, Zuckeranteil(2.8))
gurke = Lebensmittel("Gurke", 470, "grün")


#beschreibung: Diese Funktion berechnet aus einer Zuckermenge den Gesamtzuckergehalt pro 100g
#Input: Eine Zuckermenge (Klasse Zuckermenge) und die Packungsgröße in Gramm (int)
#Output: Den Gesamtzuckergehalt pro 100g (float)

def berechneZuckergehaltPro100G(zuckermenge : Zuckermenge, packungsgroesse : int) -> float:
    return ((zuckermenge.glukosemenge + zuckermenge.fruktosemenge)/packungsgroesse)*100

check(berechneZuckergehaltPro100G(Zuckermenge(25, 25), 500), 10)
check(berechneZuckergehaltPro100G(Zuckermenge(15.29, 24.9), 100), 40.19)


#beschreibung: Diese Funktion ordnet einem Zuckergehalt pro 100g die passende Ampelfarbe zu
#Input: Ein Zuckergehalt pro 100g (float)
#Output: Eine ampelfarbe (Klasse Ampelfarbe)

def berechneFarbeAusZuckerPro100G(zuckerPro100G : float) -> Ampelfarbe:
    if(zuckerPro100G < 5):
        return "grün"
    if(zuckerPro100G <= 22.5):
        return "gelb"
    return "rot"

check(berechneFarbeAusZuckerPro100G(4.9), "grün")
check(berechneFarbeAusZuckerPro100G(5), "gelb")
check(berechneFarbeAusZuckerPro100G(22.5), "gelb")
check(berechneFarbeAusZuckerPro100G(22.6), "rot")


#beschreibung: Diese Funktion berechnet die Ampelfarbe eines Lebensmittels
#Input: Ein Lebensmittel (Klasse Lebensmittel)
#Output: Eine Ampelfarbe (Ampelfarbe)

def berechneLebensmittelFarbe(lebensmittel : Lebensmittel) -> Ampelfarbe:
    zuckergehalt = lebensmittel.zuckergehalt
    if isinstance(zuckergehalt, Zuckermenge):
        return berechneFarbeAusZuckerPro100G(berechneZuckergehaltPro100G(zuckergehalt, lebensmittel.packungsgroesse))
    elif isinstance(zuckergehalt, Zuckeranteil):
        return berechneFarbeAusZuckerPro100G(zuckergehalt.zuckerPro100Gramm)
    else:
        return zuckergehalt

check(berechneLebensmittelFarbe(cocaCola), "gelb")
check(berechneLebensmittelFarbe(ritterSport), "rot")
check(berechneLebensmittelFarbe(kuerbis), "grün")
check(berechneLebensmittelFarbe(gurke), "grün")
