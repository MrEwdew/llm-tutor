from wypp import *


# Eine Ampelfarbe ist eins der folgenden:
# - grün
# - gelb
# - rot
type Ampelfarbe = Literal['grün', 'gelb', 'rot']

# Eine ZuckerAufteilung besteht aus:
# - Fruktose in Gramm pro Packung (float)
# - Glukose in Gramm pro Packung (float)
@record
class ZuckerAufteilung:
    fruktose: float
    glukose: float


# ZuckerPro100g besteht aus:
# - Gramm Zucker pro 100 g Lebensmittel (float)
@record
class ZuckerPro100g:
    gramm: float


# ZuckerAmpel besteht aus:
# - Ampelfarbe (Ampelfarbe)
@record
class ZuckerAmpel:
    farbe: Ampelfarbe


# Ein Zuckergehalt ist eins der folgenden:
# - ZuckerAufteilung
# - ZuckerPro100g
# - ZuckerAmpel
type Zuckergehalt = Union[ZuckerAufteilung, ZuckerPro100g, ZuckerAmpel]

# Ein Lebensmittel besteht aus:
# - Name (str)
# - Packungsgröße in Gramm (float)
# - Zuckergehalt (Zuckergehalt)
@record
class Lebensmittel:
    name: str
    packung: float
    zucker: Zuckergehalt


cocaCola = Lebensmittel('Coca Cola', 500, ZuckerAufteilung(25, 25))
ritterSport = Lebensmittel('Ritter Sport himmlische Beere', 100,
                           ZuckerAufteilung(15.29, 24.9))
kuerbis = Lebensmittel('Kürbis', 1000, ZuckerPro100g(2.8))
gurke = Lebensmittel('Gurke', 470, ZuckerAmpel('grün'))


# Gesamtzucker pro 100 g berechnen
# Eingaben: ZuckerAufteilung und Packungsgröße in Gramm (float)
# Ergebnis: Gramm Zucker pro 100 g (float)
def zuckerJe100g(z: ZuckerAufteilung, packung: float) -> float:
    return (z.fruktose + z.glukose) * 100 / packung


# Ampelfarbe für ein Lebensmittel bestimmen
# Eingabe: ein Lebensmittel
# Ergebnis: die Ampelfarbe (Ampelfarbe)
def zuckerKategorie(l: Lebensmittel) -> Ampelfarbe:
    if isinstance(l.zucker, ZuckerAmpel):
        return l.zucker.farbe
    elif isinstance(l.zucker, ZuckerAufteilung):
        gramm = zuckerJe100g(l.zucker, l.packung)
    else:
        gramm = l.zucker.gramm
    if gramm < 5:
        return 'grün'
    elif gramm <= 22.5:
        return 'gelb'
    else:
        return 'rot'


check(zuckerJe100g(ZuckerAufteilung(25, 25), 500), 10.0)
check(zuckerJe100g(ZuckerAufteilung(0, 5), 100), 5.0)
check(zuckerKategorie(cocaCola), 'gelb')
check(zuckerKategorie(ritterSport), 'rot')
check(zuckerKategorie(kuerbis), 'grün')
check(zuckerKategorie(gurke), 'grün')
check(zuckerKategorie(Lebensmittel('Grenze 5', 100,
                                  ZuckerPro100g(5))), 'gelb')
check(zuckerKategorie(Lebensmittel('Grenze 22,5', 100,
                                  ZuckerPro100g(22.5))), 'gelb')
check(zuckerKategorie(Lebensmittel('Über 22,5', 100,
                                  ZuckerPro100g(23))), 'rot')
