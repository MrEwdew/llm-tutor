from wypp import *


# Eine Schadstoffklasse ist eine der Zahlen 1, 2, 3, 4, 5 oder 6.
type Schadstoffklasse = Literal[1, 2, 3, 4, 5, 6]

# Maut-Kriterien bestehen aus:
# - bezahlter Maut (bool)
# - Sondergenehmigung (bool)
# - Schadstoffklasse (Schadstoffklasse)
@record
class MautKriterien:
    bezahlt: bool
    sondergenehmigung: bool
    schadstoffklasse: Schadstoffklasse


# Prüfen, ob ein Auto in Offenburg einfahren darf
# Eingabe: die Maut-Kriterien
# Ergebnis: ob die Einfahrt erlaubt ist (bool)
def darfEinfahren(k: MautKriterien) -> bool:
    if k.schadstoffklasse == 5 or k.schadstoffklasse == 6:
        return k.bezahlt or k.sondergenehmigung
    else:
        return k.bezahlt and k.sondergenehmigung


check(darfEinfahren(MautKriterien(False, False, 5)), False)
check(darfEinfahren(MautKriterien(True, False, 5)), True)
check(darfEinfahren(MautKriterien(False, True, 5)), True)
check(darfEinfahren(MautKriterien(True, True, 6)), True)
check(darfEinfahren(MautKriterien(False, False, 1)), False)
check(darfEinfahren(MautKriterien(True, False, 4)), False)
check(darfEinfahren(MautKriterien(False, True, 4)), False)
check(darfEinfahren(MautKriterien(True, True, 1)), True)
