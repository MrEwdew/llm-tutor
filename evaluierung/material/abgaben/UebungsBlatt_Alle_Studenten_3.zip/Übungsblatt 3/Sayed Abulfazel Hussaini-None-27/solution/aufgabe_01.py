from wypp import *


# Ein Computer besteht aus:
# - Prozessor (str)
# - Festplatten-Kapazität in Gigabyte (int)
# - Hauptspeicher-Kapazität in Gigabyte (int)
@record
class Computer:
    prozessor: str
    festplatte: int
    hauptspeicher: int


# Preis eines Computers berechnen
# Eingabe: ein Computer
# Ergebnis: Preis in Euro (int)
def computerPreis(c: Computer) -> int:
    ramPreis = c.hauptspeicher * 5
    if ramPreis < 30:
        ramPreis = 30
    plattenPreis = ((c.festplatte + 499) // 500) * 20
    prozessorPreis = 90
    if 'Intel' in c.prozessor:
        prozessorPreis = prozessorPreis + 20
    return ramPreis + plattenPreis + prozessorPreis + 100


check(computerPreis(Computer('AMD', 500, 4)), 240)
check(computerPreis(Computer('AMD', 501, 6)), 260)
check(computerPreis(Computer('Intel i9', 1100, 16)), 350)
check(computerPreis(Computer('Intel i5', 1500, 16)), 350)


# Hauptspeicher eines Computers erweitern
# Eingaben: ein Computer und die Erweiterung in Gigabyte (int)
# Ergebnis: ein Computer mit dem erweiterten Hauptspeicher
def erweitereHauptspeicher(c: Computer, menge: int) -> Computer:
    if menge < 0:
        menge = 0
    return Computer(c.prozessor, c.festplatte, c.hauptspeicher + menge)


check(erweitereHauptspeicher(Computer('AMD', 500, 8), 4),
      Computer('AMD', 500, 12))
check(erweitereHauptspeicher(Computer('AMD', 500, 8), 0),
      Computer('AMD', 500, 8))
check(erweitereHauptspeicher(Computer('AMD', 500, 8), -4),
      Computer('AMD', 500, 8))
