from wypp import *


# Ein Name besteht aus:
# - Vorname (str)
# - Nachname (str)
@record
class Name:
    vorname: str
    nachname: str


# Eine Adresse besteht aus:
# - Name (Name)
# - Straße und Hausnummer (str)
# - Zusatz, eventuell leer (str)
# - Postleitzahl (str)
# - Stadt (str)
# - Land (str)
@record
class Adresse:
    name: Name
    strasseUndNummer: str
    zusatz: str
    plz: str
    stadt: str
    land: str


# Nachnamen einer Adresse ändern
# Eingaben: eine Adresse und ein neuer Nachname (str)
# Ergebnis: die Adresse mit geändertem Nachnamen
def aendereNachname(a: Adresse, neu: str) -> Adresse:
    return Adresse(Name(a.name.vorname, neu), a.strasseUndNummer,
                   a.zusatz, a.plz, a.stadt, a.land)


# Adresse für einen Briefumschlag formatieren
# Eingabe: eine Adresse
# Ergebnis: die mehrzeilige Anschrift (str)
def briefanschrift(a: Adresse) -> str:
    zeilen = a.name.vorname + ' ' + a.name.nachname
    zeilen = zeilen + '\n' + a.strasseUndNummer
    if a.zusatz != '':
        zeilen = zeilen + '\n' + a.zusatz
    return zeilen + '\n' + a.plz + ' ' + a.stadt + '\n' + a.land


a1 = Adresse(Name('Masimo', 'Bastimo'), 'Hauptstraße 7', '',
             '77694', 'Kehl', 'Deutschland')
a2 = Adresse(Name('Ali', 'Baba'), 'Rheinstraße 12', '',
             '77694', 'Kehl', 'Deutschland')
a3 = Adresse(Name('Adrian', 'Devlin'), 'Bahnhofstraße 3', '',
             '77694', 'Kehl', 'Deutschland')

check(aendereNachname(a1, 'Baba'),
      Adresse(Name('Masimo', 'Baba'), 'Hauptstraße 7', '',
              '77694', 'Kehl', 'Deutschland'))
check(briefanschrift(a1),
      'Masimo Bastimo\nHauptstraße 7\n77694 Kehl\nDeutschland')
check(briefanschrift(a2),
      'Ali Baba\nRheinstraße 12\n77694 Kehl\nDeutschland')
check(briefanschrift(a3),
      'Adrian Devlin\nBahnhofstraße 3\n77694 Kehl\nDeutschland')
