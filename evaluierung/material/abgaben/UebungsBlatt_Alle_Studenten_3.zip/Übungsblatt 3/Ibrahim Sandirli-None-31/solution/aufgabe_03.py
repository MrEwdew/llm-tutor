from wypp import *

# Eine Adresse hat:
# - Namen,              (str)
# - Straße + Hausnummer,  (str)
# - Zusatz                (str)
# - Postleitzahl,         (str)
# - Stadt,                (str)
# - Land                  (str)
# Ein Name besteht aus:
# - Vornamen    (str)
# - Nachnamen   (str)

@record
class Name:
    vorname: str
    nachname: str


@record
class Adresse:
    name: Name 
    strasse: str
    hausnummer: int
    zusatz: str
    plz: int
    stadt: str
    land: str



# Funktion zur Namensänderung
# Eingabe:
# - Adresse und Namen (str)
# Ausgabe:
# - Adresse und neuen Namen (str)

# Beispiel Adressen:
musterstraße = Adresse(Name("Muster", "Mustermann"), "Musterstraße", 23, "", 79683, "Musterstadt", "Musterland")
bauhaus = Adresse(Name("Maxi", "Meusel"), "Kleinstraße", 19, "A-Gebäude", 98765, "Fleur", "Wunderland")

def changeName(c: Adresse, neuernachname: str) -> Adresse:
    return Adresse(Name(c.name.vorname, neuernachname), c.strasse, c.hausnummer, c.zusatz, c.plz, c.stadt, c.land)
    


check(changeName(musterstraße, "Müller"), Adresse(Name("Muster", "Müller"), "Musterstraße", 23, "", 79683, "Musterstadt", "Musterland"))
check(changeName(bauhaus, "King"), Adresse(Name("Maxi", "King"), "Kleinstraße", 19, "A-Gebäude", 98765, "Fleur", "Wunderland"))


# Foramtierung der Adresse für einen Brief
def formatBrief(a: Adresse) -> str:
    if a.zusatz != "":
        return a.name.vorname + " " + a.name.nachname + "\n" + a.strasse + " " +str(a.hausnummer) + "\n" + a.zusatz + "\n" + str(a.plz) + " " + a.stadt + "\n" + a.land
    else:
        return a.name.vorname + " " + a.name.nachname + "\n" + a.strasse + " " + str(a.hausnummer) + "\n" + str(a.plz) + " " + a.stadt + "\n" + a.land
    

check(formatBrief(musterstraße), "Muster Mustermann\nMusterstraße 23\n79683 Musterstadt\nMusterland")
check(formatBrief(bauhaus), "Maxi Meusel\nKleinstraße 19\nA-Gebäude\n98765 Fleur\nWunderland")