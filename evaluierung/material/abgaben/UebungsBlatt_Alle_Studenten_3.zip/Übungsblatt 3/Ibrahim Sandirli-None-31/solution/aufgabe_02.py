from wypp import * 

# City Maut für Offenburg
# volgende Kriterien:
# Input:
# - CityMaut bezahlt?    (bool)
# - Sondergenehmigung?   (bool)
# - Schadstoffklasse?    (int)
# Output:
# - erlaubt oder verboten   (str)

# Maut Kriterien sind:
# - Einfahrt erlaubt    (str)
# - Einfahrt verboten   (str)

type Einfahrt = Literal["Einfahrt erlaubt", "Einfahrt verboten"] 

# Datenbeschreibung Schadstoffklasse:
# - gültig 5,6              (int)
# - Sondergenehmigung 1-4   (int)

type Schadstoffklasse = Literal[1,2,3,4,5,6]

@record
class Klasse:
    schadstoffklasse: Schadstoffklasse
    sondergenhemigung: bool
    mautbezahlt: bool 


# Funktion zum Test der Maut Kriterien

def Maut(k: Klasse) -> Einfahrt:
    if k.schadstoffklasse < 5:
        if k.sondergenhemigung and k.mautbezahlt:
            return "Einfahrt erlaubt"
        else:
            return "Einfahrt verboten"
    elif k.sondergenhemigung or k.mautbezahlt:
        return "Einfahrt erlaubt"
    else:
        return "Einfahrt verboten"
    

check(Maut(Klasse(2, True, False)), "Einfahrt verboten")
check(Maut(Klasse(4, False, True)), "Einfahrt verboten")
check(Maut(Klasse(5, True, False)), "Einfahrt erlaubt")
check(Maut(Klasse(5, False, True)), "Einfahrt erlaubt")
check(Maut(Klasse(6, False, False)), "Einfahrt verboten")



