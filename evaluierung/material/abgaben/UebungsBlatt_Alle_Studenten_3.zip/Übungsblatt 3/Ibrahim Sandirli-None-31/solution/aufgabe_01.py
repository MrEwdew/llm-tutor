from wypp import *

# Berechnung der Kosten eines Computers
# - CPU kostet 90€, Aufschlag von 20€ falls Intel
# - Arbeitsspeicher für jedes GB 5€ mindestens 30€/6GB
# - Festplatte je 500GB 20€ , aufgerundet in 500GB Schritte


# TYPEDEFINITION
type ComputerModel = Literal['budget', 'gaming', 'office']

# DATENBESCHREIBUNG
# Ein Computer besteht aus:
# - CPU (str)
# - Festplatte in GB (int)
# - Arbeitsspeicher in GB (int)
@record
class Computer:
    cpu: str
    harddrive: int
    ram: int

# Fehlermeldung bei Speicher Verringerung
@record
class ERROR:
    message: str


# Beispiel Computer
gaming = Computer("AMD R9", 4000, 64)
office = Computer("Intel i5", 1000, 16)
budget = Computer("Intel i3", 250, 8)
    
# Funktion zur Errechnung eines Computers (Teil A)
def Computercost(c: Computer) -> int:
    harddrivecost = math.ceil(c.harddrive /500) * 20
    ramcost = 30 if c.ram < 6 else c.ram * 5
    cpucost = 110 if "Intel" in c.cpu else 90
    return harddrivecost + ramcost + cpucost + 100

# Checks Computer Kosten
check(Computercost(gaming), 670)
check(Computercost(office), 330)
check(Computercost(budget), 270)


# Funktion zur Erweiterung von RAM (Teil B)
def RAMextend(m: Computer, ram: int) -> Union[Computer, ERROR]:
    if m.ram < ram:
        return Computer(m.cpu, m.harddrive, ram)
    elif m.ram == ram:
        return m
    else:
        return ERROR("RAM can't be decreased")

# Check für Memory extend
check(RAMextend(gaming, 128), Computer("AMD R9", 4000, 128))
check(RAMextend(budget, 16), Computer("Intel i3", 250, 16))
check(RAMextend(office, 32), Computer("Intel i5", 1000, 32))

# Check für Memory equal
check(RAMextend(gaming, 64), gaming)
check(RAMextend(budget, 8), budget)
check(RAMextend(office, 16), office)

# Check für ERROR
check(RAMextend(gaming, 32), ERROR("RAM can't be decreased"))
check(RAMextend(office, 8), ERROR("RAM can't be decreased"))
check(RAMextend(budget, 6), ERROR("RAM can't be decreased"))
