from wypp import *

# Eine Ampel hat 3 verschiedene Farben
# - grün
# - geld
# - rot

type Ampel = Literal["grün", "gelb", "rot"]

# Datenbeschreibung Zuckerarten
# Es gibt:
# - fruktose    (float)
# - glukose     (float)

@record
class Zuckerarten:
    fruktose: float
    glukose: float 

# Der Zuckergehalt lässt sich über 2 verschiedene Werte bestimmen
# - Zuckerarten
# - Ampel

type Zuckergehalt = Union[Zuckerarten, float, Ampel]   

# Lebensmittel bestehen aus:
# - Name            (str)
# - Packungsgröße   (float)
# - Zuckergehalt    (Zuckergehalt)

@record
class Lebensmittel:
    name: str
    packungsgröße: float
    zuckergehalt: Zuckergehalt


# Beispiel Lebensmittel

cola = Lebensmittel("Coca Cola", 500, Zuckerarten(25, 25))
ritter = Lebensmittel("Ritter Sport himmlische Beere", 100, Zuckerarten(15.29, 24.9))
kürbis = Lebensmittel("Kürbis", 1000, 2.8)
gurke = Lebensmittel("Gurke", 470, "grün")


# HilfsFunktion zur Berechnung Zuckergehalt pro 100g

def berechnenZucker(z: Zuckerarten, packung: float) -> float:
    return (z.fruktose + z.glukose) / packung * 100

check(berechnenZucker(Zuckerarten(12, 47), 250), 23.6)
check(berechnenZucker(Zuckerarten(15.29, 24.9), 100), 40.19)


# HauptFunktion zur Bestimmung der Ampelfarbe
# Eingabe:
# - Lebensmittel
# - Zuckerarten
# - HilfsFunktion berechnenZucker
# Ausgabe:
# - Zuckergehalt in Ampelfarbe

def zuckerAmpel(l: Lebensmittel) -> Ampel:
    if isinstance(l.zuckergehalt, Zuckerarten):
        zucker = berechnenZucker(l.zuckergehalt, l.packungsgröße)
    elif isinstance(l.zuckergehalt, (int, float)):
        zucker = l.zuckergehalt
    else:
        return l.zuckergehalt
    
    if zucker < 5:
        return "grün"
    elif zucker <= 22.5:
        return "gelb"
    else:
        return "rot"



check(zuckerAmpel(cola), "gelb")
check(zuckerAmpel(ritter), "rot")
check(zuckerAmpel(kürbis), "grün")
check(zuckerAmpel(gurke), "grün")