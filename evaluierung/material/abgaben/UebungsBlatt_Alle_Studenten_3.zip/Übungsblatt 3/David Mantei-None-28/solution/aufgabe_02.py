from wypp import *

# Schadstoffklasse von 1 bis 6.

type Schadstoffklasse = Literal[1, 2, 3, 4, 5, 6]

# Die Maut-Kriterien bestehen aus:
# - Maut bezahlt (Typ: bool)
# - Sondergenehmigung vorhanden (Typ: bool)
# - Schadstoffklasse (Typ: Schadstoffklasse)

@record
class MautKriterien:
    bezahlt: bool
    sondergenehmigung: bool
    schadstoffklasse: Schadstoffklasse

# Prüft, ob ein Auto in Offenburg einfahren darf.
# Eingabe: Maut (Typ: MautKriterien)
# Ergebnis: Einfahrt erlaubt oder nicht (Typ: bool)

def darfEinfahren(Maut: MautKriterien) -> bool:
    if Maut.schadstoffklasse == 5 or Maut.schadstoffklasse == 6:
        return Maut.bezahlt or Maut.sondergenehmigung
    else:
        return Maut.bezahlt and Maut.sondergenehmigung

check(darfEinfahren(MautKriterien(True, False, 6)), True)
check(darfEinfahren(MautKriterien(False, True, 6)), True)
check(darfEinfahren(MautKriterien(False, False, 6)), False)
check(darfEinfahren(MautKriterien(True, True, 3)), True)
check(darfEinfahren(MautKriterien(True, False, 3)), False)
check(darfEinfahren(MautKriterien(False, True, 3)), False)
check(darfEinfahren(MautKriterien(False, True, 5)), True)
