from wypp import *

# Ein Name besteht aus:
# - Vorname (str)
# - Nachname (str)

@record
class Name:
    vorname: str
    nachname: str

# Eine Adresse besteht aus:
# - Name (Name)
# - Straße und Hausnummer (str)
# - Zusatz, darf leer sein (str)
# - Postleitzahl (str)
# - Stadt (str)
# - Land (str)

@record
class Adresse:
    name: Name
    strasseHausnummer: str
    zusatz: str
    plz: str
    stadt: str
    land: str

adresse1 = Adresse(
    Name('Yven', 'Bakus'),
    'Hauptstraße 10',
    '',
    '77652',
    'Freiburg',
    'Deutschland'
)

adresse2 = Adresse(
    Name('Edwin', 'Weigel'),
    'Musterweg 2',
    '1. OG',
    '77694',
    'Kehl',
    'Deutschland'
)

# Ändert den Nachnamen einer Adresse.
# Eingabe: Adresse (Typ: Adresse) und neuer Nachname (str)
# Ergebnis: Adresse mit geändertem Nachnamen

def aendereNachname(a: Adresse, neuerNachname: str) -> Adresse:
    neuerName = Name(a.name.vorname, neuerNachname)
    return Adresse(neuerName,a.strasseHausnummer,a.zusatz,a.plz,a.stadt,a.land)

check(aendereNachname(adresse1, 'Musterfrau'),
        Adresse(
            Name('Yven', 'Musterfrau'),
            'Hauptstraße 10',
            '',
            '77652',
            'Freiburg',
            'Deutschland'
        )
    )
    
check(aendereNachname(adresse2, 'Byron'),
        Adresse(
            Name('Edwin', 'Byron'),
            'Musterweg 2',
            '1. OG',
            '77694',
            'Kehl',
            'Deutschland'
        )
    )

# Formatiert eine Adresse für einen Briefumschlag.
# Eingabe: eine Adresse (Typ: Adresse)
# Ergebnis: formatierte Adresse (str)

def formatiereAdresse(a: Adresse) -> str:
    ergebnis = a.name.vorname + ' ' + a.name.nachname + ', ' + a.strasseHausnummer

    if a.zusatz != '':
        ergebnis = ergebnis + ', ' + a.zusatz

    return ergebnis + ', ' + a.plz + ' ' + a.stadt + ', ' + a.land

check(formatiereAdresse(adresse1), 'Yven Bakus, Hauptstraße 10, 77652 Freiburg, Deutschland')
check(formatiereAdresse(adresse2), 'Edwin Weigel, Musterweg 2, 1. OG, 77694 Kehl, Deutschland')