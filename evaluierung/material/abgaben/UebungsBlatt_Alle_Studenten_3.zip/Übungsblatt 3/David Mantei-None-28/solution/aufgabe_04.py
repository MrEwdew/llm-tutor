from wypp import *

# Der Zuckergehalt kann auf drei Arten angegeben werden:
# - Fruktose und Glukose in Gramm (ZuckerArten)
# - Zucker in Gramm pro 100g (ZuckerPro100g)
# - Ampelfarbe (Ampelfarbe)

# Zuckergehalt aufgeteilt in Fruktose und Glukose.
@record
class ZuckerArten:
    fruktose: float
    glukose: float

# Zuckergehalt in Gramm pro 100g.
@record
class ZuckerPro100g:
    gramm: float


# Eine Ampelfarbe ist:
# - grün
# - gelb
# - rot

type Ampelfarbe = Literal['grün', 'gelb', 'rot']

# Gemischter Datentyp für den Zuckergehalt.
type Zuckergehalt = Union[ZuckerArten, ZuckerPro100g, Ampelfarbe]

# Ein Lebensmittel besteht aus:
# - Name (str)
# - Packungsgröße in Gramm (int, größer als 0)
# - Zuckergehalt (Zuckergehalt)

@record
class Lebensmittel:
    name: str
    packungsgroesse: int
    zucker: Zuckergehalt

# Beispieldaten

cola = Lebensmittel('Coca Cola',500,ZuckerArten(25.0, 25.0))
ritter = Lebensmittel('Ritter Sport himmlische Beere',100,ZuckerArten(15.29, 24.9))
kuerbis = Lebensmittel('Kürbis',1000,ZuckerPro100g(2.8))
gurke = Lebensmittel('Gurke',470,'grün')

# Berechnet den Gesamtzuckergehalt in Gramm pro 100g.
# Eingabe: ZuckerArten und Packungsgröße in Gramm (int, größer als 0)
# Ergebnis: Zuckergehalt in Gramm pro 100g (float)

def berechneZuckerPro100g(z: ZuckerArten, packungsgroesse: int) -> float:
    return (z.fruktose + z.glukose) * 100 / packungsgroesse

check(berechneZuckerPro100g(ZuckerArten(25.0, 25.0), 500),10.0)
check(berechneZuckerPro100g(ZuckerArten(0.0, 5.0), 100),5.0)

# Bestimmt die Ampelfarbe eines Lebensmittels anhand seines Zuckergehalts.
# Eingabe: ein Lebensmittel
# Ergebnis: Ampelfarbe (grün, gelb oder rot)

def zuckerAmpel(l: Lebensmittel) -> Ampelfarbe:
    if isinstance(l.zucker, str):
        return l.zucker
    elif isinstance(l.zucker, ZuckerArten):
        zuckerPro100 = berechneZuckerPro100g(l.zucker,l.packungsgroesse)
    else:
        zuckerPro100 = l.zucker.gramm
    if zuckerPro100 < 5:
        return 'grün'
    elif zuckerPro100 <= 22.5:
        return 'gelb'
    else:
        return 'rot'

check(zuckerAmpel(cola), 'gelb')
check(zuckerAmpel(ritter), 'rot')
check(zuckerAmpel(kuerbis), 'grün')
check(zuckerAmpel(gurke), 'grün')
check(zuckerAmpel(Lebensmittel('Grenze 5', 100, ZuckerPro100g(5.0))),'gelb')
check(zuckerAmpel(Lebensmittel('Grenze 22,5', 100, ZuckerPro100g(22.5))),'gelb')
check(zuckerAmpel(Lebensmittel('Über 22,5', 100, ZuckerPro100g(22.6))),'rot')
