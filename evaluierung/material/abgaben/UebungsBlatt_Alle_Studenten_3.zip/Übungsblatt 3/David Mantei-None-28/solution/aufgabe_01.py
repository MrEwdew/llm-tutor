from wypp import *

# Ein Computer besteht aus:
# - Prozessor (str)
# - Festplatten-Kapazität in Gigabyte (int)
# - Hauptspeicher-Kapazität in Gigabyte (int)

@record
class Computer:
    prozessor: str
    festplatte: int
    hauptspeicher: int

# Berechnet den Gesamtpreis eines Computers in Euro.
# Eingabe: ein Computer (Typ: Computer)
# Ergebnis: Gesamtpreis in Euro (int)

def computerPreis(c: Computer) -> int:

    # Preis für den Arbeitsspeicher
    ramPreis = c.hauptspeicher * 5
    if ramPreis < 30:
        ramPreis = 30

    # Preis für die Festplatte
    festplattenPreis = (c.festplatte // 500) * 20
    if c.festplatte % 500 != 0:
        festplattenPreis = festplattenPreis + 20

    # Preis für den Prozessor
    prozessorPreis = 90
    if 'Intel' in c.prozessor:
        prozessorPreis = prozessorPreis + 20

    # Preis für weitere Komponenten und Montage
    montagePreis = 100

    # Gesamtpreis berechnen
    gesamtPreis = ramPreis + festplattenPreis + prozessorPreis + montagePreis
    return gesamtPreis

check(computerPreis(Computer('Intel i9', 1000, 16)), 330)
check(computerPreis(Computer('AMD Ryzen', 1100, 4)), 280)
check(computerPreis(Computer('Intel i7', 750, 8)), 290)
check(computerPreis(Computer('AMD', 500, 8)), 250)


# Erweitert den Hauptspeicher eines Computers, ohne ihn zu verkleinern.
# Eingabe: ein Computer und zusätzliche GB (int)
# Ergebnis: ein Computer mit erweitertem Hauptspeicher

def erweitereHauptspeicher(c: Computer, zusaetzlicheGB: int) -> Computer:
    if zusaetzlicheGB < 0:
        return c
    else:
        neuerSpeicher = c.hauptspeicher + zusaetzlicheGB
        return Computer(c.prozessor, c.festplatte, neuerSpeicher)

check(erweitereHauptspeicher(Computer('AMD', 500, 8), 8), Computer('AMD', 500, 16))
check(erweitereHauptspeicher(Computer('Intel i7', 750, 16), -5), Computer('Intel i7', 750, 16))
check(erweitereHauptspeicher(Computer('Intel i7', 750, 16), 0), Computer('Intel i7', 750, 16))