from wypp import * 

@record 
class Zuckeranteil:
    fruktoseanteil: float
    glukoseanteil: float

@record 
class Zuckerprozent:
    prozent: float

type Zuckerampel = Literal['grün', 'gelb', 'rot']

@record 
class Lebensmittel: 
    name: str
    packungsgröße: int 
    zuckergehalt: Union[Zuckeranteil, Zuckerprozent, Zuckerampel]

cola = Lebensmittel("Coca Cola", 500, Zuckeranteil(25, 25))
ritter_sport = Lebensmittel("Ritter Sport himmlische Beere", 100, Zuckeranteil(15.29, 24.9))
kürbis = Lebensmittel("Kürbis", 1000, Zuckerprozent(2.8))
gurke = Lebensmittel("Gurke", 470, 'grün')

# Hilfsfunktion, die für einen Zuckergehalt, der als Zuckeranteil angegeben ist, Zuckerprozent (pro 100g) berechnet 
# Eingabe: Record-Objekt Zuckeranteil (typ: zuckeranteil) / Packungsgröße (1=100g...) (typ: float)
# Ausgabe: Zucker in Prozent (typ: float)
def zuckeranteil(z: Zuckeranteil, size: float) -> float:
    return (z.fruktoseanteil + z.glukoseanteil) / size 


# Funktion, die für ein Lebensmittel berechnet, in welche Ampelfarbe es fällt 
# Eingabe: Record-Objekt Lebensmittel (typ: Lebensmittel)
# Ausgabe: Ampelfarbe (typ: zuckerampel)
def ampelfarbe(l: Lebensmittel) -> Zuckerampel:
    
    # Fall 1) Zuckeraufteilung in Glukose und Fruktose
    if isinstance(l.zuckergehalt, Zuckeranteil):      
        zuckerprozent = zuckeranteil(l.zuckergehalt, (l.packungsgröße/100))
    # Fall 2) Zuckeranteil in Prozent
    elif isinstance(l.zuckergehalt, Zuckerprozent):
        zuckerprozent = l.zuckergehalt.prozent
    # Fall 3) Zuckeranteil bereits in Ampelfarbe
    elif isinstance(l.zuckergehalt, Zuckerampel):
        return l.zuckergehalt

    if zuckerprozent < 5:
        return 'grün'
    elif zuckerprozent >= 5 and zuckerprozent <= 22.5:
        return 'gelb'
    elif zuckerprozent > 22.5:
        return 'rot'

check(ampelfarbe(cola), 'gelb')
check(ampelfarbe(ritter_sport), 'rot')
check(ampelfarbe(kürbis), 'grün')
