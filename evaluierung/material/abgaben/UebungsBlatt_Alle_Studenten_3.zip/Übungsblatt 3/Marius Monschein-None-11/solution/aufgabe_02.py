from wypp import * 

@record 
class citymaut:
    bezahlt: bool
    sondergenehmigung: bool
    schadstoffklasse: int

# Funktion, die aus Maut-Kriterien berechnet, ob eine Einfahrt möglich ist
# Eingabe: Record-Objekt Citymaut (typ: citymaut)
# Ausgabe: True, falls Einfahrt möglich (typ: bool)
def einfahrt(c: citymaut) -> bool:
    # Fall 1) Maut nicht bezahlt
    if not c.bezahlt:
        if c.sondergenehmigung:
            return True
        else:
            return False 

    # Fall 2) Auto nicht Schadstoffklasse 5 oder 6
    if (c.schadstoffklasse != 5) or (c.schadstoffklasse !=6):
        if (c.bezahlt is True) and (c.sondergenehmigung is True):
            return True 
        else: 
            return False 

    return False 

# Fall 1)
check(einfahrt(citymaut(False, True, 5)), True)
check(einfahrt(citymaut(False, False, 5)), False)

# Fall 2) 
check(einfahrt(citymaut(True, True, 4)), True)
check(einfahrt(citymaut(True, False, 4)), False)
check(einfahrt(citymaut(False, False, 4)), False)
