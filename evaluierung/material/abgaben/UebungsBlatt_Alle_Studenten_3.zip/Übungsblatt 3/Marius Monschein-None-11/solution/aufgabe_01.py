from wypp import * 

@record
class Computer:
    prozessor: str
    festplatte: int
    hauptspeicher: int

# Funktion, die den Preis eines Computers berechent 
# Eingabe: Record-Objekt Computer (typ: Computer)
# Ausgabe: Preis in Euro (typ: int)
from wypp import *

@record
class Computer:
    prozessor: str
    festplatte: int
    hauptspeicher: int

def totalprice(c: Computer) -> int:
    total_price = 100

    total_price += max(c.hauptspeicher * 5, 30)

    if c.festplatte % 500 > 0:
        number = (c.festplatte // 500) + 1
    else: 
        number = c.festplatte // 500
    
    total_price += number * 20

    if 'Intel' in c.prozessor:
        total_price += 110
    else:
        total_price += 90

    return total_price

c1 = Computer('Int500', 500, 5)
c2 = Computer('Intel500', 500, 5)
c3 = Computer('Intel500', 600, 5)
c4 = Computer('Intel500', 600, 7)

check(totalprice(c1), 100 + 90 + 20 + 30)
check(totalprice(c2), 100 + 110 + 20 + 30)
check(totalprice(c3), 100 + 110 + 40 + 30)
check(totalprice(c4), 100 + 110 + 40 + 35)


# Funktion, die den Arbeitsspeicher erweitert 
# Eingabe: Computer (typ: Computer) / Speichermenge (typ: int)
# Ausgabe: Computer mit erweiterter Speichermenge (typ: int)
def expandram(c: Computer, ram: int) -> Computer:
    if ram <= 0:
        return c 
    else: 
        new_ram = c.hauptspeicher + ram
        return Computer(c.prozessor, c.festplatte, new_ram)

check(expandram(c1, 5), Computer('Int500', 500, 10))
check(expandram(c1, -1), Computer('Int500', 500, 5))
