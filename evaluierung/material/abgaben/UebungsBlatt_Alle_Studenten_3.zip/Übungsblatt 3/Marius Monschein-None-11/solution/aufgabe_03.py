from wypp import * 

@record
class name:
    vorname: str
    nachname: str 

@record
class adresse:
    name: name
    straße: str
    zusatz: Union[None, str]
    postleitzahl: int
    stadt: str
    land: str 

# Funktion, die den Nachnamen einer gegebenen Adresse ändert 
# Eingabe: Record-Objekt Adresse (typ: adresse) / neuer Nachname (typ: str)
# Ausgabe: Record-Objekt Adresse mit neuem Nachnamen (typ: adresse)
def nachname(a: adresse, nachname: str) -> adresse:
    return adresse(name(a.name.vorname, nachname), a.straße, a.zusatz, a.postleitzahl, a.stadt, a.land)

name1 = name("Marius", "Heide")
a1 = adresse(name1, "Haupstraße77", "Zusatz", 77704, "Oberkirch", "Deutschland")

check(nachname(a1, "Monschein"), adresse(name("Marius", "Monschein"), "Haupstraße77", "Zusatz", 77704, "Oberkirch", "Deutschland"))

# Funktion, die eine Adresse für einen Briefumschlag formatiert
# Eingabe: Record-Objekt Adresse (typ: adresse)
# Ausgabe: formatierter Briefumschlag (typ: None)