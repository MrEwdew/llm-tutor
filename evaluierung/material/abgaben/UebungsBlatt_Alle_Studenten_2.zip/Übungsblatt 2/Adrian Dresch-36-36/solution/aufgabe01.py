from wypp import *

#Beschreibung: Prüft, ob eine Zahl eine Lieblingszahl von Luise ist.
#Eingabe: Eine ganze Zahl (int).
#Ergebnis: Ein Wahrheitswert (bool): True, wenn die Zahl 6, 11, 13 oder größer als 100 ist, sonst False


def ist_lieblingszahl(zahl: int) -> bool:
    return zahl == 6 or zahl == 11 or zahl == 13 or zahl > 100


check(ist_lieblingszahl(6), True)
check(ist_lieblingszahl(11), True)
check(ist_lieblingszahl(13), True)
check(ist_lieblingszahl(12), False)
check(ist_lieblingszahl(100), False)
check(ist_lieblingszahl(101), True)
check(ist_lieblingszahl(0), False)
check(ist_lieblingszahl(-1), False)