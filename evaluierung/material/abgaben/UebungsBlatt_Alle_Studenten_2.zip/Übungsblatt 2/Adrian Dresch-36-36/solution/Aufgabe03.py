from wypp import *

# Beschreibung: Berechnet das Bußgeld für zu langes Parken.
# Eingabe: Die positive Überschreitungsdauer in Minuten (float).
# Ergebnis: Das zu zahlende Bußgeld in Euro (int).
def berechne_bussgeld(minuten: float) -> int:
    if minuten <= 30:
        return 10
    elif minuten <= 60:
        return 15
    elif minuten <= 120:
        return 20
    elif minuten <= 180:
        return 25
    else:
        n = math.ceil(minuten / 60)
        return (n - 1) * 10


check(berechne_bussgeld(1), 10)
check(berechne_bussgeld(30), 10)
check(berechne_bussgeld(30.5), 15)
check(berechne_bussgeld(60), 15)
check(berechne_bussgeld(61), 20)
check(berechne_bussgeld(120), 20)
check(berechne_bussgeld(121), 25)
check(berechne_bussgeld(180), 25)
check(berechne_bussgeld(181), 30)
check(berechne_bussgeld(240), 30)
check(berechne_bussgeld(241), 40)