from wypp import *

#Beschreibung: Bestimmt die Position einer Spielerin anhand ihrer Rückennummer.
#Eingabe: Eine gültige Rückennummer zwischen 1 und 99 (int).
#Ergebnis: Die zugehörige Position vom Typ Position.



type Position = Literal[
    'Torhüterin',
    'Abwehrspielerin',
    'Mittelfeldspielerin',
    'Stürmerin',
    'Ersatzspielerin'
]


def bestimme_position(rueckennummer: int) -> Position:
    if rueckennummer == 1:
        return 'Torhüterin'
    elif rueckennummer >= 2 and rueckennummer <= 5:
        return 'Abwehrspielerin'
    elif rueckennummer == 6 or rueckennummer == 7 or rueckennummer == 8 or rueckennummer == 10:
        return 'Mittelfeldspielerin'
    elif rueckennummer == 9 or rueckennummer == 11:
        return 'Stürmerin'
    elif rueckennummer >= 12 and rueckennummer <= 99:
        return 'Ersatzspielerin'


check(bestimme_position(1), 'Torhüterin')
check(bestimme_position(2), 'Abwehrspielerin')
check(bestimme_position(3), 'Abwehrspielerin')
check(bestimme_position(4), 'Abwehrspielerin')
check(bestimme_position(5), 'Abwehrspielerin')
check(bestimme_position(6), 'Mittelfeldspielerin')
check(bestimme_position(7), 'Mittelfeldspielerin')
check(bestimme_position(8), 'Mittelfeldspielerin')
check(bestimme_position(10), 'Mittelfeldspielerin')
check(bestimme_position(9), 'Stürmerin')
check(bestimme_position(11), 'Stürmerin')
check(bestimme_position(12), 'Ersatzspielerin')
check(bestimme_position(99), 'Ersatzspielerin')