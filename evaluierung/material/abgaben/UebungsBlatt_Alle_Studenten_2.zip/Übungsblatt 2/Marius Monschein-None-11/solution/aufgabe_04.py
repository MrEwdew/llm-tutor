from wypp import * 

# Funktion, die eine obere & unter Schranke hat
# Eingabe: x (typ: int) / l (typ: int) / u (typ: int)
# Ausgabe: x oder l oder u (typ: int)
def clamp(x: int, l: int, u: int) ->int:
    if x >= l and x <= u:
        return x
    elif x < l:
        return l 
    elif x > u:
        return u 


check(clamp(5, 3, 7), 5)
check(clamp(2, 3, 7), 3)
check(clamp(8, 3, 7), 7)