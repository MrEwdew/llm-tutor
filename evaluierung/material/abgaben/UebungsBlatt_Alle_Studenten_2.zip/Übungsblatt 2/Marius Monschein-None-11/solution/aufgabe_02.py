from wypp import * 

type Spielerposition = Literal['Torhüterin', 'Abwehrspielerin', 'Mittelfeldspielerin', 'Stürmerin', 'Ersatzspielerin']

# Funktion, die für eine Rückennummer die Spielerposition zurückgibt 
# Eingaeb: Rückennummer (typ: int)
# Ausgabe: Spielerpositon (typ: Spielerposition)
def spielerposition(Rückennummer: int) -> Spielerposition:
    if Rückennummer == 1:
        return "Torhüterin"
    elif Rückennummer >= 2 and Rückennummer <= 5:
        return "Abwehrspielerin"
    elif Rückennummer >= 6 and Rückennummer <= 8 or Rückennummer == 10:
        return "Mittelfeldspielerin"
    elif Rückennummer == 9 or Rückennummer == 11: 
        return "Stürmerin"
    elif Rückennummer >= 12 and Rückennummer <= 99:
        return 'Ersatzspielerin'

check(spielerposition(1), "Torhüterin")
check(spielerposition(2), "Abwehrspielerin")
check(spielerposition(5), "Abwehrspielerin")
check(spielerposition(6), "Mittelfeldspielerin")
check(spielerposition(10), "Mittelfeldspielerin")
check(spielerposition(9), "Stürmerin")
check(spielerposition(11), "Stürmerin")
check(spielerposition(12), "Ersatzspielerin")
check(spielerposition(99), "Ersatzspielerin")