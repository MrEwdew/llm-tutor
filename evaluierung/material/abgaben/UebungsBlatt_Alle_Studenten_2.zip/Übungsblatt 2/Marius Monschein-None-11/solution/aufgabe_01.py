from wypp import * 

# Funktion, welche True für Lieblingszahl ausgibt 
# Eingabe: Zahl (typ: int)
# Ausgabe: True, wenn Lieblingszahl (typ: bool)
def lieblingszahl(zahl: int) -> bool:
    if (zahl == 6) or (zahl == 11) or (zahl == 13):
        return True
    elif zahl > 100:
        return True 
    else:
        return False 


check(lieblingszahl(6), True)
check(lieblingszahl(11), True)
check(lieblingszahl(12), False)
check(lieblingszahl(13), True)
check(lieblingszahl(145), True)