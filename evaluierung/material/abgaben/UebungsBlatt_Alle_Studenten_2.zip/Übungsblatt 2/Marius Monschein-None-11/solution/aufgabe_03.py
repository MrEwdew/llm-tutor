from wypp import * 

# Funktion, welche die Bußgeld für zu langes Parken bestimmt
# Eingabe: Parkzeit in h (typ: float)
# Ausgabe: Bußgeld in Euro (typ: int)
def bußgeld(parkzeit: float) -> int:
    if parkzeit <= 0.5:
        return 10 
    elif parkzeit <= 1:
        return 15 
    elif parkzeit <= 2:
        return 20 
    elif parkzeit <= 3:
        return 25 
    else: 
        return (math.ceil(parkzeit) -1) * 10

check(bußgeld(0.3), 10)
check(bußgeld(0.5), 10)
check(bußgeld(0.6), 15)
check(bußgeld(1), 15)
check(bußgeld(1.4), 20)
check(bußgeld(2), 20)
check(bußgeld(2.4), 25)
check(bußgeld(3), 25)
check(bußgeld(3.4), 30)
check(bußgeld(4.1), 40)