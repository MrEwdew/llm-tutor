from wypp import *

#DATENBESCHREIBUNG

#Eine Fußballposition hat folgende Möglichkeiten:
#Torhüterin,  Abwehrspielerin, Mittelfeldspielerin, Stürmerin, Ersatzspielerin

type Position = Literal["Torhüterin", "Abwehrspielerin","Mittelfeldspielerin", "Stürmerin", "Ersatzspielerin"]

#Funktion, die für eine Rückennummer die passende Position bestimmt

#Eingabe: Rückennummer (int)
#Ergebnis: Position (type: Position)

def bestimmePosition(rückennummer: int)->Position:
    if rückennummer == 1:
        return "Torhüterin"
    elif rückennummer <=5:
        return "Abwehrspielerin"
    elif rückennummer <=8 or rückennummer ==10:
        return "Mittelfeldspielerin"
    elif rückennummer == 9 or rückennummer ==  11:
        return "Stürmerin"
    elif rückennummer <=99:
        return "Ersatzspielerin"


check(bestimmePosition(1), "Torhüterin")
check(bestimmePosition(2), "Abwehrspielerin")
check(bestimmePosition(8), "Mittelfeldspielerin")
check(bestimmePosition(9), "Stürmerin")
check(bestimmePosition(73), "Ersatzspielerin")

