from wypp import *

#Funktion, die für eine beliebige Zahl bestimmt, ob diese eine von Luises' Lieblingszahlen ist

#Eingabe: eine beliebige Zahl (int)
#Ergebnis: Lieblingszahl oder nicht? (bool)

def istLieblingszahl(zahl: int)-> bool:
    if zahl == 6 or zahl == 11 or zahl == 13:
        return True
    elif zahl > 100:
        return True
    else: 
        return False

check(istLieblingszahl(6), True)
check(istLieblingszahl(11), True)
check(istLieblingszahl(13), True)
check(istLieblingszahl(100), False)
check(istLieblingszahl(101), True)