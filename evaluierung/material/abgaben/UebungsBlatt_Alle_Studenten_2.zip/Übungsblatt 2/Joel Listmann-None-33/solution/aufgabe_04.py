from wypp import *

#Funktion, die x, l oder u ausgibt, abhängig davon, ob x zwischen l und u oder außerhalb dieser liegt

#Eingabe: 
#Beliebige Zahl (x) (float)
#Lower bound (l) (float)
#Upper bound (u) (float)
#Ergebnis: x, l oder u

def clamp(x: float,l: float,u: float)-> float:
    if x < l:
        return l
    elif x > u:
        return u
    else:
        return x

check(clamp(2,1,3),2)
check(clamp(4,1,3),3)
check(clamp(0,1,3),1)
check(clamp(1,1,3),1)
check(clamp(4,1,4),4)



