from wypp import *

#Funktion, die ein Bußgeld in abhängigkeit von der Überschreitungsdauer der Höchstparkdauer berechnet

#Eingabe: Überschreitung der Höchstparkdauer (float)
#Ergebnis: Bußgeld in Euro (int)

def berechneBußgeld(überschreitung: float) -> int:
    if überschreitung <= 0.5:
        return 10
    elif überschreitung <=1:
        return 15
    elif überschreitung <=2:
        return 20
    elif überschreitung <=3:
        return 25
    elif überschreitung >3:
        return (math.ceil(überschreitung)-1) *10

    
check(berechneBußgeld(0.5), 10)
check(berechneBußgeld(1), 15)
check(berechneBußgeld(2), 20)
check(berechneBußgeld(3), 25)
check(berechneBußgeld(5), 40)