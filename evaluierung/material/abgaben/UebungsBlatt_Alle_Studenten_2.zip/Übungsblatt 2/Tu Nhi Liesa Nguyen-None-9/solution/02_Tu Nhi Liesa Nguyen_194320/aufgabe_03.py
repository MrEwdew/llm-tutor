from wypp import *

#Aufgabe 3
#Bußgeld für zu langes Parken soll bestimmt werden
#bis 30 Min. = 10€
#bis 1h = 15€
#bis 2h = 20€
#bis 3h = 25€
#mehr als 3h = (Parkdauer aufgerundet auf die nächste Stunde in (n) * 10€)

#aufgerundet mit math.cell

#Zeit wird in Stunden angegeben
# def bußgeldh(zeit: float) -> float:
#     if zeit <= 0.5:
#         return 10.00
    
#     if zeit <= 1:
#         return 15.00
    
#     if zeit <= 2:
#         return 20.00
    
#     if zeit <= 3:
#         return 25.00

#     if zeit > 3:
#         return (math.ceil(zeit)-1) * 10.00
    
#     return

# check(bußgeldh(0.2), 10.00)
# check(bußgeldh(0.7), 15.00)
# check(bußgeldh(1.5), 20.00)
# check(bußgeldh(2.3), 25.00)
# check(bußgeldh(3.5), 40.00)



#Zeit wird in Minuten angegeben
def bußgeldm(minuten: float) -> float:
    if minuten <= 30:
        return 10.00
    
    if minuten <= 60:
        return 15.00
    
    if minuten <= 120:
        return 20.00
    
    if minuten <= 180:
        return 25.00

    if minuten > 180:
        return (math.ceil(minuten/60)-1) * 10.00
    
    return

check(bußgeldm(20), 10.00)
check(bußgeldm(55), 15.00)
check(bußgeldm(107), 20.00)
check(bußgeldm(150), 25.00)
check(bußgeldm(181),30.00)
check(bußgeldm(230), 30.00)
