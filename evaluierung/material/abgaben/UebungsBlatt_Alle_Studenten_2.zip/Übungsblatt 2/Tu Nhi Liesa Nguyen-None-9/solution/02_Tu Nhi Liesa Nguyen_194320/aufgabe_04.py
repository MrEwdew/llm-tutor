from wypp import *

#Aufgabe 4
#clamp Funktion schreiben 
#x bleibt x wenn x>=l und x<=u
#x wird l wenn x<l
#x wird u wenn x>u

def clamp(x: float,
          l: float,
          u: float,) -> float:
    if x >= l and x <= u:
        return x

    elif x < l:
        return l

    elif x > u:
        return u
    
    
check(clamp(1, 10, 20), 10)
check(clamp(100, 10, 90), 90)
check(clamp(20, 10, 30), 20)

