from wypp import *

#Aufgabe 2
#Position der Fußballspielerin anhand der Rückennummer bestimmen.
#Eingabe: Rückennummer
#Ausgabe: Position der Spieler

#Datenbeschreibung:
#-Torhüterin
#-Abwehrspielerin
#-Mittelfeldspielerin
#-Stürmerin
#-Ersatzspielerin

#Typdefinition:
type Position = Literal['Torhüterin', 'Abwehrspielerin', 'Mittelfeldspielerin', 'Stürmerin', 'Ersatzspielerin']

def rueckennummer(nummer: int) -> Position:
    if nummer == 1:
        return 'Torhüterin'

    elif nummer in [2, 3, 4, 5]:
        return 'Abwehrspielerin'

    elif nummer in [6, 7, 8, 10]:
        return 'Mittelfeldspielerin'

    elif nummer == 9 or nummer == 11:
        return 'Stürmerin'

    elif nummer >= 12 and nummer <=99:
        return 'Ersatzspielerin'

check(rueckennummer(1), 'Torhüterin')
check(rueckennummer(4), 'Abwehrspielerin')
check(rueckennummer(10), 'Mittelfeldspielerin')
check(rueckennummer(9), 'Stürmerin')
check(rueckennummer(33), 'Ersatzspielerin')

        