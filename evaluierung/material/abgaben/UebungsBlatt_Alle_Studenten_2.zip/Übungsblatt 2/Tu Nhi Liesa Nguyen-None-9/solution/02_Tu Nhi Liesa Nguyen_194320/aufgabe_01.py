from wypp import *

#Aufgabe 1
#Die Lieblingszahlen von Luise ist gefragt
#Eingabe: int, Zahlen
#Ausgabe: bool, ob es die Lieblingszahl ist

def lieblingszahl(x: int) -> bool:
    #if x in [6,11,13]
    if x == 6 or x == 11 or x == 13:
        return True
    
    if x > 100:
        return True
    
    return False




check(lieblingszahl(11), True)
check(lieblingszahl(1000), True)
check(lieblingszahl(12), False)