from wypp import *

# Datenbeschreibung:
# Anhand von Rückennummern soll die passende Position ausgegeben werden
# Eingabe: Rückenummer (typ: int)
# Ausgabe: Position (typ: str)

#Eine Fußballspielerin kann folgende Positionen haben:
# - Torhüterin
# - Abwehrspielerin
# - Mittelfeldspielerin
# - Stürmerin
# - Ersatzspielerin

type Position = Literal['Torhüterin','Abwehrspielerin','Mittelfeldspielerin','Stürmerin','Ersatzspielerin']


#Kopf
def bestimmtePosition(nummer: int) -> Position:
    if nummer == 1:
        return 'Torhüterin'
    elif nummer >=2 and nummer <=5:
        return 'Abwehrspielerin'
    elif nummer ==6 or nummer ==7 or nummer == 8 or nummer ==10:
        return 'Mittelfeldspielerin'
    elif nummer == 9 or nummer ==11:
        return 'Stürmerin'
    elif nummer >= 12 and nummer <=99:
        return 'Ersatzspielerin'
  
#Checks
check(bestimmtePosition(1),'Torhüterin')
check(bestimmtePosition(2),'Abwehrspielerin')
check(bestimmtePosition(7),'Mittelfeldspielerin')
check(bestimmtePosition(9),'Stürmerin')
check(bestimmtePosition(99),'Ersatzspielerin')


        





