from wypp import *
import math

#Kurzbeschreibung:
#Wir sollen ein Programm schreiben dass die höhe von Busgeldern anhand von überzogener Parkzeit bestimmt.

#Datenanalyse:
#Eingabe: Überzogene Parkzeit in Minuten (typ: int)
#Ausgabe: Bußgelder(Typ: int)

#Kopf
def bussgeldRechner(ueberzogeneZeit: int)-> int:
    if ueberzogeneZeit <= 30:
        return 10
    elif ueberzogeneZeit <= 60:
        return 15
    elif ueberzogeneZeit <= 120:
        return 20
    elif ueberzogeneZeit <= 180:
        return 25
    else: return (math.ceil(ueberzogeneZeit/60)-1) * 10


#Checks
check(bussgeldRechner(30),10)
check(bussgeldRechner(56),15)
check(bussgeldRechner(90),20)
check(bussgeldRechner(130),25)
check(bussgeldRechner(240),30)
check(bussgeldRechner(241),40)
