from wypp import *

#Funktion schreiben, die überprüft ob eine Zahl zu Luisas lieblingszahlen gehört
#Lieblingszahlen: 6, 11, 13, !12, >100

#Eingabe: Zahl typ: int
#Ausgabe: True, False typ: bool

#Kopf:
def lieblingsZahl(Zahl: int) -> bool:
    if Zahl == 6 or Zahl == 11 or Zahl == 13 or Zahl > 100:
        return True
    else: return False

#checks:
check(lieblingsZahl(6), True)
check(lieblingsZahl(100), False)
check(lieblingsZahl(101), True)
check(lieblingsZahl(12), False)