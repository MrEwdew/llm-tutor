from wypp import *
# begrenzt eine Zahl x auf das Intervall zwischen l und u.
# Eingaben: Zahl x, untere Schranke l, obere Schranke u, jeweils als float.
# Ergebnis: begrenzter Wert, als float.
#x if l <= x <= u
#l if x < l
#u if x > u

#Kopf
def clamp(x: float, l:float, u:float) -> float:
    if l <= x <= u:
        return x
    elif x<l:
        return l
    else:
        return u 
#Checks
check(clamp(1,2,3),2)
check(clamp(2.5,2,3),2.5)
check(clamp(8,4,6),6)