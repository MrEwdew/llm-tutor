from wypp import *

 # DATENBESCHREIBUNG
# Eine Spielerklassifikation ist eins der folgenden:
# - Torhueter
# - Abwehrspielerin
# - Mittelfeldspielerin
# - Stuermerin
# - Ersatzspielerin
# TYPDEFINITION

type  Spielerklassifikation = Literal['Torhueter', 'Abwehrspielerin' , 'Mittelfeldspielerin', 'Stuermer','Ersatzspieler']
def bestimmte_position(Trikotnummer: int ) -> Spielerklassifikation:
    if Trikotnummer == 1:
        return "Torhueter"
    elif Trikotnummer == (2,3,4,5):
        return "Abwehrspielerin"
    elif Trikotnummer == (6,7,8,10):
        return "Mittelfeldspielerin"
    elif Trikotnummer == (9,11):
        return "Stuermer"
    elif 12 <= Trikotnummer  <=99:
        return "Ersatzspieler"



check(bestimmte_position("Torhueter"),1)