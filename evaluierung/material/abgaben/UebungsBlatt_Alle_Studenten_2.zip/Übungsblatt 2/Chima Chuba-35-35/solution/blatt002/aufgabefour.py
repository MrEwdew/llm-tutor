from wypp import *
def clamp(x: int, l: int, u: int) -> int:
    if x < l:
        return l
    elif x > u:
        return u
    else:
        return x


# CHECKS
check(clamp(5, 0, 10), 5)
check(clamp(-3, 0, 10), 0)
check(clamp(15, 0, 10), 10)
check(clamp(0, 0, 10), 0)
check(clamp(10, 0, 10), 10)
check(clamp(7, 5, 8), 7)