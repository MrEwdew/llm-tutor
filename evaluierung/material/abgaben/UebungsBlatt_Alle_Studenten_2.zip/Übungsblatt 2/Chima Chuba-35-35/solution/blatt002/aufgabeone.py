from wypp import *


def lieblingszahl(zahl):
    if zahl == 6:
        return True
    elif zahl == 11:
        return True
    elif zahl == 13:
        return True
    elif zahl > 100:
        return True
    else:
        return False



check(lieblingszahl(6))    # True
check(lieblingszahl(12))   # False
check(lieblingszahl(105))  # True