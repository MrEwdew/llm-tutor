from wypp import *

def berechne_bussgeld(dauer: int) -> int:
    if dauer <= 0:
        return 0
    elif dauer <= 30:
        return 10
    elif dauer <= 60:
        return 15
    elif dauer <= 120:
        return 20
    elif dauer <= 180:
        return 25
    else:
        n = math.ceil(dauer / 60)
        return (n - 1) * 10


# CHECKS
check(berechne_bussgeld(0), 0)
check(berechne_bussgeld(20), 10)
check(berechne_bussgeld(30), 10)
check(berechne_bussgeld(45), 15)
check(berechne_bussgeld(60), 15)
check(berechne_bussgeld(90), 20)
check(berechne_bussgeld(120), 20)
check(berechne_bussgeld(150), 25)
check(berechne_bussgeld(180), 25)
check(berechne_bussgeld(200), 30)
check(berechne_bussgeld(250), 40)