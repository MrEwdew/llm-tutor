from wypp import *
# Datendefinition für Positionen 

#Position ist eins der Folgenden:
#Törhüterin
#Abwehrspielern
#Mittelfeldspielerin
#Stürmerin
#Ersatzspielerin

type positionen = Literal["Torhüterin", "Abwehrspielerin", "Mittelfeldspielerin", "Stürmerin", "Ersatzspielerin"]

#Ermittelt anhand der Rückennummer die Position
#Eingabe: Rückennumer, als int
#Ausgabe: Position, als str

def position(rückennummer: int) -> str:
    if(rückennummer == 1): 
        return "Torhüterin"
    if(1 < rückennummer <= 5):
        return "Abwehrspielerin"
    if(6 <= rückennummer <= 8 or rückennummer == 10):
        return "Mittelfeldspielerin"
    if(rückennummer == 9 or rückennummer == 11):
        return "Stürmerin"
    return "Ersatzspielerin"

check(position(1), "Torhüterin")
check(position(2), "Abwehrspielerin")
check(position(5), "Abwehrspielerin")
check(position(6), "Mittelfeldspielerin")
check(position(8), "Mittelfeldspielerin")
check(position(10), "Mittelfeldspielerin")
check(position(9), "Stürmerin")
check(position(11), "Stürmerin")
check(position(12), "Ersatzspielerin")
check(position(99), "Ersatzspielerin")