from wypp import *
#Prueft ob die Zahl Teil der Lieblingszahlen ist.
#Eingabe: Zahl als int
#Ausgabe: Teil der Lieblingszahlen als boolean

def lieblingszahl(zahl: int) -> bool:
    if zahl == 6 or zahl == 11 or zahl == 13:
        return True
    if zahl > 100:
        return True
    return False

check(lieblingszahl(6), True)
check(lieblingszahl(11), True)
check(lieblingszahl(13), True)
check(lieblingszahl(100),False)
check(lieblingszahl(101), True)