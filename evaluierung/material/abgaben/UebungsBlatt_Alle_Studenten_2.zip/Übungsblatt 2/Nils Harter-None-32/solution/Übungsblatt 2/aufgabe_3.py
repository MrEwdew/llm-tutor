from wypp import *
#Berechnet anhand der Überschreitungsdauer der Parkzeit die Höhe des Bußgeldes. 
#Eingabe: Überschreitungsdauer in Minuten, als int
#Ausgabe: Bußgeld in Euro, als int

def bußgeld(ueberschreitungsdauer: int) -> int:
    if(ueberschreitungsdauer <= 30):
        return 10
    if(ueberschreitungsdauer <= 60):
        return 15
    if(ueberschreitungsdauer <= 120):
        return 20
    if(ueberschreitungsdauer <= 180):
        return 25
    return (math.ceil(ueberschreitungsdauer / 60) - 1) * 10

check(bußgeld(1), 10)
check(bußgeld(30), 10)
check(bußgeld(31),15)
check(bußgeld(60), 15)
check(bußgeld(61), 20)
check(bußgeld(120), 20)
check(bußgeld(121), 25)
check(bußgeld(180), 25)
check(bußgeld(181), 30)
check(bußgeld(240), 30)
check(bußgeld(241), 40)
check(bußgeld(300), 40)
