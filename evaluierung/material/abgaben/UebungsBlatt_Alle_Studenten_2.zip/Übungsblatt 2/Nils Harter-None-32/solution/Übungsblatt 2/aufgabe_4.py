from wypp import *
#Gibt x zurück, sofern l <= x <= u, gibt l zurück sofern x < l, gibt u zurück sofern x > u.
#Eingabe: x, l und u als float
#Ausgabe: x, l oder u als float

def clamp(x: float, l: float, u: float) -> float:
    if(x >= l and x <= u):
        return x
    if(x <= l):
        return l
    return u

check(clamp(2, 1, 3), 2)
check(clamp(1, 2, 3), 2)
check(clamp(3, 1, 2), 2)
check(clamp(1, 1, 1), 1)
check(clamp(2, 3, 1), 3)