from wypp import *

# Funktion, um Spielerposition beim Fußball zu bestimmen
# Törhüter: Rückennummer 1
# Abwehrspieler: Rückennummer 2,3,4,5
# Mittelfeldspieler: Rückennummer 6,7,8,10
# Stürmer: Rückennummer 9,11
# Ersatzspieler: Rückennummer 12-99
# Eingabe: Zahl in int
# Ergebnis: Spielerposition in (Typ: Spieler)
type Spieler = Literal['Torhüter','Abwehrspieler','Mittelfeldspieler','Stürmer','Ersatzspieler']

def spielerposition(zahl:int)-> Spieler:
    if zahl == 1:
        return 'Torhüter'
    elif zahl in [2,3,4,5]:
        return 'Abwehrspieler'
    elif zahl in (6,7,8,10):
        return 'Mittelfeldspieler'
    elif zahl in (9,11):
        return 'Stürmer'
    elif zahl > 11 and zahl < 100: 
        return 'Ersatzspieler'

check(spielerposition(1), 'Torhüter')
check(spielerposition(3), 'Abwehrspieler')
check(spielerposition(10), 'Mittelfeldspieler')
check(spielerposition(11), 'Stürmer')
check(spielerposition(12), 'Ersatzspieler')

