from wypp import *

# Funktion, um eine Zahl auf einen bestimmten Wertebereich zu begrenzen
# Untere Schranke (l): kleinster erlaubter Wert
# Obere Schranke (u): größter erlaubter Wert
# Wenn x kleiner als l ist: Ergebnis ist l in float
# Wenn x größer als u ist: Ergebnis ist u in float
# Wenn x zwischen l und u liegt: Ergebnis ist x in float
# Eingabe: Zahl x, untere Schranke l, obere Schranke u (Typ: float)
# Ergebnis: Begrenzte Zahl (Typ: float)

def clamp(x: float, l: float, u: float) -> float:
    if x >= l and x<= u:
        return x
    elif x < l:
        return l
    elif x > u:
        return u

check(clamp(5, 0, 10), 5)
check(clamp(-3, 0, 10), 0)
check(clamp(15, 0, 10), 10)
check(clamp(0, 0, 10), 0)
check(clamp(10, 0, 10), 10)