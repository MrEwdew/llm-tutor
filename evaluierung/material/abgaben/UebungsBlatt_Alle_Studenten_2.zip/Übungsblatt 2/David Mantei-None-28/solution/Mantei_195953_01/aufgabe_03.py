from wypp import *
import math

# Funktion, um das Bußgeld für zu langes Parken zu bestimmen
# Bis zu 30 Minuten: 10 Euro
# Bis zu 1 Stunde: 15 Euro
# Bis zu 2 Stunden: 20 Euro
# Bis zu 3 Stunden: 25 Euro
# Länger als 3 Stunden: (n - 1) * 10 Euro
# n = Parkdauer in Stunden, aufgerundet
# Eingabe: Überschreitungsdauer in Minuten (Typ: int)
# Ergebnis: Bußgeld in Euro (Typ: int)

def bussgeld(minuten: int) -> int:
    if minuten <= 30:
        return 10
    elif minuten <= 60:
        return 15
    elif minuten <= 120:
        return 20
    elif minuten <= 180:
        return 25
    else:
        n = math.ceil(minuten / 60)
        return (n - 1) * 10

check(bussgeld(20), 10)
check(bussgeld(45), 15)
check(bussgeld(90), 20)
check(bussgeld(150), 25)
check(bussgeld(200), 30)
check(bussgeld(240), 30)
check(bussgeld(241), 40)
