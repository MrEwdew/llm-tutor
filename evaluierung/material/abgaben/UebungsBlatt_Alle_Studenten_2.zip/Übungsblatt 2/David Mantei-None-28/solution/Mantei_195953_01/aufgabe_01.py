from wypp import *

# Liste mit Luises Lieblingszahlen

lieblingszahlen = [6,11,13]

# Funktion, um zu überprüfen, ob Zahl in Lieblingszahlen an.
# Eingabe: zahl in int
# Ergebnis: Ist Zahl Lieblingszahl? in bool

def lieblingszahl(zahl:int)-> bool:
    if zahl in lieblingszahlen or zahl > 100:
        return True
    else:
        return False

check(lieblingszahl(11), True)
check(lieblingszahl(12), False)
check(lieblingszahl(99), False)
check(lieblingszahl(100), False)