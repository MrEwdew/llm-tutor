from wypp import*
import math

# Bußgelder für zu langes Parken automatisch bestimmt werden.
# Abhängigkeit der Überschreitungsdauer der Höchstparkdauer wie folgt festgelegt:
#• Bis zu 30 Minuten: 10 Euro.
#• Bis zu einer Stunde: 15 Euro.
#• Bis zu zwei Stunden: 20 Euro
#• Bis zu drei Stunden: 25 Euro
#• Länger als drei Stunden: (n − 1) · 10 Euro, wobei n die Parkdauer aufgerundet auf die
#nächste ganze Stunde ist.
#Eingabe Zeit (int)
#Ergebnis Bußgeld (int)

def bussgeld(minuten:int)->int:
    if minuten <= 30:
        return 10
    elif minuten<= 60:
        return 15
    elif minuten <= 120:
        return 20
    elif minuten<= 180:
        return 25
    else:
        n = math.ceil(minuten / 60)
        return (n-1)*10

check(bussgeld(35),15)
check(bussgeld(240),30)
check(bussgeld(241),40)