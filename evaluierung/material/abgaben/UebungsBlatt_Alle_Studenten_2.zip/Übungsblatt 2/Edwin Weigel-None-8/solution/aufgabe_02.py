from wypp import*

# Bestimmt die Position einer Fußballspielerin basierend auf ihrer Rückennummer.
#Daten:
#Torhüter hat die Rückennummer 1.
#Abwehrspieler hat die Rückennummer 2, 3, 4 oder 5.
#Mittelfeldspieler hat die Rückennummer 6, 7, 8 oder 10.
#Stürmer hat die Rückennummer 9 oder 11.
#Ersatzspieler hat eine Rückennummer zwischen 12 und 99
#Eingabe: Rückennummer (Zahl) (typ int)
#Ergebnis:Position(typ:str) 
type SpielerPosition = Literal["Torhüterin","Abwehrspieler","Mittelfeldspieler","Stürmer","Ersatzspieler"]
def Position(zahl: int)-> SpielerPosition:
    if zahl==1:
        return "Torhüterin"
    elif zahl== 2 or zahl==3 or zahl==4 or zahl==5:
        return "Abwehrspieler"
    elif zahl== 6 or zahl == 7 or zahl==8 or zahl==10:
        return "Mittelfeldspieler"
    elif zahl ==9 or zahl == 11:
        return "Stürmer"
    elif zahl > 11 and zahl < 100:
        return "Ersatzspieler"

check(Position(1),"Torhüterin")
check(Position(33),"Ersatzspieler")
check(Position(4),"Abwehrspieler")
