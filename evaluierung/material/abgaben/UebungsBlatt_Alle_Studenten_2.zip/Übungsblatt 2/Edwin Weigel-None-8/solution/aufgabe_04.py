from wypp import*
#Funktion clamp aufstellen
#Eingabe:
#-x als float
#-l als float 
#-u als float 
#Ergebnis:Begrenzter Wert als float
def clamp(x:float,lowerbound:float,upperbound: float)->float:
    if lowerbound<= x <= upperbound:
        return x 
    elif x <lowerbound:
        return lowerbound
    else: return upperbound

check(clamp(1,3,4),3)
check(clamp(4,3,5),4)
check(clamp(5,5,5),5)
check(clamp(6,4,5),5)