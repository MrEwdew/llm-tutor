from wypp import*
#Lieblingszahlen von Luise
#- 6,11 ,13 und alle Zahlen größer als 100
#Zahlen die sie nicht mag 
#-12    
#Eingabe: Zahl (Typ int)
#Ergebnis: True oder false

def Lieblingszahl(zahl:int)->bool:
    if zahl in (6,11,13) or zahl > 100:
        return True
    else: 
        return False


check(Lieblingszahl(6),True)
check(Lieblingszahl(1019),True)
check(Lieblingszahl(13),True)
check(Lieblingszahl(11),True)
check(Lieblingszahl(100),False)
check(Lieblingszahl(5),False)



