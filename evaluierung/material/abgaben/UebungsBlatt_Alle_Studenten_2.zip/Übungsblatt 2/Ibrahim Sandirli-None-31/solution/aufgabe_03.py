from wypp import *

# Ein Programm der Berrechnung des Bußgeldes je nach überzogener Höchstparkdauer
# Eingabe: Überschreitungsdauer in minuten(int)
# Ausgabe: Kosten Bußgeld in Euro(int)

# Daten
# - 10€ bis zu 30 minuten
# - 15€ bis zu 60 minuten
# - 20€ bis zu 120 minuten
# - 25€ bis zu 180 minuten
# - (n-1)*10€ bei über 240 minuten, n = Parkdauer aufgerundet

def bußgeld(zeit: int) -> int:
    n = math.ceil(zeit/60)
    if zeit <= 30:
        return 10 
    elif zeit <= 60 and zeit > 30:
        return 15 
    elif zeit <= 120 and zeit > 60:
        return 20 
    elif zeit <= 180 and zeit > 120:
        return 25 
    elif zeit > 180:
        return (n-1)*10
    
check(bußgeld(20), 10)
check(bußgeld(40), 15)
check(bußgeld(80), 20)
check(bußgeld(150), 25)
check(bußgeld(240), 30)
    


