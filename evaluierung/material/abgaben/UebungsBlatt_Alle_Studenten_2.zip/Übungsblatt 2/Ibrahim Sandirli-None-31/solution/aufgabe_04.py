from wypp import *

# Funktion clamp definieren
# Eingabe: x,l,u (float)
# Ausgabe: Begrenzter Zahlenwert (float)

def clamp(x:float,l:float,u:float) -> float:
    if x > u:
        return u
    elif x < l:
        return l
    else:
        return x
    
check(clamp(3,8,5), 8)
check(clamp(6,4,8), 6)
check(clamp(15,4,11), 11)
check(clamp(2.9,-9.4,5.3), 2.9)
check(clamp(347,512,818), 512)