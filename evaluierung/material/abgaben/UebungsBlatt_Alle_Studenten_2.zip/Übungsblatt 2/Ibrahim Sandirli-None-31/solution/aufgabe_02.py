from wypp import *

# Für die angegbenen Rückennummern die richtige Position finden
# Eingabe: 
# Zahlen 1 - 99 (int), 
# Ausgabe:
# Positionen (Torhüterin, Abwehrspielerin, Mittelfeldspielerin, Stürmerin, Ersatzspielerin)

# Daten Typdefinition Positionen

type Position = Literal["Torhüterin", "Abwehrspielerin", "Mittelfeldspielerin", "Stürmerin", "Ersatzspielerin"]

# Eine Fußballspielerin hat:
# - eine Rückennummer
# - Position

# Funktion zur Bestimmung der Position für eine Nummer

def spielerin(number: int) -> Position:
    if number == 1:
        return  "Torhüterin"
    elif number >= 2 and number <=5:
        return  "Abwehrspielerin"
    elif number == 6 or number == 7 or number == 8 or number == 10:
        return  "Mittelfeldspielerin"
    elif number == 9 or number == 11:
        return "Stürmerin"
    elif number >=12 and number <=99:
        return "Ersatzspielerin"
    

check(spielerin(7), "Mittelfeldspielerin")
check(spielerin(1), "Torhüterin")
check(spielerin(4), "Abwehrspielerin")
check(spielerin(9), "Stürmerin")
check(spielerin(55), "Ersatzspielerin")



    