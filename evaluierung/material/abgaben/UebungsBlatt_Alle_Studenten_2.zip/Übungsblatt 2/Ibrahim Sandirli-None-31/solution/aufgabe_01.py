from wypp import *

# Ein Funktion welches wahr oder falsch liefert ob die Zahlen Luises Lieblingszahlen sind(bool)
# Eingabe: 6, 11, 13, >100 (int) [Lieblingszahlen]
# Augabe: True or False (bool)

def lieblingszahlen(zahl: int) -> bool:
    if zahl == 6:
        return True
    elif zahl == 11:
        return True
    elif zahl == 13:
        return True
    elif zahl >100:
        return True
    else:
        return False



check(lieblingszahlen(2), False)
check(lieblingszahlen(6), True)
check(lieblingszahlen(12), False)
check(lieblingszahlen(13), True)
check(lieblingszahlen(150), True)
check(lieblingszahlen(90), False)
