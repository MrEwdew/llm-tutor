from wypp import *

# eine funktion die den boolescehn wahr ausgibt sobald es Luises lieblingszahl
# Lusises Lieblingszahlen: 6, 11, 13, >100
# Eingabe: Beliebige Zahl als int
# Ergebnis: wahr oder falsch als bool

def luisusesLieblingsZahl(zahl: int) -> bool:
    if zahl == 6:
        return True
    elif zahl == 11:
        return True
    elif zahl == 13:
        return True
    elif zahl > 100:
        return True
    else:
        return False

check(luisusesLieblingsZahl(6), True)
check(luisusesLieblingsZahl(11), True)
check(luisusesLieblingsZahl(13), True)
check(luisusesLieblingsZahl(101), True)
check(luisusesLieblingsZahl(100), False)
check(luisusesLieblingsZahl(2), False)
