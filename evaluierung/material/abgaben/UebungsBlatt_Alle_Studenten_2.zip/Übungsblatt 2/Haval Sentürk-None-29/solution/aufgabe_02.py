from wypp import *

# Funktion die die Position eines spielers angibt
# Eingabe: Spielernummer als int
# Ergebnis: Position als Position
# Positionen: Torhüterin, Abwehrspielerin, Mittelfeldspielerin, Stürmerin, Ersatzspielerin

type Position = Literal["Torhüterin", "Abwehrspielerin", "Mittelfeldspielerin", "Stürmerin", "Ersatzspielerin"]

def positionVonNummer(nummer: int) -> Position:
    if nummer == 1:
        return "Torhüterin"
    elif nummer == 2 or nummer == 3 or nummer == 4 or nummer == 5:
        return "Abwehrspielerin"
    elif nummer == 6 or nummer == 7 or nummer == 8 or nummer == 10:
        return "Mittelfeldspielerin"
    elif nummer == 9 or nummer == 11:
        return "Stürmerin"
    elif nummer >= 12 and nummer <= 99:
        return "Ersatzspielerin"


check(positionVonNummer(1), "Torhüterin")
check(positionVonNummer(3), "Abwehrspielerin")
check(positionVonNummer(6), "Mittelfeldspielerin")
check(positionVonNummer(9), "Stürmerin")
check(positionVonNummer(12), "Ersatzspielerin")
check(positionVonNummer(99), "Ersatzspielerin")
