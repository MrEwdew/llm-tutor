from wypp import *
import math

# Funktion zur Brechnung von Bußgeld
# Eingabe: Zeit in Minuten als int
# Ergebnis: Bußgeld betrag in euro als int

def bußgeldRechner(zeit: int) -> int:
    if zeit <= 30:
        return 10
    elif zeit > 30 and zeit <= 60:
        return 15
    elif zeit > 60 and zeit <= 120:
        return 20
    elif zeit > 120 and zeit <= 180:
        return 25
    else: return (math.ceil (zeit / 60) - 1) * 10

check(bußgeldRechner(30), 10)
check(bußgeldRechner(60), 15)
check(bußgeldRechner(120), 20)
check(bußgeldRechner(180), 25)
check(bußgeldRechner(181), 30)
check(bußgeldRechner(240), 30)
