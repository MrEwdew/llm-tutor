from wypp import *

# Die Funktion clamp aufstellen
# Eingabe:
# * x als float
# * l als float
# * u als float
# Ergebnis: Begrenzter Wert als float


def clamp(x: float, lowerbound: float, upperbound: float) -> float:
    if lowerbound <= x <= upperbound:
        return x
    elif x < lowerbound:
        return lowerbound
    else: return upperbound

check(clamp(2, 3, 4), 3)
check(clamp(3.5, 3, 4), 3.5)
check(clamp(5, 3, 4), 4)
