from wypp import *

#beschreibung: Eine gegebene Trikotnummer gibt Rückschlüsse über die Spielerposition
#Input: eine Trikotnummer, natürliche Zahl (int)
#Output: eine Fußballposition (str)

def positionsBestimmung(nummer: int) -> str:
    match nummer:
        case 1:
            return "Torhueter"   
        case 2:
            return "Abwehr" 
        case 3:
            return "Abwehr"
        case 4:
            return "Abwehr" 
        case 5:
            return "Abwehr" 
        case 6:
            return "Mittelfeld" 
        case 7:
            return "Mittelfeld" 
        case 8:
            return "Mittelfeld" 
        case 9:
            return "Stuermer" 
        case 10:
            return "Mittelfeld" 
        case 11: 
            return "Stuermer" 

    if (nummer > 11 and nummer < 100):
        return "Ersatz"



check(positionsBestimmung(1), "Torhueter")
check(positionsBestimmung(80), "Ersatz")