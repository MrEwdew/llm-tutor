from wypp import * 

#Beschreibung: eine funktion clamp gibt den upperbound, lowerbound oder ursprünglichen input wert je nach input wert zurück
#Input: x,l,u sind natürliche Zahlen (int)
#Output: Eine unserer drei Inputs (int)

def clamp(x:int,lower:int, upper:int) -> int:
    if (x < lower):
        return lower
    if (x > upper):
        return upper
    else:
        return x

check(clamp(5,3,6),5)
check(clamp(7,3,6),6)
check(clamp(1,3,6),3)