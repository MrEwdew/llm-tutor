from wypp import *

#Beschreibung: Wir bestimmen das Bussgeld anhand der Parkdauer.
#Input: Eine Parkdauer in Minuten (float)
#Output: Eine Bussgeld in Euro (float)

def bussgeld(ueberschreitungInMin: float) -> float:
    if(ueberschreitungInMin <= 30):
        return 10
    elif(ueberschreitungInMin <= 60):
        return 15
    elif(ueberschreitungInMin <= 120):
        return 20
    elif(ueberschreitungInMin <=180):
        return 25
    else:
        return math.ceil((ueberschreitungInMin/60) -1) * 10

check(bussgeld(55), 15)
check(bussgeld(7*60), (7-1) * 10)