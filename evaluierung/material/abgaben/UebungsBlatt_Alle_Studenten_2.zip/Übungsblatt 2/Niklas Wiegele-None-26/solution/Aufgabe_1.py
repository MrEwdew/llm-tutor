from wypp import *

#Beschreibung: Luise mag die Zahl 6, 11, 13 und alle Zahlen >100
#Input: eine natürlice Zahl (int)
#Output: ein Wahtheitswert der Ausrückt ob die zahl eine von Luises lieblingszahlen ist (boolean)

def lieblingsZahl(zahl: int) -> bool:
    if(zahl == 11 or zahl == 6 or zahl == 12 or zahl >= 100):
        return True
    else:
        return False


check(lieblingsZahl(54), False)
check(lieblingsZahl(112), True)