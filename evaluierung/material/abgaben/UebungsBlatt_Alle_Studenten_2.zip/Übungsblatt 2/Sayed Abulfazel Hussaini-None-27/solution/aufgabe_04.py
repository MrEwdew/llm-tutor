from wypp import *

# Beschreibung: Begrenzt eine Zahl auf einen bestimmten Bereich.
# Eingabe: x, l und u (float)
# Ergebnis: Begrenzter Wert (float)

def clamp(x: float, l: float, u: float) -> float:
    if x >= l and x <= u:
        return x
    elif x < l:
        return l
    elif x > u:
        return u


check(clamp(-2, 0, 10), 0)
check(clamp(5, 0, 10), 5)
check(clamp(12, 0, 10), 10)
check(clamp(0, 0, 10), 0)
check(clamp(10, 0, 10), 10)
check(clamp(2.5, 0, 10), 2.5)
check(clamp(4, 3, 3), 3)