from wypp import *

# Beschreibung: Prüft, ob eine Zahl Luises Lieblingszahl ist.
# Eingabe: zahl (float)
# Ergebnis: True oder False (bool)

def lieblingszahl(zahl: float) -> bool:
    return zahl == 6 or zahl == 11 or zahl == 13 or zahl > 100

check(lieblingszahl(6), True)
check(lieblingszahl(11), True)
check(lieblingszahl(13), True)
check(lieblingszahl(12), False)
check(lieblingszahl(100), False)
check(lieblingszahl(101), True)
check(lieblingszahl(100.5), True)
