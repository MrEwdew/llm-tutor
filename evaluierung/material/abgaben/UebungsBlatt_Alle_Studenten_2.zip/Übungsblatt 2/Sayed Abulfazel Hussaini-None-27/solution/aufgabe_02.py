from wypp import *

# Beschreibung: Bestimmt die Position anhand der Rueckennummer.
# Eingabe: nummer (int)
# Ergebnis: Position der Spielerin (Position)

type Position = Literal[
    'Torhueterin', 'Abwehrspielerin',
    'Mittelfeldspielerin', 'Stuermerin', 'Ersatzspielerin'
]

def position(nummer: int) -> Position:
    if nummer == 1:
        return 'Torhueterin'
    elif nummer >= 2 and nummer <= 5:
        return 'Abwehrspielerin'
    elif nummer == 6 or nummer == 7 or nummer == 8 or nummer == 10:
        return 'Mittelfeldspielerin'
    elif nummer == 9 or nummer == 11:
        return 'Stuermerin'
    else:
        return 'Ersatzspielerin'

check(position(1), 'Torhueterin')
check(position(2), 'Abwehrspielerin')
check(position(5), 'Abwehrspielerin')
check(position(6), 'Mittelfeldspielerin')
check(position(8), 'Mittelfeldspielerin')
check(position(9), 'Stuermerin')
check(position(10), 'Mittelfeldspielerin')
check(position(11), 'Stuermerin')
check(position(12), 'Ersatzspielerin')
check(position(99), 'Ersatzspielerin')