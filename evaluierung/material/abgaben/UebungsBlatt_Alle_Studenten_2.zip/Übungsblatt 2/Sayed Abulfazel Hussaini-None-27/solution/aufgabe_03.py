from wypp import *

# Beschreibung: Berechnet das Bussgeld fuer zu langes Parken.
# Eingabe: minuten (float)
# Ergebnis: Bussgeld in Euro (int)

def bussgeld(minuten: float) -> int:
    if minuten <= 30:
        return 10
    elif minuten <= 60:
        return 15
    elif minuten <= 120:
        return 20
    elif minuten <= 180:
        return 25
    else:
        n = math.ceil(minuten / 60)
        return (n - 1) * 10

check(bussgeld(1), 10)
check(bussgeld(30), 10)
check(bussgeld(31), 15)
check(bussgeld(60), 15)
check(bussgeld(61), 20)
check(bussgeld(120), 20)
check(bussgeld(121), 25)
check(bussgeld(180), 25)
check(bussgeld(181), 30)
check(bussgeld(240), 30)
check(bussgeld(241), 40)