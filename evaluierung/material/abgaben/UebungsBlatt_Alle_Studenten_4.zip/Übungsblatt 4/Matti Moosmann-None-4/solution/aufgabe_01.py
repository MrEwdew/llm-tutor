from wypp import *

# Aufgabe 1a

# Datenbeschreibung:
# Die Antriebsart eines Autos ist entweder Verbrenner oder Elektrisch
type AntriebsartenAuto = Literal['Verbrenner', 'Elektrisch']

# Die Antriebsart eines Fahrrads ist entweder Elektrisch oder Muskelkraft
type AntriebsartenFahrrad = Literal['Elektrisch', 'Muskelkraft']

# Ein Auto besteht aus:
# - Farbe (typ: str)
# - Marke (typ: str)
# - Antriebsart (typ: AntriebsartenAuto)

@record
class Auto:
    farbe: str
    marke: str
    antriebsart: AntriebsartenAuto

# Ein Fahrrad besteht aus:
# - Marke (typ: str)
# - Antriebsart (typ: AntriebsartenFahrrad)

@record
class Fahrrad:
    marke: str
    antriebsart: AntriebsartenFahrrad

# Ein Fahrzeug ist entweder:
# - ein Auto (typ: Auto)
# - ein Fahrrad (typ: Fahrrad)

type Fahrzeug = Union[Auto, Fahrrad]


# Aufgabe 1b

# Hilfsfunktion 1:
# 1. Kurzbeschreibung
# Berechnet die Reichweite eines Autos anhand seiner Antriebsart.
# Verbrenner hat 600km Reichweite, Elektrisch hat 400km Reichweite.

# 2. Datenanalyse
# Eingabe: ein Auto (typ: Auto)
# Ausgabe: Reichweite in km (typ: int)

# 3. Kopf
def autoReichweite(a: Auto) -> int:
    if a.antriebsart == 'Verbrenner':
        return 600
    else:
        return 400

# 4. Checks
test_auto1 = Auto('schwarz', 'BMW', 'Verbrenner')
test_auto2 = Auto('weiß', 'Tesla', 'Elektrisch')

check(autoReichweite(test_auto1), 600)
check(autoReichweite(test_auto2), 400)


# Hilfsfunktion 2:
# 1. Kurzbeschreibung
# Berechnet die Reichweite eines Fahrrads anhand seiner Antriebsart.
# Elektrisch hat 120km Reichweite, Muskelkraft hat 10000km Reichweite.

# 2. Datenanalyse
# Eingabe: ein Fahrrad (typ: Fahrrad)
# Ausgabe: Reichweite in km (typ: int)

# 3. Kopf
def fahrradReichweite(f: Fahrrad) -> int:
    if f.antriebsart == 'Elektrisch':
        return 120
    else:
        return 10000

# 4. Checks
test_rad1 = Fahrrad('Cube', 'Elektrisch')
test_rad2 = Fahrrad('Canyon', 'Muskelkraft')

check(fahrradReichweite(test_rad1), 120)
check(fahrradReichweite(test_rad2), 10000)


# Hauptfunktion:
# 1. Kurzbeschreibung
# Berechnet die Reichweite eines gegebenen Fahrzeugs (Auto oder Fahrrad).

# 2. Datenanalyse
# Eingabe: ein Fahrzeug (typ: Fahrzeug)
# Ausgabe: Reichweite in km (typ: int)

# 3. Kopf
def fahrzeugReichweite(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Auto):
        return autoReichweite(fahrzeug)
    else:
        return fahrradReichweite(fahrzeug)

# 4. Checks
check(fahrzeugReichweite(test_auto1), 600)
check(fahrzeugReichweite(test_auto2), 400)
check(fahrzeugReichweite(test_rad1), 120)
check(fahrzeugReichweite(test_rad2), 10000)
