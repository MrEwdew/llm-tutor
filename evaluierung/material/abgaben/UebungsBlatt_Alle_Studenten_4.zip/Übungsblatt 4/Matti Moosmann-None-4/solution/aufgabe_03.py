from wypp import *

# Aufgabe 3a

# Datenbeschreibung:
# Die Größe einer Pizza ist entweder normal oder groß
type PizzaGroesse = Literal['normal', 'groß']

# Eine Pizza besteht aus:
# - Größe (typ: PizzaGroesse)
# - Oliven vorhanden (typ: bool)
# - Pilze vorhanden (typ: bool)
# - Salami vorhanden (typ: bool)
# - Käse vorhanden (typ: bool)

@record
class Pizza:
    groesse: PizzaGroesse
    oliven: bool
    pilze: bool
    salami: bool
    kaese: bool

# 1. Kurzbeschreibung
# Berechnet den Preis einer Pizza anhand ihrer Größe und der gewählten Zutaten.
# Grundpreis: normal 2,00€, groß 2,50€.
# Zutaten (Normalgröße): Oliven 0,50€, Pilze 0,40€, Salami 0,45€, Käse 0,55€.
# Bei einer großen Pizza werden auf die Zutaten 10% Aufpreis berechnet.

# 2. Datenanalyse
# Eingabe: eine Pizza (typ: Pizza)
# Ausgabe: Preis in Euro (typ: float)

# 3. Kopf
def pizzaPreis(p: Pizza) -> float:
    zutatenPreis = 0.0
    if p.oliven == True:
        zutatenPreis = zutatenPreis + 0.50
    if p.pilze == True:
        zutatenPreis = zutatenPreis + 0.40
    if p.salami == True:
        zutatenPreis = zutatenPreis + 0.45
    if p.kaese == True:
        zutatenPreis = zutatenPreis + 0.55

    if p.groesse == 'normal':
        return 2.00 + zutatenPreis
    else:
        return 2.50 + (zutatenPreis * 1.10)

# 4. Checks
test_pizza_normal_ohne = Pizza('normal', False, False, False, False)
test_pizza_normal_salami_kaese = Pizza('normal', False, False, True, True)
test_pizza_gross_alles = Pizza('groß', True, True, True, True)

check(pizzaPreis(test_pizza_normal_ohne), 2.00)
check(pizzaPreis(test_pizza_normal_salami_kaese), 3.00)
check(pizzaPreis(test_pizza_gross_alles), 4.59)


# Aufgabe 3b

# Datenbeschreibung:
# Eine Biersorte ist entweder Pils oder Weizen
type BierSorte = Literal['Pils', 'Weizen']

# Eine Biergröße ist entweder 0.3l oder 0.5l
type BierGroesse = Literal['0.3l', '0.5l']

# Ein Bier besteht aus:
# - Sorte (typ: BierSorte)
# - Größe (typ: BierGroesse)

@record
class Bier:
    sorte: BierSorte
    groesse: BierGroesse

# Ein Nudelgericht besteht aus:
# - Name (typ: str)
# - Preis pro 100g in Euro (typ: float)
# - Bestellmenge in Gramm (typ: int)

@record
class Nudelgericht:
    name: str
    preisPro100g: float
    bestellmenge: int

# Ein Gericht oder Getränk ist entweder:
# - eine Pizza (typ: Pizza)
# - ein Nudelgericht (typ: Nudelgericht)
# - ein Bier (typ: Bier)

type GerichtOderGetraenk = Union[Pizza, Nudelgericht, Bier]


# Hilfsfunktion 1:
# 1. Kurzbeschreibung
# Berechnet den Preis für ein Bier (100ml Pils = 0,80€, 100ml Weizen = 0,85€).

# 2. Datenanalyse
# Eingabe: ein Bier (typ: Bier)
# Ausgabe: Preis in Euro (typ: float)

# 3. Kopf
def bierPreis(b: Bier) -> float:
    if b.groesse == '0.3l':
        mengeIn100ml = 3
    else:
        mengeIn100ml = 5

    if b.sorte == 'Pils':
        return mengeIn100ml * 0.80
    else:
        return mengeIn100ml * 0.85

# 4. Checks
test_pils_klein = Bier('Pils', '0.3l')
test_weizen_gross = Bier('Weizen', '0.5l')

check(bierPreis(test_pils_klein), 2.40)
check(bierPreis(test_weizen_gross), 4.25)


# Hilfsfunktion 2:
# 1. Kurzbeschreibung
# Berechnet den Preis für ein Nudelgericht anhand des Preises pro 100g und der Bestellmenge in Gramm.

# 2. Datenanalyse
# Eingabe: ein Nudelgericht (typ: Nudelgericht)
# Ausgabe: Preis in Euro (typ: float)

# 3. Kopf
def nudelPreis(n: Nudelgericht) -> float:
    return (n.bestellmenge / 100) * n.preisPro100g

# 4. Checks
test_carbonara = Nudelgericht('Spaghetti Carbonara', 1.50, 400)
test_bolognese = Nudelgericht('Penne Bolognese', 1.20, 350)

check(nudelPreis(test_carbonara), 6.00)
check(nudelPreis(test_bolognese), 4.20)


# Hauptfunktion:
# 1. Kurzbeschreibung
# Berechnet den Preis eines Gerichts (Pizza oder Nudeln) oder eines Getränks (Bier).

# 2. Datenanalyse
# Eingabe: ein Gericht oder Getränk (typ: GerichtOderGetraenk)
# Ausgabe: Preis in Euro (typ: float)

# 3. Kopf
def gesamtPreis(artikel: GerichtOderGetraenk) -> float:
    if isinstance(artikel, Pizza):
        return pizzaPreis(artikel)
    elif isinstance(artikel, Nudelgericht):
        return nudelPreis(artikel)
    else:
        return bierPreis(artikel)

# 4. Checks
check(gesamtPreis(test_pizza_normal_salami_kaese), 3.00)
check(gesamtPreis(test_pizza_gross_alles), 4.59)
check(gesamtPreis(test_carbonara), 6.00)
check(gesamtPreis(test_bolognese), 4.20)
check(gesamtPreis(test_pils_klein), 2.40)
check(gesamtPreis(test_weizen_gross), 4.25)
