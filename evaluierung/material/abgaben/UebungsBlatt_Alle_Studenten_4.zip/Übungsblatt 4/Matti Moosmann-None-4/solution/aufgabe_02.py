from wypp import *

# Aufgabe 2a

# Datenbeschreibung:
# Falls keine Rückennummer gewählt wird, geben wir 'keine' an.
type KeineRueckennummer = Literal['keine']

# Eine optionale Rückennummer ist entweder:
# - eine Rückennummer (typ: int)
# - keine Rückennummer (typ: KeineRueckennummer)

type OptionaleRueckennummer = Union[int, KeineRueckennummer]

# 1. Kurzbeschreibung
# Entscheidet, ob eine optionale Rückennummer vorhanden ist.

# 2. Datenanalyse
# Eingabe: Optionale Rückennummer (typ: OptionaleRueckennummer)
# Ausgabe: Ob eine Rückennummer vorhanden ist (typ: bool)

# 3. Kopf
def istRueckennummerVorhanden(r: OptionaleRueckennummer) -> bool:
    if isinstance(r, int):
        return True
    else:
        return False

# 4. Checks
check(istRueckennummerVorhanden(10), True)
check(istRueckennummerVorhanden('keine'), False)


# Aufgabe 2b

# Datenbeschreibung:
# Eine Größe ist eins der folgenden: S, M oder L
type Groesse = Literal['S', 'M', 'L']

# Eine Farbe ist eins der folgenden: schwarz, grün, blau oder rot
type Farbe = Literal['schwarz', 'grün', 'blau', 'rot']

# Ein Trikot besteht aus:
# - Größe (typ: Groesse)
# - Farbe (typ: Farbe)
# - Optionale Rückennummer (typ: OptionaleRueckennummer)

@record
class Trikot:
    groesse: Groesse
    farbe: Farbe
    rueckennummer: OptionaleRueckennummer

# Eine Hose besteht aus:
# - Größe (typ: Groesse)
# - Farbe (typ: Farbe)

@record
class Hose:
    groesse: Groesse
    farbe: Farbe

# Stutzen bestehen aus:
# - Untere Schranke der Schuhgröße (typ: int)
# - Obere Schranke der Schuhgröße (typ: int)
# - Farbe (typ: Farbe)

@record
class Stutzen:
    untereSchranke: int
    obereSchranke: int
    farbe: Farbe

# Ein Sportartikel ist entweder:
# - ein Trikot (typ: Trikot)
# - eine Hose (typ: Hose)
# - Stutzen (typ: Stutzen)

type Sportartikel = Union[Trikot, Hose, Stutzen]


# Aufgabe 2c

# 1. Kurzbeschreibung
# Berechnet den Preis eines gegebenen Sportartikels (Trikot, Hose oder Stutzen).
# - Trikot: 20€, mit Rückennummer 25€
# - Hose: Größe S 10€, Größe M 12€, Größe L 15€
# - Stutzen: bis Maximalgröße 38 5€, ansonsten 9€

# 2. Datenanalyse
# Eingabe: ein Sportartikel (typ: Sportartikel)
# Ausgabe: Preis in Euro (typ: int)

# 3. Kopf
def sportartikelPreis(artikel: Sportartikel) -> int:
    if isinstance(artikel, Trikot):
        if istRueckennummerVorhanden(artikel.rueckennummer):
            return 25
        else:
            return 20
    elif isinstance(artikel, Hose):
        if artikel.groesse == 'S':
            return 10
        elif artikel.groesse == 'M':
            return 12
        else:
            return 15
    else:
        if artikel.obereSchranke <= 38:
            return 5
        else:
            return 9

# 4. Checks
test_trikot_ohne = Trikot('M', 'rot', 'keine')
test_trikot_mit = Trikot('L', 'blau', 7)
test_hose_s = Hose('S', 'schwarz')
test_hose_m = Hose('M', 'grün')
test_hose_l = Hose('L', 'blau')
test_stutzen_klein = Stutzen(35, 38, 'rot')
test_stutzen_gross = Stutzen(39, 42, 'schwarz')

check(sportartikelPreis(test_trikot_ohne), 20)
check(sportartikelPreis(test_trikot_mit), 25)
check(sportartikelPreis(test_hose_s), 10)
check(sportartikelPreis(test_hose_m), 12)
check(sportartikelPreis(test_hose_l), 15)
check(sportartikelPreis(test_stutzen_klein), 5)
check(sportartikelPreis(test_stutzen_gross), 9)

# Aufgabe 2a

# Datenbeschreibung:
# Falls keine Rückennummer gewählt wird, geben wir 'keine' an.
type KeineRueckennummer = Literal['keine']

# Eine optionale Rückennummer ist entweder:
# - eine Rückennummer (typ: int)
# - keine Rückennummer (typ: KeineRueckennummer)

type OptionaleRueckennummer = Union[int, KeineRueckennummer]

# 1. Kurzbeschreibung
# Entscheidet, ob eine optionale Rückennummer vorhanden ist.

# 2. Datenanalyse
# Eingabe: Optionale Rückennummer (typ: OptionaleRueckennummer)
# Ausgabe: Ob eine Rückennummer vorhanden ist (typ: bool)

# 3. Kopf
def istRueckennummerVorhanden(r: OptionaleRueckennummer) -> bool:
    if isinstance(r, int):
        return True
    else:
        return False

# 4. Checks
check(istRueckennummerVorhanden(10), True)
check(istRueckennummerVorhanden('keine'), False)


# Aufgabe 2b

# Datenbeschreibung:
# Eine Größe ist eins der folgenden: S, M oder L
type Groesse = Literal['S', 'M', 'L']

# Eine Farbe ist eins der folgenden: schwarz, grün, blau oder rot
type Farbe = Literal['schwarz', 'grün', 'blau', 'rot']

# Ein Trikot besteht aus:
# - Größe (typ: Groesse)
# - Farbe (typ: Farbe)
# - Optionale Rückennummer (typ: OptionaleRueckennummer)

@record
class Trikot:
    groesse: Groesse
    farbe: Farbe
    rueckennummer: OptionaleRueckennummer

# Eine Hose besteht aus:
# - Größe (typ: Groesse)
# - Farbe (typ: Farbe)

@record
class Hose:
    groesse: Groesse
    farbe: Farbe

# Stutzen bestehen aus:
# - Untere Schranke der Schuhgröße (typ: int)
# - Obere Schranke der Schuhgröße (typ: int)
# - Farbe (typ: Farbe)

@record
class Stutzen:
    untereSchranke: int
    obereSchranke: int
    farbe: Farbe

# Ein Sportartikel ist entweder:
# - ein Trikot (typ: Trikot)
# - eine Hose (typ: Hose)
# - Stutzen (typ: Stutzen)

type Sportartikel = Union[Trikot, Hose, Stutzen]


# Aufgabe 2c

# 1. Kurzbeschreibung
# Berechnet den Preis eines gegebenen Sportartikels (Trikot, Hose oder Stutzen).
# - Trikot: 20€, mit Rückennummer 25€
# - Hose: Größe S 10€, Größe M 12€, Größe L 15€
# - Stutzen: bis Maximalgröße 38 5€, ansonsten 9€

# 2. Datenanalyse
# Eingabe: ein Sportartikel (typ: Sportartikel)
# Ausgabe: Preis in Euro (typ: int)

# 3. Kopf
def sportartikelPreis(artikel: Sportartikel) -> int:
    if isinstance(artikel, Trikot):
        if istRueckennummerVorhanden(artikel.rueckennummer):
            return 25
        else:
            return 20
    elif isinstance(artikel, Hose):
        if artikel.groesse == 'S':
            return 10
        elif artikel.groesse == 'M':
            return 12
        else:
            return 15
    else:
        if artikel.obereSchranke <= 38:
            return 5
        else:
            return 9

# 4. Checks
test_trikot_ohne = Trikot('M', 'rot', 'keine')
test_trikot_mit = Trikot('L', 'blau', 7)
test_hose_s = Hose('S', 'schwarz')
test_hose_m = Hose('M', 'grün')
test_hose_l = Hose('L', 'blau')
test_stutzen_klein = Stutzen(35, 38, 'rot')
test_stutzen_gross = Stutzen(39, 42, 'schwarz')

check(sportartikelPreis(test_trikot_ohne), 20)
check(sportartikelPreis(test_trikot_mit), 25)
check(sportartikelPreis(test_hose_s), 10)
check(sportartikelPreis(test_hose_m), 12)
check(sportartikelPreis(test_hose_l), 15)
check(sportartikelPreis(test_stutzen_klein), 5)
check(sportartikelPreis(test_stutzen_gross), 9)
