from wypp import *



# Funktion um Rueckennumer zu bestimmen entweder leer oder eine Zahl
def rueckennumerVorhanden(nummer: int | None) -> bool:
    return nummer is not None


check(rueckennumerVorhanden(None), False)
check(rueckennumerVorhanden(5), True)

# Bestellformular
# Trikot Größe (S, M und L)
# Trikot Farbe (schwarz, grün, blau und rot)
# Trikot Rückennummer (optional)

type Groesse = Literal["S", "M", "L"]
type Farbe = Literal["schwarz", "gruen", "blau", "rot"]


@record
class Trikot:
    groesse: Groesse 
    farbe: Farbe
    rueckennumer: rueckennumerVorhanden


# Hose Größe (S, M und L)
# Hose Farbe (schwarz, grün, blau und rot)

@record
class Hose:
    groesse: Groesse
    farbe: Farbe


# Stutzen Größe (Schuhgröße)
# Stutzen Farbe (schwarz, grün, blau und rot)

@record
class Stutzen:
    schuhgroesse: int
    farbe: Farbe


type Sportartikel = Union[Trikot, Hose, Stutzen]

# Eine Funktion für den Preis eines Trikots mit oder ohne Rückennummer

def sportartikelPreis(artikel: Sportartikel) -> int:
    if isinstance(artikel, Trikot):
        if artikel.rueckennumer is None:
            return 20
        else: 
            return 25
    elif isinstance(artikel, Hose):
        if artikel.groesse == "S":
            return 10
        elif artikel.groesse == "M":
            return 12
        else:
            return 15
    else: #Stutzen
        if artikel.schuhgroesse <= 38:
            return 5
        else:
            return 9


check(sportartikelPreis(Trikot("M", "schwarz", None)), 20)
check(sportartikelPreis(Trikot("S", "blau", 5)), 25)

check(sportartikelPreis(Hose("S", "schwarz")), 10)
check(sportartikelPreis(Hose("M", "gruen")), 12)
check(sportartikelPreis(Hose("L", "rot")), 15)

check(sportartikelPreis(Stutzen(38, "schwarz")), 5)
check(sportartikelPreis(Stutzen(39, "blau")), 9)