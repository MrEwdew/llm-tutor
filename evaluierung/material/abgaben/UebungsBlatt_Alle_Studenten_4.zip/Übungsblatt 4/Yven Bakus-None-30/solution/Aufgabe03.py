from wypp import *


# Datenbeschreibung und Typdefinition

type PizzaGroesse = Literal["normal", "gross"]

# Eine Pizza hat eine Größe und kann jede Zutat höchstens einmal enthalten.
@record
class Pizza:
    groesse: PizzaGroesse
    oliven: bool
    pilze: bool
    salami: bool
    kaese: bool


# Eingabe: Pizza
# Ausgabe: Preis in Euro

def preisEinerPizza(pizza: Pizza) -> float:
    if pizza.groesse == "normal":
        preis = 2.0
    else:
        preis = 2.5

    if pizza.oliven:
        if pizza.groesse == "normal":
            preis += 0.50
        else:
            preis += 0.55

    if pizza.pilze:
        if pizza.groesse == "normal":
            preis += 0.40
        else:
            preis += 0.44

    if pizza.salami:
        if pizza.groesse == "normal":
            preis += 0.45
        else:
            preis += 0.495

    if pizza.kaese:
        if pizza.groesse == "normal":
            preis += 0.55
        else:
            preis += 0.605

    return preis



check(preisEinerPizza(Pizza("normal", False, False, False, False)), 2.0)
check(preisEinerPizza(Pizza("normal", True, False, True, False)), 2.95)
check(preisEinerPizza(Pizza("gross", False, False, False, False)), 2.5)
check(preisEinerPizza(Pizza("gross", True, False, True, False)), 3.545)

# 3.2)
# Ein Bier ist entwedr ein Pils oder ein Weizen in den größen 0.5L oder 0.3L

type Getraenk = Literal["pils", "weizen"]

type GetraenkGroesse = Union[0.3, 0.5]

@record
class Getraenk:
    sorte: Getraenk
    groesse: GetraenkGroesse

@record
class Nudelgericht:
    name: str
    preisPro100Gramm: float
    bestellMengeInGramm: int

type Gericht = Union[Nudelgericht, Pizza]
type Bestellung = Union[Nudelgericht, Pizza, Getraenk]

# Preis eines Gerichts oder eines Getränks

def preisBestellung(bestellung: Bestellung) -> float:
    if isinstance(bestellung, Pizza):
        return preisEinerPizza(bestellung)

    if isinstance(bestellung, Nudelgericht):
        return bestellung.preisPro100Gramm * bestellung.bestellMengeInGramm / 100

    if bestellung.sorte == "pils":
        preisPro100Ml = 0.80
    else:
        preisPro100Ml = 0.85

    return preisPro100Ml * bestellung.groesse * 10


check(preisBestellung(Pizza("normal", False, False, False, False)), 2.0)
check(preisBestellung(Pizza("normal", True, False, True, False)), 2.95)
check(preisBestellung(Pizza("gross", False, False, False, False)), 2.5)
check(preisBestellung(Nudelgericht("Pasta", 1.20, 150)), 1.80)
check(preisBestellung(Getraenk("pils", 0.3)), 2.40)
check(preisBestellung(Getraenk("weizen", 0.3)), 2.55)
check(preisBestellung(Getraenk("pils", 0.5)), 4.00)
check(preisBestellung(Getraenk("weizen", 0.5)), 4.25)