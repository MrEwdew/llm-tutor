from wypp import *


# (a) Datenbeschreibung und Typdefinition

# Die Antriebsart eines Autos ist elektrisch oder Verbrenner.
type AntriebsartAuto = Literal["elektrisch", "verbrenner"]

# Die Antriebsart eines Fahrrads ist elektrisch oder Muskelkraft.
type AntriebsartFahrrad = Literal["elektrisch", "muskelkraft"]


# Ein Auto hat eine Farbe, eine Marke und eine Antriebsart.
@record
class Auto:
    farbe: str
    marke: str
    antriebsart: AntriebsartAuto


# Ein Fahrrad hat eine Marke und eine Antriebsart.
@record
class Fahrrad:
    marke: str
    antriebsart: AntriebsartFahrrad


# Ein Fahrzeug ist entweder ein Auto oder ein Fahrrad.
type Fahrzeug = Union[Auto, Fahrrad]


# Eingabe: Auto
# Ausgabe: Reichweite in Kilometern

def reichweiteAuto(auto: Auto) -> int:
    if auto.antriebsart == "elektrisch":
        return 400
    else:
        return 600


# Hilfsfunktion für Fahrräder
# Eingabe: Fahrrad
# Ausgabe: Reichweite in Kilometern

def reichweiteFahrrad(fahrrad: Fahrrad) -> int:
    if fahrrad.antriebsart == "elektrisch":
        return 120
    else:
        return 10000


# Funktion für beliebige Fahrzeuge
# Eingabe: Fahrzeug, also Auto oder Fahrrad
# Ausgabe: Reichweite in Kilometern

def reichweiteFahrzeug(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Auto):
        return reichweiteAuto(fahrzeug)
    else:
        return reichweiteFahrrad(fahrzeug)


# Tests für die Auto-Hilfsfunktion
check(reichweiteAuto(Auto("blau", "VW", "elektrisch")), 400)
check(reichweiteAuto(Auto("rot", "Ferrari", "verbrenner")), 600)


check(reichweiteFahrrad(Fahrrad("Cube", "elektrisch")), 120)
check(reichweiteFahrrad(Fahrrad("Cube", "muskelkraft")), 10000)



check(reichweiteFahrzeug(Auto("blau", "VW", "elektrisch")), 400)
check(reichweiteFahrzeug(Auto("rot", "Ferrari", "verbrenner")), 600)
check(reichweiteFahrzeug(Fahrrad("Cube", "elektrisch")), 120)
check(reichweiteFahrzeug(Fahrrad("Cube", "muskelkraft")), 10000)