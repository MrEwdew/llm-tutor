from wypp import *

# Datenbeschreibung:
# Eine Größe ist entweder S,M,L (str)
type Groesse = Literal["S", "M", "L"]

# Eine Farbe ist entweder schwarz, grün, blau oder rot (str)
type Farbe = Literal["schwarz", "grün", "blau", "rot"]

# eine rückennummer kann vorhanden oder leer sein, ist wenn vorhanden ein String
type Rueckennummer = Optional[str]

# Ein Trikot besteht aus:
# - Größe (type Groesse)
# - Farbe (type Farbe)
# - Rückennummer (type Rueckennummer)


@record
class Trikot:
    groesse: Groesse
    farbe: Farbe
    rueckennummer: Rueckennummer = None


# Eine Hose besteht aus:
# - Größe (type Groesse)
# - Farbe (type Farbe)


@record
class Hose:
    groesse: Groesse
    farbe: Farbe


# Ein Stutzen besteht aus:
# - Unterschranke (int)
# - Oberschranke (int)
# - Farbe (type Farbe)


@record
class Stutzen:
    unterschranke: int
    oberschranke: int
    farbe: Farbe


# Ein Sportartikel ist entweder ein Trikot, Hose, Stutzen (die jeweilige Klasse)
type Sportartikel = Union[Hose, Stutzen, Trikot]

# Funktionsbesch.: Checkt ob eine Rückennummer vorhanden ist
# Input: Ein Trikot (Klasse Trikot)
# Output: Wahrheitswert (bool)


def istRueckennummerVorhanden(trikot: Trikot) -> bool:
    if isinstance(trikot.rueckennummer, str):
        return True
    else:
        return False


check(istRueckennummerVorhanden(Trikot("L", "rot", "8")), True)
check(istRueckennummerVorhanden(Trikot("L", "rot")), False)

# Funktionsbesch.: Berechnet den Preis eines Artikels anhand der Begebenheiten der Aufgabe
# Input: Ein Sportartikel (type Sportartikel)
# Output: preis des Artikels in € (float)


def berechnePreis(artikel: Sportartikel) -> float:

    if isinstance(artikel, Trikot):
        if istRueckennummerVorhanden(artikel):
            return 25
        else:
            return 20
    elif isinstance(artikel, Hose):
        if artikel.groesse == "S":
            return 10
        if artikel.groesse == "M":
            return 12
        if artikel.groesse == "L":
            return 15
    elif isinstance(artikel, Stutzen):
        if artikel.oberschranke <= 38:
            return 5
        else:
            return 9
    else:
        return 1000


check(berechnePreis(Trikot("L", "rot", "8")), 25)
check(berechnePreis(Trikot("L", "rot")), 20)
check(berechnePreis(Hose("S", "rot")), 10)
check(berechnePreis(Hose("M", "rot")), 12)
check(berechnePreis(Hose("L", "rot")), 15)
check(berechnePreis(Stutzen(34, 38, "rot")), 5)
check(berechnePreis(Stutzen(36, 40, "rot")), 9)
