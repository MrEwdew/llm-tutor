from wypp import *

# Datenbeschreibung:

# Eine Antriebsart besteht aus:
# - Antrieb (Literal: Verbrenner; Elektrisch; Muskelkraft)

type Antriebsart = Literal["Verbrenner", "Elektrisch", "Muskelkraft"]

# Ein Auto besteht aus:
# - Farbe (str)
# - Marke (str)
# - Antriebsart (type Antriebsart)


@record
class Auto:
    farbe: str
    marke: str
    antriebsart: Antriebsart


# Ein Fahrrad besteht aus:
# - Marke (str)
# - Antriebsart  (type Antriebsart)


@record
class Fahrrad:
    marke: str
    antriebsart: Antriebsart


# Ein Fahrzeug ist:
# Ein Auto oder ein Fahrrad (Literal: Auto, Fahrrad)

type Fahrzeug = Union[Auto, Fahrrad]

# Funktionsbeschreibung: Schaut ob das gegebene Ding ein Fahrrad oder Auto ist
# Input: ein Fahrzeug (Fahrzeug)
# Output: ein Wahrheitswert, true wenn Auto (bool)


def istDasDingEinAuto(fahrzeug: Fahrzeug) -> bool:
    if isinstance(fahrzeug, Auto):
        return True
    else:
        return False


check(istDasDingEinAuto(Auto("Rot", "Ferrari", "Verbrenner")), True)
check(istDasDingEinAuto(Fahrrad("Peugeot", "Elektrisch")), False)


# Funktionsbeschreibung: Berechnung der Reichweite eines gegebenen
# Input: ein Fahrzeug (type Fahrzeug)
# Output: Eine Reichweite (float)
def berechneReichweite(fahrzeug: Fahrzeug) -> float:
    if istDasDingEinAuto(fahrzeug):
        if fahrzeug.antriebsart == "Elektrisch":
            return 400
        elif fahrzeug.antriebsart == "Verbrenner":
            return 600
        else:
            return 0
    else:
        if fahrzeug.antriebsart == "Elektrisch":
            return 120
        elif fahrzeug.antriebsart == "Muskelkraft":
            return 10000
        else:
            return 0


check(berechneReichweite(Auto("Rot", "Ferrari", "Verbrenner")), 600)
check(berechneReichweite(Fahrrad("Peugeot", "Elektrisch")), 120)
check(berechneReichweite(Auto("Rot", "VW", "Muskelkraft")), 0)
