from wypp import *

# Datenbeschreibung:
# Eine BierGroesse kann entweder 300 oder 500 ml sein

type BierGroesse = Literal[300, 500]

# Eine PizzaGroesse kann entweder groß oder klein sein
type PizzaGroesse = Literal["Groß", "Klein"]


# Eine Biersorte ist entweder ein Pils odre ein Weizen

type BierSorte = Literal["Pils", "Weizen"]

# Eine Pizza besteht aus:
# - Name (str)
# - Groesse (type Groesse)
# - Oliven (bool)
# - Pilze (bool)
# - Salami (bool)
# - Käse (bool)


@record
class Pizza:
    name: str
    groesse: PizzaGroesse
    oliven: bool = False
    pilze: bool = False
    salami: bool = False
    kaese: bool = False


# Ein Bier besteht aus:
# - Einer Sorte (Biersorte)
# - Einer Groesse (BierGroesse)


@record
class Bier:
    sorte: BierSorte
    groesse: BierGroesse


# Ein Nudelgericht besteht aus:
# - Name (str)
# - Einen Preis pro 100G (float)
# - Bestellmenge in Gramm (int)


@record
class Nudelgericht:
    name: str
    preisPro100Gramm: float
    bestellmengeInGramm: int


# Ein Artikel ist entwder Bier, Pizza, oder ein Nudelgericht

type Artikel = Union[Pizza, Nudelgericht, Bier]

# Funktionsbesch: Eine Funktion die den Pizzapreis berechnet
# btw: wo gibts so günstige Pizzas, schick mal Link
# Input: Eine Pizza (Klasse Pizza)
# Output: Ein Preis in € (float)


def bereichnePizzaPreis(pizza: Pizza) -> float:
    tempPreis = 0
    if pizza.groesse == "Klein":
        tempPreis += 2
        if pizza.oliven == True:
            tempPreis += 0.5
        if pizza.pilze == True:
            tempPreis += 0.4
        if pizza.salami == True:
            tempPreis += 0.45
        if pizza.kaese == True:
            tempPreis += 0.55

    elif pizza.groesse == "Groß":
        tempPreis += 2.5
        if pizza.oliven == True:
            tempPreis += 0.5 * 1.1
        if pizza.pilze == True:
            tempPreis += 0.4 * 1.1
        if pizza.salami == True:
            tempPreis += 0.45 * 1.1
        if pizza.kaese == True:
            tempPreis += 0.55 * 1.1

    return tempPreis


check(bereichnePizzaPreis(Pizza("Margarita", "Klein")), 2)
check(bereichnePizzaPreis(Pizza("Fungi", "Groß", pilze=True)), 2.94)


# Funktionsbesch: Eine Funktion die den Bierpreis berechnet
# Input: Ein Bier (Klasse Bier)
# Output: Ein Preis in € (float)
def berechneBierPreis(bier: Bier) -> float:
    if bier.sorte == "Pils":
        preisPro100ml = 0.80
    else:
        preisPro100ml = 0.85
    return bier.groesse * preisPro100ml / 100


check(berechneBierPreis(Bier("Pils", 300)), 2.40)
check(berechneBierPreis(Bier("Pils", 500)), 4.00)
check(berechneBierPreis(Bier("Weizen", 300)), 2.55)
check(berechneBierPreis(Bier("Weizen", 500)), 4.25)

# Funktionsbesch: Eine Funktion die den Bierpreis berechnet
# Input: Ein Bier (Klasse Bier)
# Output: Ein Preis in € (float)


def berechneNudelPreis(nudelgericht: Nudelgericht) -> float:
    return nudelgericht.bestellmengeInGramm * nudelgericht.preisPro100Gramm / 100


check(berechneNudelPreis(Nudelgericht("Carbonara", 1.50, 350)), 5.25)
check(berechneNudelPreis(Nudelgericht("Pesto", 2.00, 100)), 2.00)
check(berechneNudelPreis(Nudelgericht("Bolognese", 1.80, 50)), 0.90)


# Funktionsbesch: Eine Funktion die Alle Preise mithilfe der Hilfsfunktionen berechnet
# Input: Ein Gericht (Klasse Gericht)
# Output: Ein Preis in € (float)


def berechneAllePreise(artikel: Artikel) -> float:
    if isinstance(artikel, Pizza):
        return bereichnePizzaPreis(artikel)
    elif isinstance(artikel, Bier):
        return berechneBierPreis(artikel)
    else:
        return berechneNudelPreis(artikel)


check(berechneAllePreise(Pizza("Margarita", "Klein")), 2.00)
check(berechneAllePreise(Pizza("Fungi", "Groß", pilze=True)), 2.94)
check(
    berechneAllePreise(
        Pizza("Alles", "Klein", oliven=True, pilze=True, salami=True, kaese=True)
    ),
    3.90,
)
check(
    berechneAllePreise(
        Pizza("Alles", "Groß", oliven=True, pilze=True, salami=True, kaese=True)
    ),
    4.59,
)

check(berechneAllePreise(Bier("Pils", 300)), 2.40)
check(berechneAllePreise(Bier("Pils", 500)), 4.00)
check(berechneAllePreise(Bier("Weizen", 300)), 2.55)
check(berechneAllePreise(Bier("Weizen", 500)), 4.25)

check(berechneAllePreise(Nudelgericht("Carbonara", 1.50, 350)), 5.25)
check(berechneAllePreise(Nudelgericht("Pesto", 2.00, 100)), 2.00)
