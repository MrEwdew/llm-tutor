from wypp import *


# Eine Größe ist S, M oder L.
type Groesse = Literal['S', 'M', 'L']

# Eine Farbe ist schwarz, grün, blau oder rot.
type Farbe = Literal['schwarz', 'grün', 'blau', 'rot']

# Eine optionale Rückennummer ist eine Zahl oder 'keine'.
type OptionaleNummer = Union[int, Literal['keine']]


# Prüfen, ob eine Rückennummer vorhanden ist
# Eingabe: eine optionale Rückennummer
# Ergebnis: ob eine Nummer vorhanden ist (bool)
def hatRueckennummer(nummer: OptionaleNummer) -> bool:
    if isinstance(nummer, int):
        return True
    else:
        return False


check(hatRueckennummer(10), True)
check(hatRueckennummer('keine'), False)


# Ein Trikot hat Größe, Farbe und eine optionale Rückennummer.
@record
class Trikot:
    groesse: Groesse
    farbe: Farbe
    rueckennummer: OptionaleNummer


# Eine Hose hat Größe und Farbe.
@record
class Hose:
    groesse: Groesse
    farbe: Farbe


# Stutzen haben untere und obere Schuhgröße und eine Farbe.
@record
class Stutzen:
    untereGroesse: int
    obereGroesse: int
    farbe: Farbe


# Ein Sportartikel ist ein Trikot, eine Hose oder Stutzen.
type Sportartikel = Union[Trikot, Hose, Stutzen]


# Preis eines Sportartikels berechnen
# Eingabe: ein Sportartikel
# Ergebnis: Preis in Euro (int)
def preisSportartikel(artikel: Sportartikel) -> int:
    if isinstance(artikel, Trikot):
        if hatRueckennummer(artikel.rueckennummer):
            return 25
        else:
            return 20
    elif isinstance(artikel, Hose):
        if artikel.groesse == 'S':
            return 10
        elif artikel.groesse == 'M':
            return 12
        else:
            return 15
    else:
        if artikel.obereGroesse <= 38:
            return 5
        else:
            return 9


check(preisSportartikel(Trikot('M', 'blau', 'keine')), 20)
check(preisSportartikel(Trikot('L', 'rot', 10)), 25)
check(preisSportartikel(Hose('S', 'schwarz')), 10)
check(preisSportartikel(Hose('M', 'grün')), 12)
check(preisSportartikel(Hose('L', 'blau')), 15)
check(preisSportartikel(Stutzen(35, 38, 'rot')), 5)
check(preisSportartikel(Stutzen(39, 44, 'schwarz')), 9)
