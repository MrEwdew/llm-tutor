from wypp import *


# Eine Pizzagröße ist normal oder groß.
type Pizzagroesse = Literal['normal', 'groß']

# Eine Pizza hat eine Größe und kann vier Zutaten haben.
# Jede Zutat wird mit True oder False angegeben.
@record
class Pizza:
    groesse: Pizzagroesse
    oliven: bool
    pilze: bool
    salami: bool
    kaese: bool


# Preis einer Pizza berechnen
# Eingabe: eine Pizza
# Ergebnis: Preis in Euro (float)
def preisPizza(pizza: Pizza) -> float:
    zutaten = 0.0
    if pizza.oliven:
        zutaten = zutaten + 0.50
    if pizza.pilze:
        zutaten = zutaten + 0.40
    if pizza.salami:
        zutaten = zutaten + 0.45
    if pizza.kaese:
        zutaten = zutaten + 0.55

    if pizza.groesse == 'groß':
        return 2.50 + zutaten * 1.10
    else:
        return 2.00 + zutaten


check(preisPizza(Pizza('normal', False, False, False, False)), 2.00)
check(preisPizza(Pizza('normal', True, False, False, False)), 2.50)
check(preisPizza(Pizza('groß', True, False, False, False)), 3.05)


# Biersorten sind Pils oder Weizen.
type Biersorte = Literal['Pils', 'Weizen']

# Biermengen sind 300 oder 500 Milliliter.
type Biermenge = Literal[300, 500]

# Bier hat eine Sorte und eine Menge in Millilitern.
@record
class Bier:
    sorte: Biersorte
    menge: Biermenge


# Nudeln haben einen Namen, einen Preis je 100 g und eine Menge in g.
@record
class Nudeln:
    name: str
    preisPro100g: float
    menge: int


# Ein Artikel ist Pizza, Bier oder Nudeln.
type Artikel = Union[Pizza, Bier, Nudeln]


# Preis eines Biers berechnen
# Eingabe: ein Bier
# Ergebnis: Preis in Euro (float)
def preisBier(bier: Bier) -> float:
    if bier.sorte == 'Pils':
        return bier.menge * 0.80 / 100
    else:
        return bier.menge * 0.85 / 100


check(preisBier(Bier('Pils', 300)), 2.40)
check(preisBier(Bier('Weizen', 500)), 4.25)


# Preis eines Nudelgerichts berechnen
# Eingabe: ein Nudelgericht
# Ergebnis: Preis in Euro (float)
def preisNudeln(nudeln: Nudeln) -> float:
    return nudeln.menge / 100 * nudeln.preisPro100g


check(preisNudeln(Nudeln('Spaghetti', 1.50, 200)), 3.00)


# Preis eines Artikels berechnen
# Eingabe: Pizza, Bier oder Nudeln
# Ergebnis: Preis in Euro (float)
def preisArtikel(artikel: Artikel) -> float:
    if isinstance(artikel, Pizza):
        return preisPizza(artikel)
    elif isinstance(artikel, Bier):
        return preisBier(artikel)
    else:
        return preisNudeln(artikel)


check(preisArtikel(Pizza('normal', False, False, False, False)), 2.00)
check(preisArtikel(Bier('Pils', 300)), 2.40)
check(preisArtikel(Nudeln('Spaghetti', 1.50, 200)), 3.00)
