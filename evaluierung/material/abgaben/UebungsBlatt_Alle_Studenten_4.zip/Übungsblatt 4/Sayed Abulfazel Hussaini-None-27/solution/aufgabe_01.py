from wypp import *


# Die Antriebsart eines Autos ist Verbrenner oder elektrisch.
type AutoAntrieb = Literal['Verbrenner', 'elektrisch']

# Die Antriebsart eines Fahrrads ist Muskelkraft oder elektrisch.
type FahrradAntrieb = Literal['Muskelkraft', 'elektrisch']

# Ein Auto besteht aus:
# - Farbe (str)
# - Marke (str)
# - Antriebsart (AutoAntrieb)
@record
class Auto:
    farbe: str
    marke: str
    antrieb: AutoAntrieb


# Ein Fahrrad besteht aus:
# - Marke (str)
# - Antriebsart (FahrradAntrieb)
@record
class Fahrrad:
    marke: str
    antrieb: FahrradAntrieb


# Ein Fahrzeug ist ein Auto oder ein Fahrrad.
type Fahrzeug = Union[Auto, Fahrrad]


# Reichweite eines Autos berechnen
# Eingabe: ein Auto
# Ergebnis: Reichweite in km (int)
def reichweiteAuto(auto: Auto) -> int:
    if auto.antrieb == 'Verbrenner':
        return 600
    else:
        return 400


check(reichweiteAuto(Auto('rot', 'VW', 'Verbrenner')), 600)
check(reichweiteAuto(Auto('blau', 'VW', 'elektrisch')), 400)


# Reichweite eines Fahrrads berechnen
# Eingabe: ein Fahrrad
# Ergebnis: Reichweite in km (int)
def reichweiteFahrrad(fahrrad: Fahrrad) -> int:
    if fahrrad.antrieb == 'elektrisch':
        return 120
    else:
        return 10000


check(reichweiteFahrrad(Fahrrad('Cube', 'elektrisch')), 120)
check(reichweiteFahrrad(Fahrrad('Cube', 'Muskelkraft')), 10000)


# Reichweite eines Fahrzeugs berechnen
# Eingabe: ein Fahrzeug
# Ergebnis: Reichweite in km (int)
def reichweite(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Auto):
        return reichweiteAuto(fahrzeug)
    else:
        return reichweiteFahrrad(fahrzeug)


check(reichweite(Auto('rot', 'VW', 'Verbrenner')), 600)
check(reichweite(Fahrrad('Cube', 'Muskelkraft')), 10000)
