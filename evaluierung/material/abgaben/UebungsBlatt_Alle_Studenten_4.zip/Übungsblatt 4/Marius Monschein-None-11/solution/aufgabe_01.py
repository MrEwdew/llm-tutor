from wypp import * 

type Autoantriebsart = Literal['Verbrenner', 'elektrisch']

type Fahrradantriebsart = Literal['Muskelkraft', 'elektrisch']

@record
class Auto:
    farbe: str
    marke: str
    antriebsart: Autoantriebsart

@record 
class Fahrrad:
    marke: str
    antriebsart: Fahrradantriebsart

type Fahrzeug = Union[Auto, Fahrrad]


# Hilfsfunktion, die Reichweite von Auto berechnet
def reichweite_auto(fahrzeug: Auto) -> int:
    if fahrzeug.antriebsart == 'Verbrenner':
        return 600
    elif fahrzeug.antriebsart == 'elektrisch':
        return 400

# Hilfsfunktion, die Reichweite von Fahrrad berechnet
def reichweite_fahrrad(fahrzeug: Fahrrad) -> int:
    if fahrzeug.antriebsart == 'Muskelkraft':
        return 10000
    elif fahrzeug.antriebsart == 'elektrisch':
        return 400

# Funktion, welche die Reichweite eines Fahrzeugs berechnet
# Eingabe: Fahrzeug (typ: Fahrzeug)
# Ausgabe: Reichweite in km (typ: int)
def reichweite(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Auto):
        return reichweite_auto(fahrzeug)
    elif isinstance(fahrzeug, Fahrrad):
        return reichweite_fahrrad(fahrzeug)

auto_verbrenner = Auto('grün', 'Audi', 'Verbrenner')
auto_elektrisch = Auto('grün', 'Audi', 'elektrisch')
fahrrad_muskelkraft = Fahrrad('Stratera', 'Muskelkraft')
fahrrad_elektrisch = Fahrrad('Stratera', 'elektrisch')

check(reichweite(auto_verbrenner), 600)
check(reichweite(auto_elektrisch), 400)
check(reichweite(fahrrad_muskelkraft), 10000)
check(reichweite(fahrrad_elektrisch), 400)





