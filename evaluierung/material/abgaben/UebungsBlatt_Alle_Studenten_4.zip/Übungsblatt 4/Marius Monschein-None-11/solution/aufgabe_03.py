from wypp import * 

type Größe = Literal['normal', 'groß']

type Zutaten = Literal['Oliven', 'Pilze', 'Salami', 'Käse']

@record
class Zutat:
    name: Zutaten
    preis: float

@record 
class Pizza:
    größe: Größe 
    zutaten: list[Zutat]

@record 
class Nudelgericht:
    namen: str
    preis: float
    bestellmenge: int

type Sorten = Literal['Pils', 'Weizen']

@record 
class Getränk:
    sorte: Sorten
    größe: float

type Gericht = Union[Pizza, Nudelgericht]


# Funktion, die den Preis einer Pizza berechnet 
# Eingabe: pizza (typ: Pizza)
# Ausgabe: Preis in Euro (typ: float)
def pizza_preis(pizza: Pizza) -> float:

    zutaten_benutzt = []
    preis = 0

    for zutat in pizza.zutaten:
        if zutat.name not in zutaten_benutzt:
            zutaten_benutzt += [zutat.name]
            preis += zutat.preis
        else: 
            continue 

    if pizza.größe == 'normal':
        return preis
    elif pizza.größe == 'groß':
        return preis * 1.1

# Funktion, die den Preis eines Gerichts oder eines Getränks berechnet 
# Eingabe: Gericht oder Getränk (typ: Union[Gericht, Getränk])
# Ausgabe: Preis in Euro (typ: float)
def preisberechner(x: Union[Gericht, Getränk]) -> float:
    if isinstance(x, Pizza):
        return pizza_preis(x)
    elif isinstance(x, Nudelgericht):
        return x.preis * (x.bestellmenge / 100)
    elif isinstance(x, Getränk):
        if x.sorte == 'Pils':
            return 0.8 * (x.größe * 10)
        elif x.sorte == 'Weizen':
            return 0.85 * (x.größe * 10)

oliven = Zutat('Oliven', 0.5)
oliven2 = Zutat('Oliven', 0.5)
pilze = Zutat('Pilze', 0.4)
salami = Zutat('Salami', 0.45)
käse = Zutat('Käse', 0.55)

pizza_normal = Pizza('normal', [oliven, pilze, oliven2])
pizza_groß = Pizza('groß', [oliven, pilze, oliven2, salami, käse])

nudelgericht_1 = Nudelgericht('Bandnudeln', 0.57, 800) 
nudelgericht_2 = Nudelgericht('Spaghetti', 1.23, 450)

pils = Getränk('Pils', 0.3)
weizen = Getränk('Weizen', 0.5)

check(pizza_preis(pizza_normal), (0.5 + 0.4))
check(pizza_preis(pizza_groß), ((0.5 + 0.4+ 0.45 + 0.55) * 1.1))

check(preisberechner(pizza_normal), (0.5 + 0.4))
check(preisberechner(pizza_groß), ((0.5 + 0.4+ 0.45 + 0.55) * 1.1))
check(preisberechner(nudelgericht_1), (0.57 * 8))
check(preisberechner(nudelgericht_2), (1.23 * 4.5))
check(preisberechner(pils), (3*0.8))
check(preisberechner(weizen), (5*0.85))