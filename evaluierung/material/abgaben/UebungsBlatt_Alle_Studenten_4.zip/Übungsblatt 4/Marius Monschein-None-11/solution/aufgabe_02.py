from wypp import * 

type Größe = Literal['S', 'M', 'L']

type Farbe = Literal['schwarz', 'grün', 'blau', 'rot']

@record 
class Trikot:
    trikotgröß: Größe
    trikotfarbe: Farbe 
    rückennummer: Optional[int]

@record
class Hose:
    hosengröße: Größe
    hosenfarbe: Farbe
    rückennummer: Optional[int]

@record
class Stutzen:
    unterschranke: int
    oberschranke: int
    stutzenfarbe: Farbe

@record 
class Error:
    message: str

type Sportartikel = Union[Trikot, Hose, Stutzen]


# Funktion, die überprüft, ob optionale Rückennummer vorhanden ist
# Eingabe: beliebiger Sportartikel (typ: Sportartikel)
# Rückgabe: Error, falls keine Rückennummer -> sonst True (typ: bool)
def rückennummer_vorhanden(sportartikel: Sportartikel) -> bool:
    if isinstance(sportartikel, Stutzen):
        return False
    else:
        if isinstance(sportartikel.rückennummer, int):
            return True
        else:
            return False
        
# Funktion, die den Preis eines Sportartikels berechnet 
# Eingabe: beliebiger Sportartike (typ: Sportartikel)
# Rückgabe: Preis in Euro (typ: int)
def preis_sportartikel(sportartikel: Sportartikel) -> int: 
    if isinstance(sportartikel, Trikot):
        if isinstance(sportartikel.rückennummer, int):
            return 25
        else:
            return 20
    elif isinstance(sportartikel, Hose):
        if sportartikel.hosengröße == 'S':
            return 10
        elif sportartikel.hosengröße == 'M':
            return 12 
        elif sportartikel.hosengröße == 'L':
            return 15 
    elif isinstance(sportartikel, Stutzen):
        if sportartikel.oberschranke <= 38:
            return 5 
        else: 
            return 9

trikot_rückennummer = Trikot('S', 'blau', 34)
trikot = Trikot('M', 'rot', None)

hose_rückennummer = Hose('S', 'blau', 77)
hose = Hose('M', 'rot', None)
hose_l = Hose('L', 'blau', None)


stutzen = Stutzen(15, 65, 'blau')
stutzen_klein = Stutzen(15, 37, 'rot')

check(rückennummer_vorhanden(trikot_rückennummer), True)
check(rückennummer_vorhanden(trikot), False)
check(rückennummer_vorhanden(hose_rückennummer), True)
check(rückennummer_vorhanden(hose), False)
check(rückennummer_vorhanden(stutzen), False)

check(preis_sportartikel(trikot_rückennummer), 25)
check(preis_sportartikel(trikot), 20)
check(preis_sportartikel(hose_rückennummer), 10)
check(preis_sportartikel(hose), 12)
check(preis_sportartikel(hose_l), 15)
check(preis_sportartikel(stutzen), 9)
check(preis_sportartikel(stutzen_klein), 5)