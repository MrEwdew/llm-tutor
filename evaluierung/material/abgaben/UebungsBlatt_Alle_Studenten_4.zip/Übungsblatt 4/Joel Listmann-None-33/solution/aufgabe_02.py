from wypp import * 

#DATENBESCHREIBUNG

#Eine Farbe hat folgende Varianten: 
type Farbe = Literal["schwarz", "grün", "blau", "rot"]

#Eine Größe hat folgende Varianten: 
type Größe = Literal["S", "M", "L"]

#Ein Artikel hat folgende varianten: Trikot, Hosen, Stutzen
type Artikel = Union[Trikot, Hose, Stutze]

#Die Rückennummer kann entweder eine Zahl oder vom Typ None sein:
type Rückennummer = Union[str, None]

#Ein Trikot besteht aus:
# - Größe (typ: Größe)
# - Farbe (typ: Farbe)
# - Rückennummer (Rückennummer)

@record
class Trikot:
    größe: Größe
    farbe: Farbe
    rückennummer: Rückennummer


#Eine Hose besteht aus:
# - Größe (typ: Größe)
# - Farbe (typ: Farbe)

@record
class Hose:
    größe: Größe
    farbe: Farbe

#Eine Stützen bestehen aus:
# - Obere Schranke (int)
# - Untere Schranke (int)
# - Farbe (typ: Farbe)

@record
class Stutze:
    obereSchranke: int
    untereSchranke: int
    farbe: Farbe


artikel1 = Stutze(34, 30, "schwarz")
artikel2 = Hose("M", "rot")
artikel3 = Trikot("L", "blau", None)
artikel4 = Trikot("S", "grün", "5")
artikel5 = Stutze(40, 35, "schwarz")
artikel6 = Hose("S", "rot")
artikel7 = Hose("L", "rot")

#Funktion, die entscheidet, ob eine Rückennummer vorhanden ist
#Eingabe: Trikot (typ: Trikot)
#Ergebnis: Rückennummer vorhanden ja/nein? (bool)

def checkRückennummer(trikot: Trikot) -> bool:
    if type(trikot.rückennummer) == str:
        return True
    else:
        return False

check(checkRückennummer(Trikot("L", "blau", "6")), True)
check(checkRückennummer(Trikot("M", "rot", None)), False)

#Funktion, die den Preis eines Sportartikels berechnet
#Eingabe: Artikel (typ: Artikel)
#Ergebmis: Preis in Euro (int)

def berechnePreis(artikel: Artikel) -> int:
    if isinstance(artikel, Hose):
        if artikel.größe == "S":
            return 10
        elif artikel.größe == "M":
            return 12
        else:
            return 15
    elif isinstance(artikel, Trikot):
        if artikel.rückennummer == None:
            return 20
        else:
            return 25
    else:
        if artikel.obereSchranke > 38:
            return 9
        else:
            return 5 


check(berechnePreis(artikel1), 5)
check(berechnePreis(artikel5), 9)
check(berechnePreis(artikel6), 10)
check(berechnePreis(artikel2), 12)
check(berechnePreis(artikel7), 15)
check(berechnePreis(artikel3), 20)
check(berechnePreis(artikel4), 25)