from wypp import * 

#DATENBESCHREIBUNG

#Eine größe hat folgende Varianten: normal und groß
type PizzaGröße = Literal["normal", "groß"]

#Eine Pizza besteht aus folgenden Attributen:
# - Größe (typ: PizzaGröße)
# - oliven ja/nein? (bool)
# - pilze ja/nein? (bool)
# - salami ja/nein? (bool)
# - käse ja/nein? (bool)

@record
class Pizza:
    größe: PizzaGröße
    oliven: bool
    pilze: bool
    salami: bool
    käse: bool

pizza1 = Pizza("groß", True, True, False, False)
pizza2 = Pizza("normal", True, True, False, False)
pizza3 = Pizza("normal", False, False, False, False)
pizza4 = Pizza("groß", False, False, False, False)

#Funktion, die den Preis einer Pizza berechnet
#Eingabe: Pizza (typ: Pizza)
#Ergebnis: Preis in Euro (float)

def berechnePizzaPreis(pizza: Pizza) -> float:
    oliven = 0
    pilze = 0
    salami = 0
    käse = 0

    if pizza.oliven:
        oliven = 0.5
    if pizza.pilze:
        pilze = 0.4
    if pizza.salami:
        salami = 0.45
    if pizza.käse:
        käse = 0.55

    zutatenkosten = oliven + pilze + salami + käse

    if pizza.größe == "groß":
        return zutatenkosten * 1.1 + 2.5
    else:
        return zutatenkosten + 2

check(berechnePizzaPreis(pizza1), 3.49)
check(berechnePizzaPreis(pizza2), 2.9)
check(berechnePizzaPreis(pizza3), 2)
check(berechnePizzaPreis(pizza4), 2.5)


#Ein Bier hat folgende Sorten: Weizen, Pils
type BierSorte = Literal["Weizen", "Pils"]

#Ein Bier hat folgende Größen: 0.3l und 0.5l
type BierGröße = Literal["0.3l", "0.5l"]

#Ein Bier hat folgende Eigenschaften:
# - Sorte (typ: BierSorte)
# - Größe in Liter (typ: BierGröße)
# - Preis pro 100 ml (float)


@record
class Bier:
    sorte: BierSorte
    größeInLiter: BierGröße

bier1 = Bier("Pils", "0.3l")
bier2 = Bier("Weizen", "0.5l")

#Funktion, die den Preis eines Biers berechnet:
#Eingabe: Bier (typ: Bier)
#Ergebnis: Preis (float)

def berechneBierPreis(bier: Bier) -> float:
    if bier.sorte == "Pils":
        if bier.größeInLiter == "0.3l":
            return 0.8 * 3
        else:
            return 0.8 * 5
    else:
        if bier.größeInLiter == "0.3l":
            return 0.85 * 3
        else: 
            return 0.85 * 5

check(berechneBierPreis(bier1), 2.4)
check(berechneBierPreis(bier2), 4.25)

#Ein Nudelgericht hat folgende Eigenschaften:
# - Name (str)
# - Preis pro 100g (float)
# - Bestellmenge in gramm (int)

@record
class Nudelgericht:
    name: str
    preisPro100g: float
    bestellmenge: int

nudelgericht1 = Nudelgericht("Spaghetti Carbonara", 4.30, 300)

#Funktion, die den Preis eines Nudelgerichts berechnet:
#Eingabe: Nudelgericht (typ: Nudelgericht)
#Ergebnis: Preis (float)

def berechneNudelpreis(nudelgericht: Nudelgericht) -> float:
    return nudelgericht.preisPro100g/100 * nudelgericht.bestellmenge

check(berechneNudelpreis(nudelgericht1), 12.9)


#Eine Bestellung hat folgende Varianten: Pizza, Nudelgericht, Bier
type Bestellung = Union[Pizza, Nudelgericht, Bier]

#Funktion, die den Preis einer Bestellung berechnet
#Eingabe: Bestellung (typ: Bestellung)
#Ergebnis: Preis in Euro (float)

def berechneBestellungsPreis(bestellung: Bestellung) -> float:
    if isinstance(bestellung, Pizza):
        return berechnePizzaPreis(bestellung)
    elif isinstance(bestellung, Nudelgericht):
        return berechneNudelpreis(bestellung)
    else:
        return berechneBierPreis(bestellung)


check(berechneBestellungsPreis(pizza1), 3.49)
check(berechneBestellungsPreis(pizza2), 2.9)
check(berechneBestellungsPreis(pizza3), 2)
check(berechneBestellungsPreis(pizza4), 2.5)
check(berechneBestellungsPreis(bier1), 2.4)
check(berechneBestellungsPreis(bier2), 4.25)
check(berechneBestellungsPreis(nudelgericht1), 12.9)