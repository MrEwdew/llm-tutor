from wypp import * 

#DATENBESCHREIBUNG

#Die Antriebsart eines Autos ist entweder: Verbrenner oder Elektrisch 
type AutoAntriebsart = Literal["Verbrenner", "Elektrisch"]

#Die Antriebsart eines Fahrrads ist entweder: Muskelkraft oder Elektrisch 
type FahrradAntriebsart = Literal["Muskelkraft", "Elektrisch"]

#Ein Auto ist Charakterisiert durch:
# - Farbe (str)
# - Marke (str)
# - Antriebsart (typ: AutoAntriebsart)

@record
class Auto:
    farbe: str
    marke: str
    antriebsart: AutoAntriebsart

#Ein Fahrrad ist Charakterisiert durch:
# - Marke (str)
# - Antriebsart (typ: FahrradAntriebsart)

@record
class Fahrrad:
    marke: str
    antriebsart: FahrradAntriebsart

#Ein Fahrzeug ist entweder ein Auto oder ein Fahrrad
type Fahrzeug = Union[Auto, Fahrrad]

fahrzeug1 = Auto("rot", "BMW", "Verbrenner")
fahrzeug2 = Auto("gelb", "Audi", "Elektrisch")

fahrzeug3 = Fahrrad("Fahrradmarke1", "Muskelkraft")
fahrzeug4 = Fahrrad("Fahrradmarke2", "Elektrisch")


#Funktion, die die Reichweite eines Fahrzeugs berechnet
#Eingabe: Fahrzeug (typ: Fahrzeug)
#Ausgabe: Reichweite in km (int)

def berechneReichweite(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Auto):
        return berechneAutoReichweite(fahrzeug)
    else:
        return berechneFahrradReichweite(fahrzeug)

#Funktion, die die Reichweite eines Autos berechnet
#Eingabe: Auto (typ: Auto)
#Ausgabe: Reichweite in km (int)

def berechneAutoReichweite(auto: Auto) -> int:
    if "Verbrenner" in auto.antriebsart:
        return 600
    else: 
        return 400

#Funktion, die die Reichweite eines Fahrrads berechnet
#Eingabe: Fahrrad (typ: Fahrrad)
#Ausgabe: Reichweite in km (int)

def berechneFahrradReichweite(fahrrad: Fahrrad) -> int:
    if "Muskelkraft" in fahrrad.antriebsart:
        return 10000
    else:
        return 120


check(berechneFahrradReichweite(fahrzeug3), 10000)
check(berechneFahrradReichweite(fahrzeug4), 120)
check(berechneAutoReichweite(fahrzeug1), 600)
check(berechneAutoReichweite(fahrzeug2), 400)


check(berechneReichweite(fahrzeug1), 600)
check(berechneReichweite(fahrzeug2), 400)
check(berechneReichweite(fahrzeug3), 10000)
check(berechneReichweite(fahrzeug4), 120)
