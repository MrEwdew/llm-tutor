from wypp import *

# Auto Antreib:
# Verbrenner (typ:str)
# Elektrisch (typ:str)

type AutoAntrieb = Literal['Verbrenner', 'Elektro']

# Fahrrad Antrieb
# Muskelkraft (typ:str)
# Elektro (typ:str)

type FahrradAntrieb = Literal['Muskelkraft', 'Elektro']

# Auto:
# Farbe (typ:str)
# Marke (typ:str)
# Antriebsart (typ:AutoAntrieb)

@record
class Auto:
    farbe: str
    marke: str
    autoantrieb: AutoAntrieb

# Fahrrad:
# Marke (typ:str)
# Antriebsart (typ:FahrradAntrieb)

@record
class Fahrrad:
    marke: str
    fahrradantrieb: FahrradAntrieb

# Fahrzeug Modellierung 

type Fahrzeug = Union[Auto, Fahrrad]

# Funktion zur Ausagbe der Reichweite eines Auto in km
# Eingabe: auto (typ:Auto)
# Ergebnis: Antriebsreichweite Auto (typ:int)

def reichweiteAuto(auto: Auto) -> int:
    if auto.autoantrieb == 'Verbrenner':
        return 600
    else:
        return 400

check(reichweiteAuto(Auto('Schwarz', 'BMW', 'Verbrenner')), 600)
check(reichweiteAuto(Auto('Pink', 'Tesla', 'Elektro')), 400)


# Funktion zur Ausgabe der Reichweite eines Fahrrad in km
# Eingabe: fahrrad (Typ:Fahrrad)
# Ergebnis: Antriebsreichweite Fahrrad (typ:int)

def reichweiteFahrrad(fahrrad: Fahrrad) -> int:
    if fahrrad.fahrradantrieb == 'Elektro':
        return 120
    else:
        return 10000


check(reichweiteFahrrad(Fahrrad('Nike', 'Elektro')), 120)
check(reichweiteFahrrad(Fahrrad('Adidas', 'Muskelkraft')), 10000)


# Funktion zu Berechnung der Reichweite eines Fahrzeuges Auto oder Fahrrad
# Eingabe: fahrzeug (typ:Fahrzeug)
# Ergebnis: Reichweite eines Fahrzeuges in Km (typ:int)

def fahrzeugReichweite(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Fahrrad):
        return reichweiteFahrrad(fahrzeug)
    else:
        return reichweiteAuto(fahrzeug)


check(fahrzeugReichweite(Auto('Schwarz', 'BMW', 'Verbrenner')), 600)
check(fahrzeugReichweite(Auto('Pink', 'Tesla', 'Elektro')), 400)
check(fahrzeugReichweite(Fahrrad('Nike', 'Elektro')), 120)
check(fahrzeugReichweite(Fahrrad('Puma', 'Muskelkraft')), 10000)