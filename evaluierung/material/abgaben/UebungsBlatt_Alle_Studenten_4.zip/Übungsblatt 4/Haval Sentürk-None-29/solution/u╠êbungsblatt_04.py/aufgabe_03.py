from wypp import *

# Groesse:
# - Normal
# - Gross

type Groesse = Literal['Normal', 'Gross']


# Pizza:
# - groesse (typ:Groesse)
# - oliven (typ:bool)
# - pilze (typ:bool)
# - salami (typ:bool)
# - kaese (typ:bool)

@record
class Pizza:
    groesse: Groesse
    oliven: bool
    pilze: bool
    salami: bool
    kaese: bool 

# Funktion zu Preis Berechnung von einer Pizza 
# Eingabe: pizza (typ:Pizza)
# Ausgabe: Preis ind euro (typ:int)

def pizzaPreis(pizza: Pizza) -> float:
    zutaten = 0.0
    if pizza.oliven: 
        zutaten = zutaten + 0.5
    if pizza.pilze:
        zutaten = zutaten + 0.4
    if pizza.salami:
        zutaten = zutaten + 0.45
    if pizza.kaese:
        zutaten = zutaten + 0.55
    if pizza.groesse == 'Gross':
        return zutaten * 1.1 + 2.5 
    else: 
        return zutaten + 2



check(pizzaPreis(Pizza('Normal', True, True, False, False)), 2.90)
check(pizzaPreis(Pizza('Normal', False, False, True, True)), 3)
check(pizzaPreis(Pizza('Gross', True, True, False, False)), 3.49)
check(pizzaPreis(Pizza('Gross', False, False, True, True)), 3.60)



# GroesseBier:
# - 0.3 l (typ:int)
# - 0.5 l (typ:int)

type GroesseBier = Literal[300, 500]

# SorteBier: 
# - Pils
# - Weizen

type SorteBier = Literal['Pils', 'Weizen']

# Bier:
# - groesseBier (typ:GroesseBier)
# - sorteBier (typ:SorteBier)

@record
class Bier:  
    groesseBier: GroesseBier
    sorteBier: SorteBier

# Nudelgericht:
# - Name (typ:str)
# - menge (typ:int)
# - preisPro100 (typ:float)


@record
class Nudelgericht:
    name: str
    menge: int 
    preisPro100g: float

# Bestellung:
# - Nudelgericht
# - Pizza
# - Bier 

type Bestellung = Union[Nudelgericht, Pizza, Bier]


# Funktion zur Preisberechnung eines Grichtes oder Getränk
# Eingabe: 
# - bestellung (typ:Bestellung)
# Ausgabe: 
# Preis in Euro (typ:float)

def bestellungsRechner(bestellung: Bestellung) -> float:
    if isinstance(bestellung, Pizza):
        return pizzaPreis(bestellung)
    elif isinstance(bestellung, Nudelgericht):
        return (bestellung.menge / 100) * bestellung.preisPro100g
    else:
        if bestellung.sorteBier == 'Pils':
            return (bestellung.groesseBier / 100) * 0.80
        else:
            return (bestellung.groesseBier / 100) * 0.85





check(bestellungsRechner(Bier(300, 'Pils')), 2.4)
check(bestellungsRechner(Bier(500, 'Pils')), 4)
check(bestellungsRechner(Bier(300, 'Weizen')), 2.55)
check(bestellungsRechner(Bier(500, 'Weizen')), 4.25)
check(bestellungsRechner(Nudelgericht('Quadroformagie', 120, 10)), 12)
check(bestellungsRechner(Nudelgericht('Pasta Salcica', 200, 15)), 30)
check(bestellungsRechner(Pizza('Normal', True, True, False, False)), 2.90)
check(bestellungsRechner(Pizza('Normal', False, False, True, True)), 3)
check(bestellungsRechner(Pizza('Gross', True, True, False, False)), 3.49)
check(bestellungsRechner(Pizza('Gross', False, False, True, True)), 3.60)
