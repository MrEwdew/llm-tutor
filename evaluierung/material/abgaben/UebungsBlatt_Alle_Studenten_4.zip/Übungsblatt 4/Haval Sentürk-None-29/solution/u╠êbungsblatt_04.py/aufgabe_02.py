from wypp import *

# ---------- Aufgabe 2a ----------

# Rueckennummer:
# - nummer (typ: int)

@record
class Rueckennummer:
    nummer: int

# KeineRueckennummer:
# Markierung, dass keine Rückennummer vorhanden ist (keine Felder)

@record
class KeineRueckennummer:
    pass

# OptionaleRueckennummer:
# entweder Rueckennummer oder KeineRueckennummer

type OptionaleRueckennummer = Union[Rueckennummer, KeineRueckennummer]

# Prüft, ob eine Rückennummer vorhanden ist
# Eingabe:
# - rueckennummer (typ: OptionaleRueckennummer)
# Ergebnis: True, falls vorhanden, sonst False (typ: bool)

def hatRueckennummer(rueckennummer: OptionaleRueckennummer) -> bool:
    if isinstance(rueckennummer, Rueckennummer):
        return True
    else:
        return False

check(hatRueckennummer(Rueckennummer(12)), True)
check(hatRueckennummer(KeineRueckennummer()), False)



# Groesse:
# - S, M, L

type Groesse = Literal['S', 'M', 'L']

# Farbe:
# - schwarz, gruen, blau, rot

type Farbe = Literal['schwarz', 'gruen', 'blau', 'rot']

# Trikot:
# - groesse (typ: Groesse)
# - farbe (typ: Farbe)
# - optionaleRueckennummer (typ: OptionaleRueckennummer)

@record
class Trikot:
    groesse: Groesse
    farbe: Farbe
    optionaleRueckennummer: OptionaleRueckennummer

# Hose:
# - groesse (typ: Groesse)
# - farbe (typ: Farbe)

@record
class Hose:
    groesse: Groesse
    farbe: Farbe

# Stutzen:
# - farbe (typ: Farbe)
# - untereSchranke (typ: int)
# - obereSchranke (typ: int)

@record
class Stutzen:
    farbe: Farbe
    untereSchranke: int
    obereSchranke: int

# Sportartikel:
# entweder Trikot, Hose oder Stutzen

type Sportartikel = Union[Trikot, Hose, Stutzen]



# Berechnet den Preis eines Sportartikels in Euro
# Eingabe:
# - sportartikel (typ: Sportartikel)
# Ergebnis: Preis in Euro (typ: int)

def sportartikelPreis(sportartikel: Sportartikel) -> int:
    if isinstance(sportartikel, Trikot):
        if hatRueckennummer(sportartikel.optionaleRueckennummer):
            return 25
        else:
            return 20
    elif isinstance(sportartikel, Hose):
        if sportartikel.groesse == 'S':
            return 10
        elif sportartikel.groesse == 'M':
            return 12
        else:
            return 15
    else:
        if sportartikel.obereSchranke <= 38:
            return 5
        else:
            return 9

check(sportartikelPreis(Trikot('L', 'blau', KeineRueckennummer())), 20)
check(sportartikelPreis(Trikot('M', 'gruen', Rueckennummer(10))), 25)
check(sportartikelPreis(Hose('S', 'schwarz')), 10)
check(sportartikelPreis(Hose('M', 'schwarz')), 12)
check(sportartikelPreis(Hose('L', 'schwarz')), 15)
check(sportartikelPreis(Stutzen('blau', 36, 38)), 5)
check(sportartikelPreis(Stutzen('blau', 39, 42)), 9)