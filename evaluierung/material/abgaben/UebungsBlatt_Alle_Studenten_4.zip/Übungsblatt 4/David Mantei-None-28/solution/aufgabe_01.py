from wypp import *

# Auto ist charakterisiert durch Farbe und Marke in str und antrieb in Typ AutoAntrieb
# Fahrrad ist charakterisiert durch Marke in str und antrieb in Typ FahrradAntrieb.
# Fahrzeug kann entweder Auto oder Fahrrad sein

type AutoAntrieb = Literal['Verbrenner', 'Elektrisch']
type FahrradAntrieb = Literal['Muskelkraft', 'Elektrisch']

@record
class Auto:
    farbe: str
    marke: str
    antrieb: AutoAntrieb

@record
class Fahrrad:
    marke: str
    antrieb: FahrradAntrieb

type Fahrzeug = Union[Auto, Fahrrad]


# Funktion zur Berechnung der Reichweite eines Fahrzeugs
# Eingabe: Fahrzeug als Auto oder als Fahrrad mit den jeweiligen Attributen
# Ausgabe: Die jeweilige, maximale Kilometerzahl in int
# Für Auto: Verbrenner -> 600, Elektrisch -> 400
# Für Fahrrad: Muskelkraft -> 10000, Elektrisch -> 120

def reichweite(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Auto):
        if fahrzeug.antrieb == 'Verbrenner':
            return 600
        else:
            return 400
    elif isinstance(fahrzeug, Fahrrad):
        if fahrzeug.antrieb == 'Muskelkraft':
            return 10000
        else:
            return 120

check(reichweite(Auto("Rot", "BMW", "Verbrenner")), 600)
check(reichweite(Fahrrad("Pegasus", "Muskelkraft")), 10000)
