from wypp import *

type Groesse = Literal['S', 'M', 'L']
type Farbe = Literal['schwarz', 'grün', 'blau', 'rot']
type Rueckennummer = Union[int, None]

@record
class Trikot:
    groesse: Groesse
    farbe: Farbe
    rückennummer: Rueckennummer

@record
class Hose:
    groesse: Groesse 
    farbe: Farbe

@record
class Stutzen:
    schuh_min: int
    schuh_max: int
    farbe: Farbe


# Funktion, die überprüft, ob Rückennummer vorhanden ist
# Eingabe: rückennummer als Rueckennummer
# Ergebnis: bool

def rueckennummer_vorhanden(rueckennummer: Rueckennummer) -> bool:
    if rueckennummer != None:
        return True
    else:
        return False


# Funktion die den Preis eines Sportartikels berechnet
# Trikot kostet 20€, mit Rückennummer 25€
# Hose kostet in S 10€, in M 12€ und in L 15€
# Stutzen kosten bis Größe 38 nur 5€, sonst 9€
# Eingabe: sportartikel in Sportartikel
# Ergebnis: Preis des jeweiligen Artikels in int

type Sportartikel = Union[Trikot, Hose, Stutzen]

def preis_sportartikel(sportartikel: Sportartikel) -> int:
    if isinstance(sportartikel, Trikot):
        if rueckennummer_vorhanden(sportartikel.rückennummer):
            return 25
        else:
            return 20
    elif isinstance(sportartikel, Hose):
        if sportartikel.groesse == 'S':
            return 10
        elif sportartikel.groesse == 'M':
            return 12
        else:
            return 15
    elif isinstance(sportartikel, Stutzen):
        if sportartikel.schuh_max <= 38:
            return 5
        else:
            return 9

check(preis_sportartikel(Trikot('S', 'rot', 15)), 25)
check(preis_sportartikel(Trikot('S', 'rot', None)), 20)
check(preis_sportartikel(Hose('S', 'rot')), 10)
check(preis_sportartikel(Hose('L', 'schwarz')), 15)
check(preis_sportartikel(Stutzen(32, 36, 'rot')), 5)
check(preis_sportartikel(Stutzen(36, 40, 'rot')), 9)
