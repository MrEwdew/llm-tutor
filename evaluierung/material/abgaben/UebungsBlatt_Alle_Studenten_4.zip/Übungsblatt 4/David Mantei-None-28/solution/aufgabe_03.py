from wypp import *

type Groesse = Literal['Normal', 'Groß']

@record
class Pizza:
    groesse: Groesse
    oliven: bool
    pilze: bool
    salami: bool
    kaese: bool

@record
class Bier:
    sorte: str
    menge: int

@record
class Nudelgericht:
    name: str
    preis: float
    menge: int

type GerichtOderGetraenk = Union[Pizza, Bier, Nudelgericht]

# Funktion zum Berechnen des Preises einer Pizza
# Eingabe: pizza als Typ Pizza
# Ergebnis: Preis der Pizza

def preisPizza(pizza: Pizza) -> float:
    zutatenpreis = 0.0
    if pizza.groesse == 'Normal':
        grundpreis = 2.0
        faktor = 1.0
    else:
        grundpreis = 2.5
        faktor = 1.1
    if pizza.oliven:
        zutatenpreis = zutatenpreis + 0.50
    if pizza.pilze:
        zutatenpreis = zutatenpreis + 0.40
    if pizza.salami:
        zutatenpreis = zutatenpreis + 0.45
    if pizza.kaese:
        zutatenpreis = zutatenpreis + 0.55

    return grundpreis + zutatenpreis * faktor

check(preisPizza(Pizza("Normal", False, False, False, False)), 2.0)
check(preisPizza(Pizza("Normal", True, False, False, False)), 2.5)
check(preisPizza(Pizza("Groß", False, False, False, False)), 2.5)
check(preisPizza(Pizza("Groß", True, True, False, False)), 3.49)


# Funktion zum Berechnen des Preises eines Biers.
# Eingabe: bier in Typ Bier
# Ergebnis: Preis in float

def preisBier(bier: Bier) -> float:
    if bier.sorte == "Pils":
        preis = 0.80
    else:
        preis = 0.85

    return preis * bier.menge / 100

check(preisBier(Bier("Pils", 300)), 2.4)
check(preisBier(Bier("Weizen", 500)), 4.25)


# Funktion zum Berechnen des Preises eines Nudelgerichts.
# Eingabe: nudeln in Typ Nudelgericht
# Ergebnis: Preis in float

def preisNudelgericht(nudeln: Nudelgericht) -> float:
    return nudeln.preis * nudeln.menge / 100

check(preisNudelgericht(Nudelgericht("Penne", 1.20, 250)), 3.0)


# Funktion zum Berechnen des Preises einer Pizza, eines Nudelgerichts
# oder eines Getränks.
# Eingabe: bestellung in Typ GerichtOderGetraenk
# Ergebnis: Preis in float

def preisGerichtOderGetraenk(bestellung: GerichtOderGetraenk) -> float:
    if isinstance(bestellung, Pizza):
        return preisPizza(bestellung)
    elif isinstance(bestellung, Bier):
        return preisBier(bestellung)
    else:
        return preisNudelgericht(bestellung)


check(preisGerichtOderGetraenk(Pizza('Normal', False, False, True, False)), 2.45)
check(preisGerichtOderGetraenk(Bier("Pils", 300)), 2.4)
check(preisGerichtOderGetraenk(Nudelgericht("Penne", 1.20, 250)), 3.0)
