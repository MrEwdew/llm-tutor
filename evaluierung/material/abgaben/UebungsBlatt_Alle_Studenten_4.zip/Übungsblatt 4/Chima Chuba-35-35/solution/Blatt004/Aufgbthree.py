
from wypp import *


# DATENBESCHREIBUNG
# Eine Pizza hat eine Größe und verschiedene Zutaten
# Jede Zutat kann vorhanden sein oder nicht


# TYPDEFINITION

type Pizzagroesse = Literal["Normal", "Gross"]


@record
class Pizza:
    groesse: Pizzagroesse
    oliven: bool
    pilze: bool
    salami: bool
    kaese: bool


# PREIS PIZZA
# Eingabe: eine Pizza (Typ: Pizza)
# Ergebnis: Preis in Euro (Typ: float)

def preisPizza(p: Pizza) -> float:
    if p.groesse == "Normal":
        preis = 2.0
    else:
        preis = 2.5

    zutatenPreis = 0.0

    if p.oliven:
        zutatenPreis = zutatenPreis + 0.50

    if p.pilze:
        zutatenPreis = zutatenPreis + 0.40

    if p.salami:
        zutatenPreis = zutatenPreis + 0.45

    if p.kaese:
        zutatenPreis = zutatenPreis + 0.55

    if p.groesse == "Gross":
        zutatenPreis = zutatenPreis * 1.10

    return preis + zutatenPreis


# TEIL B

# BIER

type Biersorte = Literal["Pils", "Weizen"]
type Biergroesse = Literal[0.3, 0.5]


@record
class Bier:
    sorte: Biersorte
    groesse: Biergroesse


# NUDELGERICHT

@record
class Nudeln:
    name: str
    preisPro100g: float
    menge: int


# UNION

type Bestellung = Union[Pizza, Bier, Nudeln]


# PREIS BIER
# Eingabe: ein Bier
# Ergebnis: Preis in Euro

def preisBier(b: Bier) -> float:
    if b.sorte == "Pils":
        return b.groesse * 10 * 0.80
    else:
        return b.groesse * 10 * 0.85


# PREIS NUDELN
# Eingabe: ein Nudelgericht
# Ergebnis: Preis in Euro

def preisNudeln(n: Nudeln) -> float:
    return n.preisPro100g * n.menge / 100


# PREIS BESTELLUNG
# Eingabe: Pizza, Bier oder Nudeln
# Ergebnis: Preis in Euro

def preisBestellung(b: Bestellung) -> float:
    if isinstance(b, Pizza):
        return preisPizza(b)
    elif isinstance(b, Bier):
        return preisBier(b)
    else:
        return preisNudeln(b)


# BEISPIELE

pizza1 = Pizza("Normal", True, False, True, False)
pizza2 = Pizza("Gross", True, True, True, True)

bier1 = Bier("Pils", 0.3)
bier2 = Bier("Weizen", 0.5)

nudeln1 = Nudeln("Spaghetti", 1.50, 300)


# TESTS

check(preisPizza(pizza1), 2.95)
check(preisPizza(pizza2), 4.59)

check(preisBier(bier1), 2.40)
check(preisBier(bier2), 4.25)

check(preisNudeln(nudeln1), 4.50)

check(preisBestellung(pizza1), 2.95)
check(preisBestellung(bier1), 2.40)
check(preisBestellung(nudeln1), 4.50)
