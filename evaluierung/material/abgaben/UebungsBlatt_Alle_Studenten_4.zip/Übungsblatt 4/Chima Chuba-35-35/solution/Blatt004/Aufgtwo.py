from wypp import * 

type Trikotgröße = Literal["S", "M", "L"]
type Trikotfarbe = Literal["Schwarz", "Grün", "Blau", "Rot"]

@record
class Trikot:
    größe: Trikotgröße
    farbe: Trikotfarbe
    nummer: Union[int, None]





type hosengröße = Literal["S", "M", "L"]
type hosentfarbe = Literal["Schwarz", "Grün", "Blau", "Rot"]


@record
class Hose:
    größe: hosengröße
    farbe: hosentfarbe



type stutzenfarbe = Literal["Schwarz", "Grün", "Blau", "Rot"]
type schranke = Literal["Klein", "Groß"]


@record
class Stutzen:
    farbe: stutzenfarbe
    größe: schranke



type Ware = Union[Trikot, Hose, Stutzen]


trikot1 = Trikot("L", "Schwarz" , 20)
trikot2 = Trikot("M", "Grün", 10)


def preistrikot(t: Trikot) -> int:
    if t.nummer == int:
        return 25
    else:
        return 20








