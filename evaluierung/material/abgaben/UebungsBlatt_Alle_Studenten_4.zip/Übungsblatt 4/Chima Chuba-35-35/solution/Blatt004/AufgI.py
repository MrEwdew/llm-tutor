
from wypp import *


# DATENBESCHREIBUNG
# Ein Auto hat eine Farbe, Marke und Antriebsart
# Ein Fahrrad hat eine Marke und Antriebsart


# TYPDEFINITION

type AutoAntrieb = Literal["Verbrenner", "Elektrisch"]
type FahrradAntrieb = Literal["Muskelkraft", "Elektrisch"]


@record
class Auto:
    farbe: str
    marke: str
    antrieb: AutoAntrieb


@record
class Fahrrad:
    marke: str
    antrieb: FahrradAntrieb


type Fahrzeug = Union[Auto, Fahrrad]


# BEISPIELE

auto1 = Auto("Schwarz", "BMW", "Verbrenner")
auto2 = Auto("Weiß", "Tesla", "Elektrisch")

fahrrad1 = Fahrrad("Cube", "Muskelkraft")
fahrrad2 = Fahrrad("Bosch", "Elektrisch")


# REICHWEITE AUTO
# Eingabe: Auto
# Ergebnis: Reichweite in km (int)

def reichweiteAuto(a: Auto) -> int:
    if a.antrieb == "Verbrenner":
        return 600
    else:
        return 400


# REICHWEITE FAHRRAD
# Eingabe: Fahrrad
# Ergebnis: Reichweite in km (int)

def reichweiteFahrrad(f: Fahrrad) -> int:
    if f.antrieb == "Muskelkraft":
        return 10000
    else:
        return 120


# REICHWEITE FAHRZEUG
# Eingabe: Fahrzeug
# Ergebnis: Reichweite in km (int)

def reichweite(f: Fahrzeug) -> int:
    if isinstance(f, Auto):
        return reichweiteAuto(f)
    else:
        return reichweiteFahrrad(f)


# TESTS

check(reichweite(auto1), 600)
check(reichweite(auto2), 400)
check(reichweite(fahrrad1), 10000)
check(reichweite(fahrrad2), 120)
