from wypp import *

# Funktion für ein Bestellfomular für Sportartikel

# Eine Union um zu unterscheiden ob Nummer gewollt oder nicht

type Trikotnummer = Union[int, None]

# Feste größen und farben in jeweils einen Literal gepackt.
# Farben:
# - schwarz, grün, blau, rot (str)
# Größen:
# - S, M, L (str)

type Größen = Literal["S", "M", "L"]
type Farben = Literal["schwarz", "grün", "blau", "rot"]

# Datensatz eines Trikots
# Ein Trikot hat:
# - Größe (str)
# - Farbe (str)
# optional
# - Rückennummer (int)

@record
class Trikot:
    tgröße: Größen
    tfarbe: Farben
    optional: Trikotnummer


# Funktion für Trikot mit oder ohne Rückennummer
# Eingabe:
# - größe (str)
# - farbe (str)
# - optional nummer (int)
# Ausgabe:
# - Nummer ja/nein (bool)

def nummerjanein(trikot: Trikot) -> bool:
    if trikot.optional == None:
        return False
    else:
        return True


check(nummerjanein(Trikot("L", "grün", None)), False)
check(nummerjanein(Trikot("S", "schwarz", 7)), True)

# Datenbeschreibug einer Hose
# eine Hose hat:
# - Größe (str)
# - Farbe (str)

@record
class Hose:
    hgröße: Größen
    hfarbe: Farben

# Datenbeschreibung einer Stutze
# eine Stutze hat:
# - Farbe (str)
# - Schuhgröße (int)

@record
class Stutze:
    sfarbe: Farben
    schuhgröße: int


# erstellen einer Union Sportartikel für die Funktion
# Beinhaltet die Klassen:
# - Trikot
# - Rückennummer
# - Hose
# - Stutze

type Sportartikel = Union[Trikot, Hose, Stutze]

# Funktion zur Berechnung der kosten eines Sportartikels
# Ein Trikot kostet: 20€, +25€ falls Rückennummer
# Eine Hose kostet: 10€ (S), 12€ (M), 15€ (L)
# Stutzen kosten: 5€ (<= 38), 9€ (> 38)
# Eingabe:
# - Trikot (str); [optional] Rückennummer (int)
# - Hose (str)
# - Stutze (str) (int)
# Ausgabe:
# - Kosten (int)

def kosten(artikel: Sportartikel) -> int:
    if isinstance(artikel, Trikot):
        if nummerjanein(artikel) == True:
            return 25
        else:
            return 20
    elif isinstance(artikel, Hose):
        if artikel.hgröße == "S":
            return 10
        elif artikel.hgröße == "M":
            return 12
        else:
            return 15
    else:
        if artikel.schuhgröße > 38:
            return 9
        else:
            return 5

check(kosten(Trikot("L", "rot", None)), 20)
check(kosten(Trikot("S", "rot", 7)), 25)
check(kosten(Hose("S", "grün")), 10)
check(kosten(Hose("M", "blau")), 12)
check(kosten(Hose("L", "schwarz")), 15)
check(kosten(Stutze("rot", 38)), 5)
check(kosten(Stutze("blau", 39)), 9)
