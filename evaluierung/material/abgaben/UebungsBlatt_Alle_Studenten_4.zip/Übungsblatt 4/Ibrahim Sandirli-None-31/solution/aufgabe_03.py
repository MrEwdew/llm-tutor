from wypp import *

# Berechung der Preise bei Cheap&Dirty

# Datenbeschreibung Zutaten
# Wir haben 4 Zutaten:
# - Oliven  (bool)
# - Pilze   (bool)
# - Salami  (bool)
# - Käse    (bool)

@record
class Zutaten:
    oliven: bool
    pilze: bool
    salami: bool
    käse: bool

# Es gibt zwei Verschiedene Größen zur Auswahl
# - normal  (str)
# - groß    (str)

type Größen = Literal["normal", "groß"]

# Datenbeschreibung Pizza
# Es hat:
# - Größen  
# - Zutaten 

@record
class Pizza:
    größen: Größen
    zutaten: Zutaten

# Beispiel Pizza zur Vereinfachung

pizza1 = Pizza("normal", Zutaten(True, False, False, True))

# Eine Funktion zur Berechnung der Kosten einer Pizza
# Eingabe:
# - eine Größe  (str)
# - Zutaten
# Ausgabe:
# - Kosten      (float)

def kostenpizza(pizza: Pizza) -> float:
    normal = 2
    groß = 2.5
    zutatenpreis = 0
    if pizza.zutaten.oliven == True:
        zutatenpreis = zutatenpreis + 0.5
    if pizza.zutaten.pilze == True:
        zutatenpreis = zutatenpreis + 0.4
    if pizza.zutaten.salami == True:
        zutatenpreis = zutatenpreis + 0.45
    if pizza.zutaten.käse == True:
        zutatenpreis = zutatenpreis + 0.55
    if pizza.größen == "normal":
        return normal + zutatenpreis
    elif pizza.größen == "groß":
        return groß + (zutatenpreis * 1.1)


check(kostenpizza(Pizza("normal", Zutaten(False, False, False, False))), 2)
check(kostenpizza(Pizza("groß", Zutaten(False, False, False, False))), 2.5)
check(kostenpizza(pizza1), 3.05)
check(kostenpizza(Pizza("groß", Zutaten(True, False, True, False))), 3.545)

# Die zwei verschiedenen Bier Sorten als ein Literal
# Pils      (str)
# Weizen    (str)

type Sorten = Literal["Pils", "Weizen"]

# Die Füllmenge in millilitern zur auswahl

type Menge = Literal[300, 500]

# Datenbeschreibung Bier
# Es hat:
# - Sorten
# - Menge

@record
class Bier:
    sorten: Sorten
    menge: Menge

# Datenbeschreibung NudelGericht
# Es hat:
# - Namen   (str)
# - gramm   (int)
# - preis   (float)

@record
class NudelGericht:
    name: str
    gramm: int
    preispro100gramm: float

# Für die Fallunterscheidung eine Union
# Es beinhaltet:
# - Pizza
# - Nudelgericht
# - Bier

type Alles = Union[Pizza, NudelGericht, Bier]

# Funktion zur Berechung der Bestellung mit Fallunterscheidung
# Eingabe:
# - Alles
# Ausgabe:
# - Kosten  (float)

def kostenalles(alles: Alles) -> float:
    if isinstance(alles, Pizza):
        return kostenpizza(alles)
    elif isinstance(alles, NudelGericht):
        return float(alles.gramm / 100) * alles.preispro100gramm
    else:
        if alles.sorten == "Pils":
            return float(alles.menge / 100) * 0.8
        else:
            return float(alles.menge / 100) * 0.85

check(kostenalles(pizza1), 3.05)
check(kostenalles(Bier("Pils", 300)), 2.40)
check(kostenalles(Bier("Pils", 500)), 4.0)
check(kostenalles(Bier("Weizen", 500)), 4.25)
check(kostenalles(Bier("Weizen", 300)), 2.55)
check(kostenalles(NudelGericht("Spaghetti Bolognese", 200, 0.6)), 1.2)
check(kostenalles(NudelGericht("Spaghetti Carbonara", 360, 1.2)), 4.32)