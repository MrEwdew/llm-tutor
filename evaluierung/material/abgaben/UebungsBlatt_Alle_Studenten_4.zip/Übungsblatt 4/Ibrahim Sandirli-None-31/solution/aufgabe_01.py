from wypp import *


# Verschiedenen Antriebsarten in einem Literal
# Gegeben sind 3 verschiedene
# Autos haben Verbrenner und elektrisch
# Fahrräder haben Muskelkraft und elektrisch

type AntriebsartAuto = Literal["Verbrenner", "elektrisch"]
type AntriebsartFahrrad = Literal["Muskelkraft", "elektrisch"]

# Datenbeshreibung eines Autos
# Es hat:
# - Farbe (str)
# - Marke (str)
# - Antriebsart (str)

@record
class Auto:
    farbe: str
    marke: str
    antriebsart: AntriebsartAuto

# Datenbeschreibung Fahrrad
# Ein Fahrrad hat:
# - Marke (str)
# - Antriebsart (str)

@record
class Fahrrad:
    marke: str
    antriebsart: AntriebsartFahrrad

type Fahrzeug = Union[Auto, Fahrrad]

# Hilfsfunktion zur Bestimmung ob Reichweite eines Fahrrads
# Eingabe:
# > marke (str)
# > antriebsart (str)
# Ausgabe:
# - Reichweiten (int)

def reichweiteFahrrad(fahrrad: Fahrrad) -> int:
    if fahrrad.antriebsart == "elektrisch":
        return 120
    else: 
        return 10000

check(reichweiteFahrrad(Fahrrad("Cube", "elektrisch")), 120)
check(reichweiteFahrrad(Fahrrad("Cube", "Muskelkraft")), 10000)

# Hilfsfunktion zur Bestimmung der Reichweite eines Autos
# Eingabe:
# > farbe (str)
# > marke (str)
# > antriebsart (str)
# Ausgabe:
# - Reichweiten (int)

def reichweiteAuto(auto: Auto) -> int:
    if auto.antriebsart == "elektrisch":
        return 400
    else:
        return 600
    
check(reichweiteAuto(Auto("Blau", "BMW", "elektrisch")), 400)
check(reichweiteAuto(Auto("Lila", "Mercedes", "Verbrenner")), 600)

# Eine Funktion zur berrechnung der Reichweite
# Eingabe:
# - Auto oder Fahrrad (str)
# Ausgabe:
# - Reichweite (int)

def reichweite(f: Fahrzeug) -> int:
    if isinstance(f, Auto):
        return reichweiteAuto(f)
    else:
        return reichweiteFahrrad(f)
    
check(reichweite(Auto("Blau", "Hyundai", "elektrisch")), 400)
check(reichweite(Auto("Lila", "Mercedes", "Verbrenner")), 600)
check(reichweite(Fahrrad("Cube", "elektrisch")), 120)
check(reichweite(Fahrrad("Pegasus", "Muskelkraft")), 10000)
