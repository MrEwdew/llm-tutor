from wypp import *
#Aufgabe 3
#Pizza:

#größe
#normal: 2€
#groß: 2,50€

#Zutaten (normal):
#Oliven: 0,50€
#Pilze: 0,40€
#Salami:0,45€
#Käse: 0,55€

#Zutaten (groß) -> mit 10%
#Zutaten könenn gemischt werden aber nur max. 1 vorkomen

type Größe = Literal['normal', 'gross']

@record
class Pizza:
    size: Größe
    oliven: bool
    pilze: bool
    salami: bool
    käse: bool

def preis(p: Pizza) -> float:
    grundpreis = 0
    preiszutaten = 0

    if p.oliven:
        preiszutaten += 0.5

    if p.pilze:
        preiszutaten += 0.4

    if p.salami:
        preiszutaten += 0.45

    if p.käse:
        preiszutaten += 0.55


    if p.size == 'normal':
        grundpreis += 2
        return grundpreis + preiszutaten

    
    elif p.size == 'gross':
        grundpreis += 2.5
        aufschlag = preiszutaten * 1.10
        return grundpreis + aufschlag 
         


# Nur Grundpreis (ohne Zutaten)
check(preis(Pizza('normal', False, False, False, False)), 2.0)

# Normal mit Oliven (0.50) und Salami (0.45)
check(preis(Pizza('normal', True, False, True, False)), 2.95)

# Groß mit Pilzen (0.40 * 1.10 = 0.44) 
check(preis(Pizza('gross', False, True, False, False)), 2.94)

# Groß mit allen Zutaten (1.90 * 1.10 = 2.09)
check(preis(Pizza('gross', True, True, True, True)), 4.59)



#Preise von Bier
#Bier: Pilz Weizen
#größe: 0.3, 0.5
#pils 100ml: 0,8
#weizen 100ml: 0,85

#Preise von Nudeln
#name
#preis pro 100g
#bestellmenge in 100g

#preis gericht (pizza, nudeln oder getränk)

type Biersorte = Literal['Pils', 'Weizen']
type Biergröße = Literal['0.3', '0.5']

@record
class Bier:
    sorte: Biersorte
    bgröße: Biergröße

def preisbier(pb: Bier) -> float:
    if pb.sorte == 'Pils' and pb.bgröße == '0.3':
        return 3 * 0.8

    elif pb.sorte == 'Pils' and pb.bgröße == '0.5':
        return 5 * 0.8

    elif pb.sorte == 'Weizen' and pb.bgröße == '0.3':
        return 3 * 0.85

    else:
        return 5 * 0.85



@record
class Nudeln:
    name: str
    preispro100g: float
    bestellmengein100g: int

def preisnudel(pn: Nudeln) -> float:
    return pn.preispro100g * (pn.bestellmengein100g/100)

type Gericht = Union[Pizza, Bier, Nudeln]

def end_preis(ep: Gericht) -> float:
    if  isinstance(ep, Pizza): 
        return preis(ep)

    if isinstance(ep, Bier):
        return preisbier(ep)

    if isinstance(ep, Nudeln):
        return preisnudel(ep)

# Große Pizza mit Pilzen
check(end_preis(Pizza('gross', False, True, False, False)), 2.94)

# Pils 0.3 l
check(end_preis(Bier('Pils', '0.3')), 2.40)

# Nudeln
check(end_preis(Nudeln('Penne', 2.00, 300)), 6.0)