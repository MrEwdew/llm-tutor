from wypp import *

# Aufgabe 2

type Trikotgroesse = Literal['S', 'M', 'L']
type Trikotfarbe = Literal['schwarz', 'grün', 'blau', 'rot']

type Vorhandenenummer = Union[int, None]

@record
class Trikot:
    tgroesse: Trikotgroesse
    tfarbe: Trikotfarbe
    tnummer: Vorhandenenummer

def optionalnummer(nr: Vorhandenenummer) -> bool:
    return isinstance(nr, int)

type Hosegroesse = Literal['S', 'M', 'L']
type Hosefarbe = Literal['schwarz', 'grün', 'blau', 'rot']

@record
class Hose:
    hgroesse: Hosegroesse
    hfarbe: Hosefarbe

type Stutzenfarbe = Literal['schwarz', 'grün', 'blau', 'rot']

@record
class Stutzen:
    smin: int
    smax: int
    sfarbe: Stutzenfarbe

def ptrikot(pt: Trikot) -> float:
    if optionalnummer(pt.tnummer):
        return 25.0
    else:
        return 20.0

def phose(ph: Hose) -> float:
    if ph.hgroesse == 'S':
        return 10.0
    elif ph.hgroesse == 'M':
        return 12.0
    else:
        return 15.0

def pstutzen(ps: Stutzen) -> float:
    if ps.smax <= 38:
        return 5.0
    else:
        return 9.0

type Sportartikel = Union[Trikot, Hose, Stutzen]

def preis(p: Sportartikel) -> float:
    if isinstance(p, Trikot):
        return ptrikot(p)
    elif isinstance(p, Hose):
        return phose(p)
    else:
        return pstutzen(p)

check(preis(Trikot('L', 'grün', 7)), 25.0)
check(preis(Hose('M', 'schwarz')), 12.0)
check(preis(Stutzen(36, 41, 'rot')), 9.0)