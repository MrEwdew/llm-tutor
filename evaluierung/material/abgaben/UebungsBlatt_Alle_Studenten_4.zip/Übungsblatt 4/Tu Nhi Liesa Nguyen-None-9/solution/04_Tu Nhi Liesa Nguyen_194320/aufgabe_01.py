from wypp import *
#Aufgabe 1
#Auto oder Fahrrad

#Auto hat:
#Farbe: str
#Marke: str
#Antreibsart: Verbrenner o. elektrisch

#Fahrrad:
#marke: str
#Antriebsart: elektrisch o. muskelkraft

#!!!Kein Hybrid

type AntriebsartAuto = Literal['verbrenner', 'elektrisch']

type AntriebsartFahrrad = Literal['elektrisch', 'muskelkraft']

@record
class Auto:
    farbe: str
    marke: str
    antriebauto: AntriebsartAuto

@record
class Fahrrad:
    marke: str
    antriebfahrrad: AntriebsartFahrrad

type Fahrzeug = Union[Auto, Fahrrad]

#Reichweite eines Fahrzeug wird berechnet.
#Auto:
#Verbrenner: 600km
#elektrisch: 400km

#Fahrrad:
#elektrisch: 120km
#muskelkraft: 10 000km

def berechnungauto(a: Auto) -> int:
    if a.antriebauto == 'verbrenner':
        return 600

    else:
        return 400


def berechnungfahrrad(f: Fahrrad) -> int:
    if f.antriebfahrrad == 'elektrisch':
        return 120

    else:
        return 10000
    

def reichweite(fahrz: Fahrzeug) -> int:
    if isinstance(fahrz, Auto):
        return berechnungauto(fahrz)

    else:
        return berechnungfahrrad(fahrz)

check(reichweite(Auto('rot', 'VW', 'verbrenner')), 600)
check(reichweite(Fahrrad('btwin', 'muskelkraft')), 10000)
