from wypp import *


# Aufgabe 1(a): Datenmodell

# Ein AutoAntrieb ist eins der folgenden:
# - 'verbrenner',
# - 'elektrisch'.
type AutoAntrieb = Literal['verbrenner', 'elektrisch']

# Ein FahrradAntrieb ist eins der folgenden:
# - 'muskelkraft',
# - 'elektrisch'.
type FahrradAntrieb = Literal['muskelkraft', 'elektrisch']


# Ein Auto besteht aus:
# - seiner Farbe (str),
# - seiner Marke (str),
# - seinem Antrieb (AutoAntrieb).
@record
class Auto:
    farbe: str
    marke: str
    antrieb: AutoAntrieb


# Ein Fahrrad besteht aus:
# - seiner Marke (str),
# - seinem Antrieb (FahrradAntrieb).
@record
class Fahrrad:
    marke: str
    antrieb: FahrradAntrieb


# Ein Fahrzeug ist eins der folgenden:
# - ein Auto,
# - ein Fahrrad.
type Fahrzeug = Union[Auto, Fahrrad]


# Aufgabe 1(b): Reichweiten

# Berechnet die Reichweite eines Autos.
# Eingabe: ein Auto.
# Ergebnis: die Reichweite in Kilometern (int).
def autoReichweite(auto: Auto) -> int:
    if auto.antrieb == 'verbrenner':
        return 600
    else:
        return 400


check(autoReichweite(Auto('rot', 'Opel', 'verbrenner')), 600)
check(autoReichweite(Auto('blau', 'VW', 'elektrisch')), 400)


# Berechnet die Reichweite eines Fahrrads.
# Eingabe: ein Fahrrad.
# Ergebnis: die Reichweite in Kilometern (int).
def fahrradReichweite(fahrrad: Fahrrad) -> int:
    if fahrrad.antrieb == 'elektrisch':
        return 120
    else:
        return 10000


check(fahrradReichweite(Fahrrad('Cube', 'elektrisch')), 120)
check(fahrradReichweite(Fahrrad('Bergamont', 'muskelkraft')), 10000)


# Berechnet die Reichweite eines Fahrzeugs.
# Eingabe: ein Fahrzeug, also ein Auto oder ein Fahrrad.
# Ergebnis: die Reichweite in Kilometern (int).
def fahrzeugReichweite(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Auto):
        return autoReichweite(fahrzeug)
    elif isinstance(fahrzeug, Fahrrad):
        return fahrradReichweite(fahrzeug)


check(fahrzeugReichweite(Auto('rot', 'Opel', 'verbrenner')), 600)
check(fahrzeugReichweite(Auto('blau', 'VW', 'elektrisch')), 400)
check(fahrzeugReichweite(Fahrrad('Cube', 'elektrisch')), 120)
check(fahrzeugReichweite(Fahrrad('Bergamont', 'muskelkraft')), 10000)
