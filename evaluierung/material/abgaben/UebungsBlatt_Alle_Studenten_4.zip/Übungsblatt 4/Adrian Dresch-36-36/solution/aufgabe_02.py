from wypp import *


# Aufgabe 2(a): Optionale Rueckennummer

# Eine Rueckennummer besteht aus:
# - der aufzudruckenden Nummer (int).
@record
class Rueckennummer:
    nummer: int


# KeineRueckennummer steht fuer einen Artikel ohne Rueckennummer.
# Dieser Record hat keine weiteren Eigenschaften.
@record
class KeineRueckennummer:
    pass


# Eine OptionaleRueckennummer ist eins der folgenden:
# - eine vorhandene Rueckennummer (Rueckennummer),
# - eine fehlende Rueckennummer (KeineRueckennummer).
type OptionaleRueckennummer = Union[Rueckennummer, KeineRueckennummer]


# Entscheidet, ob eine Rueckennummer vorhanden ist.
# Eingabe: eine OptionaleRueckennummer.
# Ergebnis: True, wenn eine Nummer vorhanden ist, sonst False (bool).
def rueckennummerVorhanden(rueckennummer: OptionaleRueckennummer) -> bool:
    if isinstance(rueckennummer, Rueckennummer):
        return True
    elif isinstance(rueckennummer, KeineRueckennummer):
        return False


check(rueckennummerVorhanden(KeineRueckennummer()), False)
check(rueckennummerVorhanden(Rueckennummer(7)), True)
check(rueckennummerVorhanden(Rueckennummer(0)), True)


# Aufgabe 2(b): Datenmodell der Sportartikel

# Eine Groesse ist eins der folgenden:
# - 'S',
# - 'M',
# - 'L'.
type Groesse = Literal['S', 'M', 'L']

# Eine Farbe ist eins der folgenden:
# - 'schwarz',
# - 'gruen',
# - 'blau',
# - 'rot'.
type Farbe = Literal['schwarz', 'gruen', 'blau', 'rot']


# Ein Trikot besteht aus:
# - seiner Groesse (Groesse),
# - seiner Farbe (Farbe),
# - seiner optionalen Rueckennummer (OptionaleRueckennummer).
@record
class Trikot:
    groesse: Groesse
    farbe: Farbe
    rueckennummer: OptionaleRueckennummer


# Eine Hose besteht aus:
# - ihrer Groesse (Groesse),
# - ihrer Farbe (Farbe).
@record
class Hose:
    groesse: Groesse
    farbe: Farbe


# Stutzen bestehen aus:
# - ihrer unteren Schuhgroesse (int),
# - ihrer oberen Schuhgroesse (int),
# - ihrer Farbe (Farbe).
# Die untere Groesse ist hoechstens die obere Groesse.
@record
class Stutzen:
    untereSchuhgroesse: int
    obereSchuhgroesse: int
    farbe: Farbe


# Ein Sportartikel ist eins der folgenden:
# - ein Trikot,
# - eine Hose,
# - Stutzen.
type Sportartikel = Union[Trikot, Hose, Stutzen]


# Aufgabe 2(c): Preise

# Berechnet den Preis eines Trikots.
# Eingabe: ein Trikot.
# Ergebnis: der Preis in Euro (int).
def trikotPreis(trikot: Trikot) -> int:
    if rueckennummerVorhanden(trikot.rueckennummer):
        return 25
    else:
        return 20


check(trikotPreis(Trikot('S', 'schwarz', KeineRueckennummer())), 20)
check(trikotPreis(Trikot('M', 'gruen', Rueckennummer(7))), 25)
check(trikotPreis(Trikot('L', 'rot', Rueckennummer(0))), 25)


# Berechnet den Preis einer Hose.
# Eingabe: eine Hose.
# Ergebnis: der Preis in Euro (int).
def hosePreis(hose: Hose) -> int:
    if hose.groesse == 'S':
        return 10
    elif hose.groesse == 'M':
        return 12
    else:
        return 15


check(hosePreis(Hose('S', 'blau')), 10)
check(hosePreis(Hose('M', 'schwarz')), 12)
check(hosePreis(Hose('L', 'gruen')), 15)


# Berechnet den Preis eines Paars Stutzen.
# Eingabe: Stutzen mit unterer und oberer Schuhgroesse.
# Ergebnis: der Preis in Euro (int).
def stutzenPreis(stutzen: Stutzen) -> int:
    if stutzen.obereSchuhgroesse <= 38:
        return 5
    else:
        return 9


check(stutzenPreis(Stutzen(30, 35, 'rot')), 5)
check(stutzenPreis(Stutzen(35, 38, 'blau')), 5)
check(stutzenPreis(Stutzen(35, 39, 'schwarz')), 9)


# Berechnet den Preis eines Sportartikels.
# Eingabe: ein Sportartikel, also ein Trikot, eine Hose oder Stutzen.
# Ergebnis: der Preis in Euro (int).
def sportartikelPreis(sportartikel: Sportartikel) -> int:
    if isinstance(sportartikel, Trikot):
        return trikotPreis(sportartikel)
    elif isinstance(sportartikel, Hose):
        return hosePreis(sportartikel)
    elif isinstance(sportartikel, Stutzen):
        return stutzenPreis(sportartikel)


check(sportartikelPreis(Trikot('S', 'schwarz', KeineRueckennummer())), 20)
check(sportartikelPreis(Trikot('M', 'gruen', Rueckennummer(7))), 25)
check(sportartikelPreis(Trikot('L', 'rot', Rueckennummer(0))), 25)
check(sportartikelPreis(Hose('S', 'blau')), 10)
check(sportartikelPreis(Hose('M', 'schwarz')), 12)
check(sportartikelPreis(Hose('L', 'gruen')), 15)
check(sportartikelPreis(Stutzen(35, 38, 'blau')), 5)
check(sportartikelPreis(Stutzen(35, 39, 'rot')), 9)
