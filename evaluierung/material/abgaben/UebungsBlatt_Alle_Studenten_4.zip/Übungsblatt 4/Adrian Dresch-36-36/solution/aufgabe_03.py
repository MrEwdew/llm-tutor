from wypp import *


# Aufgabe 3(a): Pizza

# Eine Pizzagroesse ist eins der folgenden:
# - 'normal',
# - 'gross'.
type PizzaGroesse = Literal['normal', 'gross']


# Eine Pizza besteht aus:
# - ihrer Groesse (PizzaGroesse),
# - der Angabe, ob Oliven gewuenscht sind (bool),
# - der Angabe, ob Pilze gewuenscht sind (bool),
# - der Angabe, ob Salami gewuenscht ist (bool),
# - der Angabe, ob Kaese gewuenscht ist (bool).
# Jede Zutat kann durch ihren bool-Wert hoechstens einmal vorkommen.
@record
class Pizza:
    groesse: PizzaGroesse
    oliven: bool
    pilze: bool
    salami: bool
    kaese: bool


# Berechnet den Preisanteil einer einzelnen Zutat fuer eine normale Pizza.
# Eingaben: ob die Zutat gewuenscht ist (bool), ihr Normalpreis in Euro (float).
# Ergebnis: der Preisanteil in Euro (float).
def zutatPreis(vorhanden: bool, normalpreis: float) -> float:
    if vorhanden:
        return normalpreis
    else:
        return 0.0


check(zutatPreis(True, 0.50), 0.50)
check(zutatPreis(False, 0.50), 0.0)
check(zutatPreis(True, 0.40), 0.40)
check(zutatPreis(False, 0.55), 0.0)


# Berechnet den Preis einer Pizza.
# Eingabe: eine Pizza (Pizza).
# Ergebnis: der Preis in Euro (float), ohne zusaetzliche Rundung.
def pizzaPreis(pizza: Pizza) -> float:
    zutatenpreis = (zutatPreis(pizza.oliven, 0.50)
                   + zutatPreis(pizza.pilze, 0.40)
                   + zutatPreis(pizza.salami, 0.45)
                   + zutatPreis(pizza.kaese, 0.55))
    if pizza.groesse == 'normal':
        return 2.0 + zutatenpreis
    else:
        return 2.50 + zutatenpreis * 1.10


check(pizzaPreis(Pizza('normal', False, False, False, False)), 2.0)
check(pizzaPreis(Pizza('gross', False, False, False, False)), 2.50)
check(pizzaPreis(Pizza('normal', True, False, False, False)), 2.50)
check(pizzaPreis(Pizza('normal', False, True, False, False)), 2.40)
check(pizzaPreis(Pizza('normal', False, False, True, False)), 2.45)
check(pizzaPreis(Pizza('normal', False, False, False, True)), 2.55)
check(pizzaPreis(Pizza('gross', True, False, False, False)), 3.05)
check(pizzaPreis(Pizza('gross', False, True, False, False)), 2.94)
check(pizzaPreis(Pizza('gross', False, False, True, False)), 2.995)
check(pizzaPreis(Pizza('gross', False, False, False, True)), 3.105)
check(pizzaPreis(Pizza('normal', True, True, True, True)), 3.90)
check(pizzaPreis(Pizza('gross', True, True, True, True)), 4.59)
check(pizzaPreis(Pizza('normal', True, True, False, False)), 2.90)
check(pizzaPreis(Pizza('gross', True, False, False, True)), 3.655)


# Aufgabe 3(b): Weitere Gerichte und Getraenke

# Eine Biersorte ist eins der folgenden:
# - 'Pils',
# - 'Weizen'.
type Biersorte = Literal['Pils', 'Weizen']

# Eine Biergroesse ist eins der folgenden:
# - 300 Milliliter (0,3 Liter),
# - 500 Milliliter (0,5 Liter).
type Biergroesse = Literal[300, 500]


# Ein Bier besteht aus:
# - seiner Sorte (Biersorte),
# - seiner Groesse in Millilitern (Biergroesse).
@record
class Bier:
    sorte: Biersorte
    groesseInMl: Biergroesse


# Ein Nudelgericht besteht aus:
# - seinem Namen (str),
# - seinem Preis pro 100 Gramm in Euro (float),
# - seiner Bestellmenge in ganzen Gramm (int, mindestens 0).
@record
class Nudelgericht:
    name: str
    preisPro100g: float
    mengeInGramm: int


# Eine SpeiseOderGetraenk ist eins der folgenden:
# - eine Pizza,
# - ein Nudelgericht,
# - ein Bier.
type SpeiseOderGetraenk = Union[Pizza, Nudelgericht, Bier]


# Berechnet den Preis eines Biers.
# Eingabe: ein Bier (Bier).
# Ergebnis: der Preis in Euro (float).
def bierPreis(bier: Bier) -> float:
    if bier.sorte == 'Pils':
        return bier.groesseInMl / 100 * 0.80
    else:
        return bier.groesseInMl / 100 * 0.85


check(bierPreis(Bier('Pils', 300)), 2.40)
check(bierPreis(Bier('Pils', 500)), 4.0)
check(bierPreis(Bier('Weizen', 300)), 2.55)
check(bierPreis(Bier('Weizen', 500)), 4.25)


# Berechnet den Preis eines Nudelgerichts.
# Eingabe: ein Nudelgericht (Nudelgericht).
# Ergebnis: der Preis fuer die Bestellmenge in Euro (float).
def nudelPreis(nudeln: Nudelgericht) -> float:
    return nudeln.mengeInGramm / 100 * nudeln.preisPro100g


check(nudelPreis(Nudelgericht('Spaghetti', 1.20, 100)), 1.20)
check(nudelPreis(Nudelgericht('Penne', 1.50, 250)), 3.75)
check(nudelPreis(Nudelgericht('Fusilli', 1.80, 50)), 0.90)
check(nudelPreis(Nudelgericht('Spaghetti', 1.20, 0)), 0.0)


# Berechnet den Preis eines Gerichts oder Getraenks.
# Eingabe: eine Pizza, ein Nudelgericht oder ein Bier (SpeiseOderGetraenk).
# Ergebnis: der Preis in Euro (float).
def preis(bestellung: SpeiseOderGetraenk) -> float:
    if isinstance(bestellung, Pizza):
        return pizzaPreis(bestellung)
    elif isinstance(bestellung, Nudelgericht):
        return nudelPreis(bestellung)
    elif isinstance(bestellung, Bier):
        return bierPreis(bestellung)


check(preis(Pizza('normal', False, False, False, False)), 2.0)
check(preis(Pizza('gross', True, True, True, True)), 4.59)
check(preis(Nudelgericht('Penne', 1.50, 250)), 3.75)
check(preis(Nudelgericht('Fusilli', 1.80, 50)), 0.90)
check(preis(Bier('Pils', 300)), 2.40)
check(preis(Bier('Pils', 500)), 4.0)
check(preis(Bier('Weizen', 300)), 2.55)
check(preis(Bier('Weizen', 500)), 4.25)
