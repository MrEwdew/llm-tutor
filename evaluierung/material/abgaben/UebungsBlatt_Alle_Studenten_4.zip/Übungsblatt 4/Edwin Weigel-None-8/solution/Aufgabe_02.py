from wypp import *

# a)
# Prueft, ob eine Rueckennummer von 1 bis 99 vorhanden ist.
# Eingabe: eine Rueckennummer (int) oder None.
# Ergebnis: True fuer 1 bis 99, sonst False (bool).
def rueckenNr(nummer: int | None) -> bool:
    if nummer is None:
        return False
    else:
        return 0 < nummer <= 99


check(rueckenNr(17), True)
check(rueckenNr(0), False)
check(rueckenNr(100), False)
check(rueckenNr(None), False)


# b)
# Ein Sportartikel ist ein Trikot, eine Hose oder Stutzen.
# Eine optionale Rueckennummer ist eine Zahl (int) oder None.

type Farbe = Literal['schwarz', 'gruen', 'blau', 'rot']
type Groesse = Literal['S', 'M', 'L']



@record
class Trikot:
    farbe: Farbe
    groesse: Groesse
    rueckennummer: int | None



@record
class Hose:
    farbe: Farbe
    groesse: Groesse



@record
class Stutzen:
    untereSchuhgroesse: int
    obereSchuhgroesse: int
    farbe: Farbe


type Sportartikel = Union[Trikot, Stutzen, Hose]


# c)
# Berechnet den Preis eines Sportartikels.
# Eingabe: ein Trikot, eine Hose oder Stutzen (Sportartikel).
# Ergebnis: Preis in Euro (int) oder None bei ungueltiger Rueckennummer.
def preisSportartikel(artikel: Sportartikel) -> int | None:
    if isinstance(artikel, Trikot):
        if artikel.rueckennummer is None:
            return 20
        elif rueckenNr(artikel.rueckennummer):
            return 25
        else:
            return None

    elif isinstance(artikel, Hose):
        if artikel.groesse == 'S':
            return 10
        elif artikel.groesse == 'M':
            return 12
        else:
            return 15

    else:
        if artikel.obereSchuhgroesse <= 38:
            return 5
        else:
            return 9



check(preisSportartikel(Trikot('rot', 'M', None)), 20)
check(preisSportartikel(Trikot('blau', 'L', 7)), 25)


check(preisSportartikel(Trikot('rot', 'M', 0)), None)
check(preisSportartikel(Trikot('rot', 'M', 109)), None)


check(preisSportartikel(Hose('schwarz', 'S')), 10)
check(preisSportartikel(Hose('gruen', 'M')), 12)
check(preisSportartikel(Hose('rot', 'L')), 15)


check(preisSportartikel(Stutzen(35, 38, 'blau')), 5)
check(preisSportartikel(Stutzen(36, 39, 'schwarz')), 9)