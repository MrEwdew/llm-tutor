from wypp import*

#Adresse hat einen Namen, Postleitzahl und Stadt 
#Zusatzinfo: Strasse+Hausnummer oder Nummer einer Packstation
#Funktion welche True zurueckgibt, falls die Zustellung zu jeder Uhrzeit moeglich
#Packstation kann immer zugestellt werden (true), an eine Anschrift mit Strasse und Hausnummer nicht(false).
#Eingabe: Name(Str), Postleitzahl (int),Stadt(str) und Strasse+Hausnummer (str) oder Nummer einer Packstation(int)



@record
class Hausanschrift:
    strasse: str
    hausnummer: int

@record 
class Packstation:
    nummer: int 

type Zusatzinfo = Union[Hausanschrift, Packstation]

@record
class Adresse:
    name: str
    plz: int
    stadt: str
    zusatzinfo: Zusatzinfo

def isDeliveryAlwaysPossible(adresse: Adresse) -> bool:
    return isinstance(adresse.zusatzinfo, Packstation)


check(isDeliveryAlwaysPossible(Adresse('Yuri Boyka', 77694, 'Kehl', Hausanschrift('Okenstrasse', 2))),False)
check(isDeliveryAlwaysPossible(Adresse('Yuri Boyka', 77694,'Kehl',Packstation(187))),True)