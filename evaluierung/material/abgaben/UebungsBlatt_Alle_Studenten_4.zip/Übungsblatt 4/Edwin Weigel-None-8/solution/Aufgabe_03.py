from wypp import *


# a)
# Eine Pizza hat eine Groesse: normal (2,00 Euro) oder gross (2,50 Euro).
# Zutaten: Oliven (0,60 Euro), Pilze (0,40 Euro),
# Salami (0,45 Euro) und Kaese (0,55 Euro).
# Jede Zutat wird durch einen bool dargestellt.
# Bei grossen Pizzen werden die Zutaten um 10 Prozent teurer.

type PizzaGroesse = Literal['normal', 'gross']


@record
class Pizza:
    groesse: PizzaGroesse
    oliven: bool
    pilze: bool
    salami: bool
    kaese: bool


# Berechnet den Preis einer Pizza.
# Eingabe: eine Pizza mit Groesse und ausgewaehlten Zutaten.
# Ergebnis: Preis in Euro (float).
def preisPizza(pizza: Pizza) -> float:
    zutatenPreis = 0.0

    if pizza.oliven:
        zutatenPreis = zutatenPreis + 0.60

    if pizza.pilze:
        zutatenPreis = zutatenPreis + 0.40

    if pizza.salami:
        zutatenPreis = zutatenPreis + 0.45

    if pizza.kaese:
        zutatenPreis = zutatenPreis + 0.55

    if pizza.groesse == 'normal':
        return 2.0 + zutatenPreis
    else:
        return 2.5 + zutatenPreis * 1.10


check(preisPizza(Pizza('normal', False, False, False, False)), 2.0)
check(preisPizza(Pizza('gross', False, False, False, False)), 2.5)
check(preisPizza(Pizza('normal', True, False, False, False)), 2.6)
check(preisPizza(Pizza('normal', False, True, False, False)), 2.4)
check(preisPizza(Pizza('normal', False, False, True, False)), 2.45)
check(preisPizza(Pizza('normal', False, False, False, True)), 2.55)
check(preisPizza(Pizza('normal', True, True, True, True)), 4.0)
check(preisPizza(Pizza('gross', True, True, True, True)), 4.7)
check(preisPizza(Pizza('gross', False, False, True, False)), 2.995)


# b)
# Es gibt die Biersorten Weizen und Pils.
# Die Menge ist 300 ml oder 500 ml.
# Preis pro 100 ml: Weizen 0,85 Euro und Pils 0,80 Euro.

type BierSorte = Literal['Weizen', 'Pils']
type BierMenge = Literal[300, 500]


@record
class Bier:
    sorte: BierSorte
    menge: BierMenge


# Berechnet den Preis eines Biers.
# Eingabe: ein Bier mit Sorte und Menge in Millilitern.
# Ergebnis: Preis in Euro (float).
# Berechnung: Anzahl der 100-ml * Preis pro 100 ml.

def preisBier(bier: Bier) -> float:
    if bier.sorte == 'Pils':
        return bier.menge / 100 * 0.80
    else:
        return bier.menge / 100 * 0.85


check(preisBier(Bier('Pils', 300)), 2.4)
check(preisBier(Bier('Pils', 500)), 4.0)
check(preisBier(Bier('Weizen', 300)), 2.55)
check(preisBier(Bier('Weizen', 500)), 4.25)


# Ein Nudelgericht besitzt:
# - einen Namen (str)
# - einen Preis pro 100 Gramm (float)
# - eine bestellte Menge in Gramm (int)

@record
class Nudel:
    name: str
    preisPro100g: float
    mengeG: int


# Berechnet den Preis einer Nudelportion.
# Eingabe: eine Nudelportion mit Menge und Preis pro 100 Gramm.
# Ergebnis: Gesamtpreis in Euro (float).
# Berechnung: Menge / 100 * Preis pro 100 Gramm.

def preisNudel(nudel: Nudel) -> float:
    return nudel.mengeG / 100 * nudel.preisPro100g



check(preisNudel(Nudel('Spaghetti', 1.50, 200)), 3.0)
check(preisNudel(Nudel('Penne', 2.00, 250)), 5.0)

type Bestellung = Union[Pizza, Bier, Nudel]


# Berechnet den Preis einer Bestellung.
# Eingabe: eine Pizza, ein Bier oder eine Nudelportion (Bestellung).
# Ergebnis: Preis in Euro (float).

def preis(bestellung: Bestellung) -> float:
    if isinstance(bestellung, Pizza):
        return preisPizza(bestellung)
    elif isinstance(bestellung, Bier):
        return preisBier(bestellung)
    else:
        return preisNudel(bestellung)


check(preis(Pizza('gross', True, True, True, True)), 4.7)
check(preis(Bier('Weizen', 500)), 4.25)
check(preis(Nudel('Penne', 2.00, 250)), 5.0)