from wypp import *


# a)
# Auto: Farbe (str), Marke (str) und Antriebsart.
# Fahrrad: Marke (str) und Antriebsart.
# Fahrzeug: Auto oder Fahrrad.

type AutoAntrieb = Literal['Verbrenner', 'elektrisch']
type FahrradAntreib = Literal['Muskelkraft', 'elektrisch']


@record
class Auto:
    farbe: str
    marke: str
    antriebsart: AutoAntrieb


@record
class Fahrrad:
    marke: str
    antriebsart: FahrradAntreib


type Fahrzeug = Union[Auto, Fahrrad]


# b)
# Berechnet die Reichweite eines Autos.
# Eingabe: ein Auto (Auto).
# Ergebnis: Reichweite in Kilometern (int).
def reichweiteAuto(auto: Auto) -> int:
    if auto.antriebsart == 'Verbrenner':
        return 600
    else:
        return 400


check(reichweiteAuto(Auto('rot', 'Benz', 'Verbrenner')), 600)
check(reichweiteAuto(Auto('rot', 'Benz', 'elektrisch')), 400)


# Berechnet die Reichweite eines Fahrrads.
# Eingabe: ein Fahrrad (Fahrrad).
# Ergebnis: Reichweite in Kilometern (int).
def reichweiteFahrrad(fahrrad: Fahrrad) -> int:
    if fahrrad.antriebsart == 'elektrisch':
        return 120
    else:
        return 10000


check(reichweiteFahrrad(Fahrrad('Porsch', 'elektrisch')), 120)
check(reichweiteFahrrad(Fahrrad('Porsch', 'Muskelkraft')), 10000)


# Berechnet die Reichweite eines Fahrzeugs.
# Eingabe: ein Auto oder Fahrrad (Fahrzeug).
# Ergebnis: Reichweite in Kilometern (int).
def reichweite(fahrzeug: Fahrzeug) -> int:
    if isinstance(fahrzeug, Auto):
        return reichweiteAuto(fahrzeug)
    else:
        return reichweiteFahrrad(fahrzeug)


check(reichweite(Auto('rot', 'Benz', 'Verbrenner')), 600)
check(reichweite(Auto('schwarz', 'Bmw', 'elektrisch')), 400)
check(reichweite(Fahrrad('Arsch', 'elektrisch')), 120)
check(reichweite(Fahrrad('Arsch', 'Muskelkraft')), 10000)