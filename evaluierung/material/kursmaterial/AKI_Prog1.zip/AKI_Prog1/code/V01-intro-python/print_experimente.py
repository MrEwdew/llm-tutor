print("Hello\n'Stefan'")
